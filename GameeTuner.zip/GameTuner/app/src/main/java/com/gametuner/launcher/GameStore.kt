package com.gametuner.launcher

import android.content.Context

/** Penyimpanan sederhana: profil per game + pengaturan global. */
class GameStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("gametuner", Context.MODE_PRIVATE)

    fun getScale(pkg: String): Int = prefs.getInt("scale_$pkg", 100)

    fun setScale(pkg: String, percent: Int) {
        prefs.edit().putInt("scale_$pkg", percent).apply()
    }

    /** Batas refresh rate (Hz) per game. 0 = otomatis / tidak dibatasi. */
    fun getFps(pkg: String): Int = prefs.getInt("fps_$pkg", 0)

    fun setFps(pkg: String, hz: Int) {
        prefs.edit().putInt("fps_$pkg", hz).apply()
    }

    /** Ikut skala density supaya ukuran UI/teks tetap normal saat resolusi diturunkan. */
    var scaleDensity: Boolean
        get() = prefs.getBoolean("scale_density", true)
        set(value) { prefs.edit().putBoolean("scale_density", value).apply() }

    /** Game yang terakhir diluncurkan; perubahan dari overlay disimpan ke game ini. */
    var currentGame: String?
        get() = prefs.getString("current_game", null)
        set(value) { prefs.edit().putString("current_game", value).apply() }

    /** Kembalikan layar otomatis setelah game ditinggalkan beberapa detik. Default: aktif. */
    var autoReset: Boolean
        get() = prefs.getBoolean("auto_reset", true)
        set(value) { prefs.edit().putBoolean("auto_reset", value).apply() }

    /** Bisukan notifikasi (Jangan Ganggu) selama main. Default: mati. */
    var focusMode: Boolean
        get() = prefs.getBoolean("focus_mode", false)
        set(value) { prefs.edit().putBoolean("focus_mode", value).apply() }

    /** Matikan Penghemat Baterai selama main bila sedang menyala. Default: mati. */
    var batterySaverOff: Boolean
        get() = prefs.getBoolean("bs_off", false)
        set(value) { prefs.edit().putBoolean("bs_off", value).apply() }

    /** True bila KITA yang menyalakan Jangan Ganggu, jadi KITA yang harus mematikannya lagi. */
    var focusApplied: Boolean
        get() = prefs.getBoolean("focus_applied", false)
        set(value) { prefs.edit().putBoolean("focus_applied", value).apply() }

    /** True bila KITA yang mematikan Penghemat Baterai, jadi KITA yang harus menyalakannya lagi. */
    var batterySaverApplied: Boolean
        get() = prefs.getBoolean("bs_applied", false)
        set(value) { prefs.edit().putBoolean("bs_applied", value).apply() }

    /** Batas suhu baterai (°C) untuk peringatan panas di bubble. 0 = mati. */
    var heatWarnC: Int
        get() = prefs.getInt("heat_warn", 44)
        set(value) { prefs.edit().putInt("heat_warn", value).apply() }

    /** Bersihkan RAM otomatis saat RAM bebas menipis selama main. Default: mati. */
    var autoBoost: Boolean
        get() = prefs.getBoolean("auto_boost", false)
        set(value) { prefs.edit().putBoolean("auto_boost", value).apply() }

    /**
     * DPI normal pengguna. Density dikembalikan ke angka ini setelah main, dan saat resolusi
     * layar diturunkan density dihitung dari angka ini. 0 = otomatis (DPI sebelum kita ubah).
     * Default 490, DPI milik pemilik aplikasi; ubah di Pengaturan.
     */
    var baseDpi: Int
        get() = prefs.getInt("base_dpi", 490)
        set(value) { prefs.edit().putInt("base_dpi", value).apply() }

    /** DPI pengguna sebelum kita mengubah layar (mode otomatis). 0 = belum tersimpan. */
    var savedDpi: Int
        get() = prefs.getInt("saved_dpi", 0)
        set(value) { prefs.edit().putInt("saved_dpi", value).apply() }

    /** True bila KITA yang mengubah ukuran/density layar, jadi KITA yang harus mengembalikannya. */
    var screenApplied: Boolean
        get() = prefs.getBoolean("screen_applied", false)
        set(value) { prefs.edit().putBoolean("screen_applied", value).apply() }

    /** Resolusi per game lewat Game Mode Android (layar dan aplikasi lain tidak berubah). Default: aktif. */
    var perGameResolution: Boolean
        get() = prefs.getBoolean("per_game_res", true)
        set(value) { prefs.edit().putBoolean("per_game_res", value).apply() }

    /** Batas FPS per game lewat Game Mode Android (refresh rate layar tidak diubah). Default: aktif. */
    var perGameFps: Boolean
        get() = prefs.getBoolean("per_game_fps", true)
        set(value) { prefs.edit().putBoolean("per_game_fps", value).apply() }

    /**
     * Game yang sedang kita beri pengaturan Game Mode (downscale dan/atau FPS), supaya bisa
     * dibersihkan saat reset. Null = tidak ada.
     */
    var downscalePkg: String?
        get() = prefs.getString("downscale_pkg", null)
        set(value) { prefs.edit().putString("downscale_pkg", value).apply() }

    /** Skala resolusi (persen) yang sedang aktif lewat Game Mode pada [downscalePkg]; 100 = tidak ada. */
    var gameScale: Int
        get() = prefs.getInt("game_scale", 100)
        set(value) { prefs.edit().putInt("game_scale", value).apply() }

    /** Batas FPS yang sedang aktif lewat Game Mode pada [downscalePkg]; 0 = tidak ada. */
    var gameFps: Int
        get() = prefs.getInt("game_fps", 0)
        set(value) { prefs.edit().putInt("game_fps", value).apply() }

    /** Trigger (auto tap): jumlah ketukan per detik. */
    var triggerCps: Int
        get() = prefs.getInt("trigger_cps", 5)
        set(value) { prefs.edit().putInt("trigger_cps", value).apply() }

    /** Trigger: berhenti sendiri setelah sekian ketukan. 0 = tanpa batas. */
    var triggerLimit: Int
        get() = prefs.getInt("trigger_limit", 0)
        set(value) { prefs.edit().putInt("trigger_limit", value).apply() }

    /** Trigger: posisi terakhir lingkaran bidik (piksel layar, titik tengah). -1 = tengah layar. */
    var triggerX: Int
        get() = prefs.getInt("trigger_x", -1)
        set(value) { prefs.edit().putInt("trigger_x", value).apply() }

    var triggerY: Int
        get() = prefs.getInt("trigger_y", -1)
        set(value) { prefs.edit().putInt("trigger_y", value).apply() }

    /** HUD Mini: angka yang ditampilkan, dipisah koma (lihat [HudItem]). Default: FPS saja. */
    var hudItems: String
        get() = prefs.getString("hud_items", HudItem.FPS_ONLY) ?: HudItem.FPS_ONLY
        set(value) { prefs.edit().putString("hud_items", value).apply() }

    /** HUD Mini: posisi terakhir (piksel layar, pojok kiri atas). -1 = posisi awal. */
    var hudX: Int
        get() = prefs.getInt("hud_x", -1)
        set(value) { prefs.edit().putInt("hud_x", value).apply() }

    var hudY: Int
        get() = prefs.getInt("hud_y", -1)
        set(value) { prefs.edit().putInt("hud_y", value).apply() }

    /** Game terpilih di Game Lobby. */
    var lobbyPkg: String?
        get() = prefs.getString("lobby_pkg", null)
        set(value) { prefs.edit().putString("lobby_pkg", value).apply() }

    /** Aplikasi bukan-game yang ditambahkan ke Game Lobby (nama paket, dipisah koma). */
    var lobbyAdd: Set<String>
        get() = csvSet("lobby_add")
        set(value) { prefs.edit().putString("lobby_add", value.joinToString(",")).apply() }

    /** Game terdeteksi yang disembunyikan dari Game Lobby. */
    var lobbyHide: Set<String>
        get() = csvSet("lobby_hide")
        set(value) { prefs.edit().putString("lobby_hide", value.joinToString(",")).apply() }

    private fun csvSet(key: String): Set<String> =
        prefs.getString(key, "").orEmpty().split(',').filter { it.isNotBlank() }.toSet()

    /** Mode Main: terapkan profil resolusi/FPS saat game diluncurkan dari aplikasi. Default: aktif. */
    var playOptimize: Boolean
        get() = prefs.getBoolean("play_optimize", true)
        set(value) { prefs.edit().putBoolean("play_optimize", value).apply() }

    /** Auto FPS: turunkan batas refresh rate ke 60 Hz saat HP panas, naikkan lagi saat dingin. Default: mati. */
    var autoFps: Boolean
        get() = prefs.getBoolean("auto_fps", false)
        set(value) { prefs.edit().putBoolean("auto_fps", value).apply() }

    /** Batas suhu terakhir yang dipilih (>0); dipakai saat Peringatan Panas dinyalakan lagi. */
    var lastHeatWarnC: Int
        get() = prefs.getInt("heat_warn_last", 44)
        set(value) { prefs.edit().putInt("heat_warn_last", value).apply() }

    /**
     * Nilai asli pengaturan refresh rate sistem sebelum kita ubah, format "min|peak".
     * Dipakai untuk memulihkan pengaturan pengguna saat reset. Null = belum kita ubah.
     */
    var savedRefresh: String?
        get() = prefs.getString("saved_refresh", null)
        set(value) { prefs.edit().putString("saved_refresh", value).apply() }

    /** Cara membuka pop-up in-game: [OPEN_EDGE] = geser dari tepi layar, [OPEN_BUBBLE] = bubble NX melayang. */
    var openMode: String
        get() = prefs.getString("open_mode", OPEN_EDGE) ?: OPEN_EDGE
        set(value) { prefs.edit().putString("open_mode", value).apply() }

    /** Tepi layar untuk geser buka pop-up: true = kanan, false = kiri. */
    var edgeRight: Boolean
        get() = prefs.getBoolean("edge_right", false)
        set(value) { prefs.edit().putBoolean("edge_right", value).apply() }

    companion object {
        const val OPEN_EDGE = "edge"
        const val OPEN_BUBBLE = "bubble"
    }
}
