package com.gametuner.launcher

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.CornerPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.ceil

/**
 * Komponen tampilan bertema neon ungu untuk pop-up in-game (panel kiri dan kanan).
 * Semuanya digambar dengan Canvas/View biasa (bukan Compose) karena dipakai di dalam Service.
 *
 * Parameter `unit` di semua kelas = jumlah piksel untuk 1 "dp" pada tata letak ini
 * (kepadatan layar dikali skala panel), jadi ukurannya ikut besar-kecilnya layar.
 */
internal object Neon {
    val LINE = 0xFFB66DFF.toInt()
    val LINE_BRIGHT = 0xFFE9D5FF.toInt()
    val RAIL = 0xFF7C3AED.toInt()
    val FILL_TOP = 0xFF2A1670.toInt()
    val FILL_BOTTOM = 0xFF140A33.toInt()
    val PANEL_TOP = 0xF0200F56.toInt()
    val PANEL_BOTTOM = 0xF00A0524.toInt()
    val ACTIVE_TOP = 0xFF6D28D9.toInt()
    val ACTIVE_BOTTOM = 0xFF3B0F8F.toInt()
    val TEXT = 0xFFFFFFFF.toInt()
    val MUTED = 0xFFB9ABE8.toInt()
    val MAGENTA = 0xFFE879F9.toInt()
    val GREEN = 0xFF34D399.toInt()
    val AMBER = 0xFFFFA94D.toInt()
    val RED = 0xFFFF6B5A.toInt()

    /** [color] dengan transparansi [a] (0..255). */
    fun withAlpha(color: Int, a: Int): Int = (color and 0x00FFFFFF) or (a.coerceIn(0, 255) shl 24)

    /** Campuran dua warna; [t] 0 = [a], 1 = [b]. */
    fun lerp(a: Int, b: Int, t: Float): Int {
        val k = t.coerceIn(0f, 1f)
        fun mix(x: Int, y: Int) = (x + (y - x) * k).toInt()
        return Color.argb(
            mix(Color.alpha(a), Color.alpha(b)),
            mix(Color.red(a), Color.red(b)),
            mix(Color.green(a), Color.green(b)),
            mix(Color.blue(a), Color.blue(b)),
        )
    }

    fun px(v: Float, unit: Float): Int = (v * unit).toInt()

    /** Atur ukuran teks dalam piksel mengikuti [unit] (tidak ikut ukuran font sistem). */
    fun TextView.sizePx(v: Float, unit: Float) {
        setTextSize(TypedValue.COMPLEX_UNIT_PX, v * unit)
    }

    val SPORT: Typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
}

/**
 * Bentuk berbingkai neon: kotak bersudut potong, segi enam, atau panel samping dengan sisi miring
 * seperti desain. Garis tepinya berpendar (beberapa goresan menumpuk), tanpa blur sehingga aman
 * di hardware acceleration.
 */
internal class NeonDrawable(
    private val shape: Shape,
    private val unit: Float,
    private val cutDp: Float = 8f,
    private val fillTop: Int = Neon.FILL_TOP,
    private val fillBottom: Int = Neon.FILL_BOTTOM,
    private val line: Int = Neon.LINE,
    private val lineDp: Float = 1.4f,
    private val glow: Boolean = true,
) : Drawable() {

    enum class Shape { CHAMFER, HEX, PANEL_LEFT, PANEL_RIGHT }

    private val lineW = lineDp * unit
    private val path = Path()
    private val rail = Path()
    private val round = CornerPathEffect(2.5f * unit)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        pathEffect = round
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        pathEffect = round
    }
    private val isPanel = shape == Shape.PANEL_LEFT || shape == Shape.PANEL_RIGHT

    override fun onBoundsChange(bounds: Rect) {
        super.onBoundsChange(bounds)
        val inset = lineW * 2.6f
        val l = bounds.left + inset
        val t = bounds.top + inset
        val r = bounds.right - inset
        val b = bounds.bottom - inset
        val w = r - l
        val h = b - t
        path.reset()
        rail.reset()
        when (shape) {
            Shape.CHAMFER -> {
                val c = minOf(cutDp * unit, w / 2f, h / 2f)
                path.moveTo(l + c, t)
                path.lineTo(r - c, t)
                path.lineTo(r, t + c)
                path.lineTo(r, b - c)
                path.lineTo(r - c, b)
                path.lineTo(l + c, b)
                path.lineTo(l, b - c)
                path.lineTo(l, t + c)
                path.close()
            }
            Shape.HEX -> {
                val cx = (l + r) / 2f
                path.moveTo(cx, t)
                path.lineTo(r, t + h * 0.25f)
                path.lineTo(r, t + h * 0.75f)
                path.lineTo(cx, b)
                path.lineTo(l, t + h * 0.75f)
                path.lineTo(l, t + h * 0.25f)
                path.close()
            }
            Shape.PANEL_LEFT -> {
                path.moveTo(l, t)
                path.lineTo(l + w * 0.80f, t)
                path.lineTo(r, t + h * 0.34f)
                path.lineTo(l + w * 0.50f, b)
                path.lineTo(l, b)
                path.close()
                rail.moveTo(l + w * 0.80f, t)
                rail.lineTo(r, t + h * 0.34f)
                rail.lineTo(l + w * 0.50f, b)
            }
            Shape.PANEL_RIGHT -> {
                path.moveTo(r, t)
                path.lineTo(r - w * 0.80f, t)
                path.lineTo(l, t + h * 0.34f)
                path.lineTo(r - w * 0.50f, b)
                path.lineTo(r, b)
                path.close()
                rail.moveTo(r - w * 0.80f, t)
                rail.lineTo(l, t + h * 0.34f)
                rail.lineTo(r - w * 0.50f, b)
            }
        }
        fillPaint.shader = LinearGradient(
            0f, bounds.top.toFloat(), 0f, bounds.bottom.toFloat(),
            fillTop, fillBottom, Shader.TileMode.CLAMP
        )
    }

    override fun draw(canvas: Canvas) {
        canvas.drawPath(path, fillPaint)
        if (glow) {
            strokePaint.color = Neon.withAlpha(line, 0x22)
            strokePaint.strokeWidth = lineW * 5f
            canvas.drawPath(path, strokePaint)
            strokePaint.color = Neon.withAlpha(line, 0x44)
            strokePaint.strokeWidth = lineW * 3f
            canvas.drawPath(path, strokePaint)
        }
        strokePaint.color = line
        strokePaint.strokeWidth = lineW
        canvas.drawPath(path, strokePaint)

        if (isPanel) {
            // Rel tebal bercahaya di sisi miring panel.
            strokePaint.color = Neon.withAlpha(Neon.RAIL, 0x55)
            strokePaint.strokeWidth = lineW * 7f
            canvas.drawPath(rail, strokePaint)
            strokePaint.color = Neon.RAIL
            strokePaint.strokeWidth = lineW * 3.4f
            canvas.drawPath(rail, strokePaint)
            strokePaint.color = Neon.LINE_BRIGHT
            strokePaint.strokeWidth = lineW * 1.1f
            canvas.drawPath(rail, strokePaint)
        }
    }

    override fun setAlpha(alpha: Int) {
        fillPaint.alpha = alpha
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fillPaint.colorFilter = colorFilter
        strokePaint.colorFilter = colorFilter
        invalidateSelf()
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Tombol segi enam dengan ikon; [active] menyalakan tampilannya (misalnya Macro sedang tampil). */
internal class HexButton(context: Context, private val unit: Float, iconRes: Int) : FrameLayout(context) {
    private val icon = ImageView(context)

    var active: Boolean = false
        set(value) {
            field = value
            applyStyle()
        }

    init {
        icon.setImageResource(iconRes)
        icon.imageTintList = ColorStateList.valueOf(Color.WHITE)
        val pad = Neon.px(11f, unit)
        icon.setPadding(pad, pad, pad, pad)
        addView(icon, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        applyStyle()
    }

    private fun applyStyle() {
        background = if (active) {
            NeonDrawable(
                NeonDrawable.Shape.HEX, unit,
                fillTop = Neon.ACTIVE_TOP, fillBottom = Neon.ACTIVE_BOTTOM, line = Neon.LINE_BRIGHT
            )
        } else {
            NeonDrawable(NeonDrawable.Shape.HEX, unit)
        }
    }
}

/** Kotak kecil di grid kanan: ikon di atas, nama di bawah. [active] = menyala. */
internal class NeonTile(
    context: Context,
    private val unit: Float,
    iconRes: Int,
    text: String,
) : LinearLayout(context) {
    private val icon = ImageView(context)
    private val caption = TextView(context)

    var active: Boolean = false
        set(value) {
            field = value
            applyStyle()
        }

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        setPadding(Neon.px(3f, unit), Neon.px(3f, unit), Neon.px(3f, unit), Neon.px(3f, unit))
        icon.setImageResource(iconRes)
        addView(icon, LayoutParams(Neon.px(17f, unit), Neon.px(17f, unit)))
        caption.apply {
            this.text = text
            with(Neon) { sizePx(9f, unit) }
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(Neon.TEXT)
        }
        addView(caption, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        applyStyle()
    }

    fun setLabel(text: String) {
        caption.text = text
    }

    private fun applyStyle() {
        icon.imageTintList = ColorStateList.valueOf(if (active) Color.WHITE else Neon.MUTED)
        background = if (active) {
            NeonDrawable(
                NeonDrawable.Shape.CHAMFER, unit, cutDp = 6f,
                fillTop = Neon.ACTIVE_TOP, fillBottom = Neon.ACTIVE_BOTTOM, line = Neon.LINE_BRIGHT
            )
        } else {
            NeonDrawable(NeonDrawable.Shape.CHAMFER, unit, cutDp = 6f)
        }
    }
}

/** Baris di daftar kiri: judul kecil, nilai tebal, dan titik tiga (opsional) di kanan. */
internal class NeonRow(
    context: Context,
    unit: Float,
    title: String,
    withMore: Boolean,
) : LinearLayout(context) {
    private val value = TextView(context)

    /** TextView nilai, bisa dipakai langsung oleh kode pembaruan statistik. */
    val valueView: TextView get() = value

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(Neon.px(9f, unit), Neon.px(3f, unit), Neon.px(6f, unit), Neon.px(3f, unit))
        background = NeonDrawable(
            NeonDrawable.Shape.CHAMFER, unit, cutDp = 7f,
            fillTop = 0xFF22155A.toInt(), fillBottom = 0xFF150C3A.toInt(), glow = false
        )

        val texts = LinearLayout(context).apply { orientation = VERTICAL }
        texts.addView(TextView(context).apply {
            text = title
            with(Neon) { sizePx(9f, unit) }
            setTextColor(Neon.MUTED)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        value.apply {
            text = "—"
            with(Neon) { sizePx(13f, unit) }
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Neon.TEXT)
            maxLines = 1
        }
        texts.addView(value)
        addView(texts, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        if (withMore) {
            val more = ImageView(context).apply {
                setImageResource(R.drawable.ic_more_v)
                imageTintList = ColorStateList.valueOf(Neon.MUTED)
            }
            addView(more, LayoutParams(Neon.px(16f, unit), Neon.px(16f, unit)))
        }
    }

    fun setValue(text: String) {
        value.text = text
    }
}

/** Tombol lebar bersudut potong dengan teks tengah dan ikon penunjuk di kanan (seperti "Rise" di desain). */
internal class NeonSelector(
    context: Context,
    unit: Float,
    text: String,
    trailingRes: Int,
) : LinearLayout(context) {
    private val label = TextView(context)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER
        setPadding(Neon.px(10f, unit), Neon.px(3f, unit), Neon.px(8f, unit), Neon.px(3f, unit))
        background = NeonDrawable(
            NeonDrawable.Shape.CHAMFER, unit, cutDp = 10f,
            fillTop = 0xFF2E1A78.toInt(), fillBottom = 0xFF1A0E48.toInt()
        )
        label.apply {
            this.text = text
            with(Neon) { sizePx(12f, unit) }
            typeface = Neon.SPORT
            setTextColor(Neon.TEXT)
            gravity = Gravity.CENTER
            maxLines = 2
        }
        addView(label, LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val icon = ImageView(context).apply {
            setImageResource(trailingRes)
            imageTintList = ColorStateList.valueOf(Neon.TEXT)
        }
        addView(icon, LayoutParams(Neon.px(14f, unit), Neon.px(14f, unit)))
    }

    fun setLabel(text: String) {
        label.text = text
    }
}

/**
 * Pengukur bulat bergaya hologram: angka besar miring di atas, tiga cincin elips bercahaya sebagai
 * alas (cincin tengah menyala sesuai [progress]), dan label kecil di bawah.
 * [progress] null = HP tidak menyediakan datanya; angka tampil "—", bukan angka karangan.
 */
internal class OrbGauge(context: Context, private val unit: Float) : View(context) {
    var value: String = "—"
        set(v) {
            field = v
            invalidate()
        }
    var unitText: String = ""
        set(v) {
            field = v
            invalidate()
        }
    var label: String = ""
        set(v) {
            field = v
            invalidate()
        }
    var progress: Int? = null
        set(v) {
            field = v
            invalidate()
        }
    var warnFrom: Int = 70
    var alertFrom: Int = 90

    private val oval = RectF()
    private val pill = Path()
    private val numPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 34f * unit
        typeface = Neon.SPORT
    }
    private val unitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE9E3FF.toInt()
        textAlign = Paint.Align.CENTER
        textSize = 14f * unit
        typeface = Neon.SPORT
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 11f * unit
        typeface = Typeface.DEFAULT_BOLD
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    /** Isi angka dari persen; null menampilkan "—". */
    fun setPercent(p: Int?, unitLabel: String = "%") {
        progress = p
        value = p?.toString() ?: "—"
        unitText = if (p != null) unitLabel else ""
    }

    private fun ellipse(cx: Float, cy: Float, w: Float, h: Float) {
        oval.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f

        // Angka dan satuan.
        val numBase = h * 0.24f - (numPaint.ascent() + numPaint.descent()) / 2f
        canvas.drawText(value, cx, numBase, numPaint)
        if (unitText.isNotEmpty()) canvas.drawText(unitText, cx, numBase + 15f * unit, unitPaint)

        // Alas hologram: tiga elips bertumpuk.
        val cy = h * 0.66f
        val pw = w * 0.96f
        val ph = h * 0.30f

        ellipse(cx, cy, pw, ph)
        fill.color = 0xFF1A0B3D.toInt()
        canvas.drawOval(oval, fill)
        stroke.color = 0xFF5B21B6.toInt()
        stroke.strokeWidth = 2f * unit
        canvas.drawOval(oval, stroke)

        ellipse(cx, cy, pw * 0.80f, ph * 0.80f)
        fill.color = 0xFF2A1060.toInt()
        canvas.drawOval(oval, fill)
        stroke.color = 0xFF8B2FE0.toInt()
        stroke.strokeWidth = 3f * unit
        canvas.drawOval(oval, stroke)

        // Cincin tengah menyala sesuai persen.
        val p = progress
        if (p != null && p > 0) {
            val c = when {
                p >= alertFrom -> Neon.RED
                p >= warnFrom -> Neon.AMBER
                else -> Neon.MAGENTA
            }
            val sweep = 360f * p.coerceAtMost(100) / 100f
            stroke.color = Neon.withAlpha(c, 0x28)
            stroke.strokeWidth = 9f * unit
            canvas.drawArc(oval, 180f, sweep, false, stroke)
            stroke.color = Neon.withAlpha(c, 0x55)
            stroke.strokeWidth = 6f * unit
            canvas.drawArc(oval, 180f, sweep, false, stroke)
            stroke.color = c
            stroke.strokeWidth = 3f * unit
            canvas.drawArc(oval, 180f, sweep, false, stroke)
        }

        ellipse(cx, cy, pw * 0.52f, ph * 0.52f)
        fill.color = 0xFF3B1480.toInt()
        canvas.drawOval(oval, fill)
        stroke.color = 0xFFD946EF.toInt()
        stroke.strokeWidth = 2f * unit
        canvas.drawOval(oval, stroke)

        ellipse(cx, cy, pw * 0.24f, ph * 0.24f)
        fill.color = Neon.withAlpha(0xFFF0ABFC.toInt(), 0xAA)
        canvas.drawOval(oval, fill)

        // Label di bawah (CPU / GPU).
        if (label.isNotEmpty()) {
            val tw = labelPaint.measureText(label)
            val pillW = tw + 22f * unit
            val pillH = 18f * unit
            val top = h - pillH - 1f * unit
            val left = cx - pillW / 2f
            val c = 6f * unit
            pill.reset()
            pill.moveTo(left + c, top)
            pill.lineTo(left + pillW - c, top)
            pill.lineTo(left + pillW, top + pillH / 2f)
            pill.lineTo(left + pillW - c, top + pillH)
            pill.lineTo(left + c, top + pillH)
            pill.lineTo(left, top + pillH / 2f)
            pill.close()
            fill.color = 0xFF1A0B3D.toInt()
            canvas.drawPath(pill, fill)
            stroke.color = Neon.LINE
            stroke.strokeWidth = 1.2f * unit
            canvas.drawPath(pill, stroke)
            val base = top + pillH / 2f - (labelPaint.ascent() + labelPaint.descent()) / 2f
            canvas.drawText(label, cx, base, labelPaint)
        }
    }
}

/**
 * Pengukur garis-garis berbentuk trapesium: garis menyala dari bawah sesuai [percent], putih di bawah
 * dan ungu di atas. [alignStart] true = rata kiri (panel kiri), false = rata kanan (panel kanan).
 */
internal class StripeMeter(
    context: Context,
    private val unit: Float,
    private val alignStart: Boolean,
) : View(context) {
    var percent: Int? = null
        set(v) {
            field = v
            invalidate()
        }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val n = 14
        val w = width.toFloat()
        val h = height.toFloat()
        val slot = h / n
        val barH = slot * 0.62f
        val p = percent
        val lit = if (p == null) 0 else ceil(p.coerceIn(0, 100) / 100f * n).toInt()

        for (i in 0 until n) {
            val frac = i / (n - 1f)
            val barW = w * (1f - 0.78f * frac)
            val left = if (alignStart) 0f else w - barW
            val top = i * slot + (slot - barH) / 2f
            rect.set(left, top, left + barW, top + barH)
            val fromBottom = n - 1 - i
            paint.color = if (fromBottom < lit) {
                Neon.lerp(0xFFFFFFFF.toInt(), 0xFFA855F7.toInt(), frac)
            } else {
                Neon.withAlpha(0xFFA855F7.toInt(), 0x3A)
            }
            canvas.drawRoundRect(rect, barH / 2f, barH / 2f, paint)
        }
    }
}
