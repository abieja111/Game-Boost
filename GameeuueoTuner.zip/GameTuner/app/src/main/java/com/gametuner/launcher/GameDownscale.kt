package com.gametuner.launcher

import android.os.Build
import java.util.Locale

/**
 * Mengatur resolusi render dan batas FPS SATU game lewat Game Mode bawaan Android
 * (`cmd game set --downscale <0.3..0.9> --fps <30|45|60|90|120> <paket>`), tanpa mengubah ukuran
 * layar, density, atau refresh rate layar untuk aplikasi lain.
 *
 * Batasan (dari dokumentasi Android):
 * - Perintah mode kustom ada di Android 14 (API 34) ke atas.
 * - Game harus dibuka ulang supaya perubahan berlaku.
 * - Game boleh menolak lewat manifest-nya, dan pabrikan HP boleh membatasinya.
 * Semua fungsi memanggil shell (blocking): panggil dari thread background.
 */
object GameDownscale {

    val available: Boolean
        get() = Build.VERSION.SDK_INT >= 34

    /** Resolusi per game dipakai bila HP mendukung dan pengguna tidak mematikannya. */
    fun enabled(store: GameStore): Boolean = available && store.perGameResolution

    /** Batas FPS per game dipakai bila HP mendukung dan pengguna tidak mematikannya. */
    fun fpsEnabled(store: GameStore): Boolean = available && store.perGameFps

    /** Nilai FPS yang diterima Game Mode Android. */
    val GAME_FPS = listOf(30, 45, 60, 90, 120)

    fun fpsSupported(hz: Int): Boolean = hz in GAME_FPS

    /**
     * Pilihan batas FPS yang ditawarkan di UI. Bila FPS per game aktif, nilai Game Mode (30, 45, ...)
     * sampai refresh rate tertinggi panel ikut ditawarkan; nilai lain tetap memakai kunci refresh rate.
     */
    fun fpsOptions(panelRates: List<Int>, perGameFps: Boolean): List<Int> {
        if (!available || !perGameFps) return panelRates
        val top = panelRates.maxOrNull() ?: 60
        return (GAME_FPS.filter { it <= top } + panelRates).distinct().sorted()
    }

    /** Skala resolusi (persen) yang sedang aktif di [pkg] lewat Game Mode; 100 bila tidak ada. */
    fun activeScale(pkg: String, store: GameStore): Int =
        if (store.downscalePkg == pkg) store.gameScale else 100

    /** Batas FPS yang sedang aktif di [pkg] lewat Game Mode; 0 bila tidak ada. */
    fun activeFps(pkg: String, store: GameStore): Int =
        if (store.downscalePkg == pkg) store.gameFps else 0

    private val PACKAGE_NAME = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

    /** `cmd` kadang tetap berkode 0 saat menolak perintah, jadi teks keluarannya ikut diperiksa. */
    fun failed(r: CmdResult): Boolean {
        if (!r.ok) return true
        val t = (r.out + " " + r.err).lowercase()
        return "exception" in t || "error" in t || "invalid" in t || "unknown" in t
    }

    /** Ubah resolusi game; batas FPS yang sedang aktif di game ini dipertahankan. */
    fun apply(pkg: String, percent: Int, store: GameStore): CmdResult {
        dropScreenOverride(store)
        return configure(pkg, percent, activeFps(pkg, store), store)
    }

    /**
     * Sisa pengecilan seluruh layar (cara cadangan) dibuang supaya resolusi tidak turun dua kali.
     * Tidak melakukan apa-apa bila bukan kita yang mengubah layar.
     */
    fun dropScreenOverride(store: GameStore) {
        DisplayController.reset(store, force = false)
    }

    /** Ubah batas FPS game ([hz] 0 = lepas); resolusi yang sedang aktif di game ini dipertahankan. */
    fun applyFps(pkg: String, hz: Int, store: GameStore): CmdResult =
        configure(pkg, activeScale(pkg, store), hz, store)

    /**
     * Terapkan resolusi ([percent], 100 = asli) dan batas FPS ([fps], 0 = tanpa batas) ke [pkg]
     * dalam satu perintah. Bila keduanya "asli", pengaturan buatan kita dibersihkan.
     */
    fun configure(pkg: String, percent: Int, fps: Int, store: GameStore): CmdResult {
        if (!PACKAGE_NAME.matches(pkg)) return CmdResult(false, "", "Nama paket tidak valid.")

        // Game lain yang tadi kita atur dibersihkan dulu, supaya tidak ada sisa pengaturan.
        val previous = store.downscalePkg
        val previousCleared = previous == null || previous == pkg || clear(previous, store).ok

        if (percent >= 100 && fps <= 0) {
            // Hanya bersihkan bila KITA yang mengatur game ini; jangan sentuh Game Mode buatan pengguna.
            return if (store.downscalePkg == pkg) clear(pkg, store) else CmdResult(true, "", "")
        }

        // Bagian yang sudah aktif di game ini dan sekarang harus dilepas.
        val hadScale = previous == pkg && store.gameScale < 100
        val hadFps = previous == pkg && store.gameFps > 0
        val parts = mutableListOf<String>()
        if (percent < 100) {
            parts += "--downscale " + String.format(Locale.US, "%.1f", percent / 100f)
        } else if (hadScale) {
            parts += "--downscale disable"
        }
        if (fps > 0) {
            parts += "--fps $fps"
        } else if (hadFps) {
            parts += "--fps disable"
        }

        // Dicatat sebelum perintah dijalankan, supaya hasil sebagian pun tetap bisa dibersihkan saat Reset.
        store.downscalePkg = pkg
        val set = ShellRunner.exec("cmd game set ${parts.joinToString(" ")} $pkg")
        if (failed(set)) {
            // Gagal: lepaskan catatan, kecuali ada game yang masih terpasang dan perlu dibersihkan nanti.
            store.downscalePkg = if (previous != null && (previous == pkg || !previousCleared)) previous else null
            return CmdResult(false, set.out, set.err.ifBlank { set.out })
        }
        store.gameScale = if (percent >= 100) 100 else percent
        store.gameFps = if (fps > 0) fps else 0
        // Pilih mode kustom supaya pengaturan tadi dipakai. Bila perintah ini ditolak, tidak fatal.
        ShellRunner.exec("cmd game mode custom $pkg")
        return CmdResult(true, set.out, set.err)
    }

    /** Hapus pengaturan Game Mode buatan kita pada game ini dan kembalikan modenya ke standar. */
    fun clear(pkg: String, store: GameStore): CmdResult {
        if (!PACKAGE_NAME.matches(pkg)) return CmdResult(true, "", "")
        val a = ShellRunner.exec("cmd game set --downscale disable $pkg")
        val b = ShellRunner.exec("cmd game reset $pkg")
        ShellRunner.exec("cmd game mode standard $pkg")

        val ok = !failed(a) || !failed(b)
        if (ok && store.downscalePkg == pkg) {
            store.downscalePkg = null
            store.gameScale = 100
            store.gameFps = 0
        }
        return CmdResult(
            ok = ok,
            out = "",
            err = if (ok) "" else listOf(a.err, b.err, a.out).filter { it.isNotBlank() }.joinToString("\n"),
        )
    }

    /** Dipakai Reset, Selesai, dan reset otomatis. Tidak melakukan apa-apa bila tidak ada yang kita ubah. */
    fun clearApplied(store: GameStore): CmdResult {
        val pkg = store.downscalePkg ?: return CmdResult(true, "", "")
        return clear(pkg, store)
    }
}

object Profile {

    /**
     * Terapkan profil sebuah game: resolusi dan batas FPS. Cara yang dipakai mengikuti pengaturan:
     * - resolusi per game (Game Mode) atau seluruh layar (`wm size`);
     * - FPS per game (Game Mode) atau kunci refresh rate layar. Nilai FPS yang tidak dikenal Game Mode,
     *   atau Game Mode yang menolak, otomatis memakai kunci refresh rate.
     */
    fun apply(pkg: String, percent: Int, fps: Int, store: GameStore): CmdResult {
        val resPerGame = GameDownscale.enabled(store)
        val fpsPerGame = GameDownscale.fpsEnabled(store)
        if (!resPerGame && !fpsPerGame) {
            return DisplayController.applyProfile(percent, fps, store.scaleDensity, store)
        }

        val screen = if (resPerGame) {
            GameDownscale.dropScreenOverride(store)
            CmdResult(true, "", "")
        } else {
            DisplayController.applyResolution(percent, store.scaleDensity, store)
        }
        val gameFps = if (fpsPerGame && GameDownscale.fpsSupported(fps)) fps else 0
        val gameMode = GameDownscale.configure(pkg, if (resPerGame) percent else 100, gameFps, store)

        val needLock = fps > 0 && (gameFps == 0 || !gameMode.ok)
        val lock = if (needLock) {
            DisplayController.setRefreshRate(fps, store)
        } else {
            DisplayController.resetRefreshRate(store)
        }

        val parts = listOf(screen, gameMode, lock)
        return CmdResult(
            ok = parts.all { it.ok },
            out = parts.map { it.out }.filter { it.isNotBlank() }.joinToString("\n"),
            err = parts.map { it.err }.filter { it.isNotBlank() }.joinToString("\n"),
        )
    }
}
