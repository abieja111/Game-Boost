package com.gametuner.launcher

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.PowerManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Satu langkah rekaman Macro: ketukan, tahan, atau geseran lurus dari (x1,y1) ke (x2,y2).
 * Koordinat dalam piksel layar. [delayMs] = jeda sebelum langkah ini (dari akhir langkah sebelumnya),
 * [durMs] = lama jari menyentuh layar.
 */
data class MacroStep(
    val x1: Int,
    val y1: Int,
    val x2: Int,
    val y2: Int,
    val delayMs: Int,
    val durMs: Int,
) {
    /** True bila jari tidak bergeser (ketukan atau tahan). */
    val isTap: Boolean get() = x1 == x2 && y1 == y2
}

/** Simpan/baca rekaman sebagai teks: "x1,y1,x2,y2,jeda,durasi" dipisah titik koma. */
object MacroCodec {
    const val MAX_STEPS = 200

    fun encode(steps: List<MacroStep>): String =
        steps.take(MAX_STEPS).joinToString(";") { "${it.x1},${it.y1},${it.x2},${it.y2},${it.delayMs},${it.durMs}" }

    fun decode(text: String): List<MacroStep> {
        if (text.isBlank()) return emptyList()
        val out = ArrayList<MacroStep>()
        for (part in text.split(';')) {
            val f = part.split(',')
            if (f.size != 6) continue
            val n = f.map { it.trim().toIntOrNull() ?: return@map null }
            if (n.any { it == null }) continue
            out += MacroStep(n[0]!!, n[1]!!, n[2]!!, n[3]!!, n[4]!!.coerceAtLeast(0), n[5]!!.coerceAtLeast(1))
            if (out.size >= MAX_STEPS) break
        }
        return out
    }
}

/**
 * Lapisan layar penuh yang menangkap sentuhan saat merekam. Gerakan jari tidak sampai ke game selama
 * merekam; yang tercatat hanya jari pertama (multi-sentuh tidak didukung).
 */
private class RecordView(
    context: Context,
    private val onStroke: (x1: Int, y1: Int, x2: Int, y2: Int, downAt: Long, upAt: Long) -> Unit,
) : View(context) {

    private val d = context.resources.displayMetrics.density
    private val accent = 0xFFFF3B5C.toInt()
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3 * d
        color = accent
        strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0x55FF3B5C
    }
    private val bannerBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xE6100B22.toInt()
    }
    private val bannerStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * d
        color = accent
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13 * d
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
    }
    private val box = RectF()

    var count: Int = 0
        set(value) {
            field = value
            invalidate()
        }

    private var down = false
    private var sx = 0f
    private var sy = 0f
    private var cx = 0f
    private var cy = 0f
    private var tDown = 0L

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true
                sx = e.rawX
                sy = e.rawY
                cx = sx
                cy = sy
                tDown = e.eventTime
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> if (down) {
                cx = e.rawX
                cy = e.rawY
                invalidate()
            }
            MotionEvent.ACTION_UP -> if (down) {
                down = false
                onStroke(sx.toInt(), sy.toInt(), e.rawX.toInt(), e.rawY.toInt(), tDown, e.eventTime)
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                down = false
                invalidate()
            }
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        // Spanduk di tengah atas.
        val msg = "● MEREKAM  ·  $count langkah  ·  ketuk atau geser layar, lalu tekan ■"
        val w = text.measureText(msg) + 28 * d
        val h = 32 * d
        val left = (width - w) / 2f
        val top = 10 * d
        box.set(left, top, left + w, top + h)
        canvas.drawRoundRect(box, h / 2f, h / 2f, bannerBg)
        canvas.drawRoundRect(box, h / 2f, h / 2f, bannerStroke)
        canvas.drawText(msg, width / 2f, top + h / 2f - (text.ascent() + text.descent()) / 2f, text)

        if (down) {
            // Lokasi layar penuh = lokasi jendela ini; rawX/rawY sudah dalam koordinat layar.
            val loc = IntArray(2)
            getLocationOnScreen(loc)
            val ax = sx - loc[0]
            val ay = sy - loc[1]
            val bx = cx - loc[0]
            val by = cy - loc[1]
            canvas.drawLine(ax, ay, bx, by, ring)
            canvas.drawCircle(ax, ay, 8 * d, fill)
            canvas.drawCircle(bx, by, 24 * d, fill)
            canvas.drawCircle(bx, by, 24 * d, ring)
        }
    }
}

/**
 * Macro: rekam ketukan dan geseran di layar, lalu putar ulang otomatis (diulang sekian kali).
 *
 * Kapsul kecil yang bisa digeser berisi: slot (M1..M3), Rekam, Putar, jumlah ulangan, kecepatan,
 * Hapus slot, dan Tutup. Saat merekam, sebuah lapisan layar penuh menangkap sentuhan (game tidak
 * menerimanya); tekan ■ untuk menyimpan. Saat diputar, ketukan dikirim lewat [TapService] (cepat)
 * bila layanan aksesibilitas aktif; bila tidak, lewat `input tap`/`input swipe` melalui Shizuku/root
 * (lebih lambat, ada jeda 0,2 sampai 0,5 detik per langkah).
 * Semua fungsi publik harus dipanggil dari main thread.
 */
class MacroController(
    private val context: Context,
    private val wm: WindowManager,
    private val store: GameStore,
    private val main: Handler,
    private val onHidden: () -> Unit,
) {
    companion object {
        /** Pilihan jumlah ulangan; 0 = terus sampai dihentikan. */
        val LOOPS = listOf(1, 3, 5, 10, 0)

        /** Pilihan kecepatan putar ulang (persen); hanya jeda antar langkah yang dipercepat/diperlambat. */
        val SPEEDS = listOf(50, 100, 150, 200, 300)

        fun loopsLabel(n: Int): String = if (n == 0) "×∞" else "×$n"

        private const val LOOP_GAP_MS = 300L
        private const val START_DELAY_MS = 400L
        private const val MAX_FAILS = 6
        private const val SAME_SPOT_PX = 16
        private const val MAX_DELAY_MS = 10_000L
        private const val MAX_DUR_MS = 5_000L

        private const val WIN_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

        private val COLOR_PANEL = 0xF2100B22.toInt()
        private val COLOR_BORDER = 0xFF3A1FA0.toInt()
        private val COLOR_GREEN = 0xFF34D399.toInt()
        private val COLOR_ALERT = 0xFFFF6B5A.toInt()
        private val COLOR_REC = 0xFFFF3B5C.toInt()
        private val COLOR_MUTED = 0xFFB7A8E8.toInt()
    }

    private enum class Mode { IDLE, RECORDING, PLAYING }

    var shown: Boolean = false
        private set

    private val worker: ExecutorService = Executors.newSingleThreadExecutor()

    private var mode = Mode.IDLE

    private var pill: LinearLayout? = null
    private var pillLp: WindowManager.LayoutParams? = null
    private var slotLabel: TextView? = null
    private var recIcon: ImageView? = null
    private var playIcon: ImageView? = null
    private var loopLabel: TextView? = null
    private var speedLabel: TextView? = null
    private var trashIcon: ImageView? = null
    private var closeIcon: ImageView? = null

    // Rekaman
    private var capture: RecordView? = null
    private val rec = ArrayList<MacroStep>()
    private var lastUp = -1L

    // Pemutaran
    private var steps: List<MacroStep> = emptyList()
    private var stepIdx = 0
    private var loopsDone = 0
    private var fails = 0
    private var token = 0

    fun setShown(on: Boolean) {
        if (on == shown) return
        if (on) show() else hide(notify = true)
    }

    /** Dipanggil saat layanan overlay dihentikan. */
    fun destroy() {
        hide(notify = false)
        worker.shutdownNow()
    }

    // ----------------------------------------------------------- tampilan

    private fun show() {
        val dm = context.resources.displayMetrics

        fun icon(res: Int, pad: Int): ImageView = ImageView(context).apply {
            setImageResource(res)
            setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
        }
        fun label(minW: Int, sp: Float): TextView = TextView(context).apply {
            textSize = sp
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            minWidth = dp(minW)
        }

        val slot = label(66, 12f)
        val recI = icon(R.drawable.ic_record, 11)
        val playI = icon(R.drawable.ic_play, 10)
        val loopL = label(38, 12f)
        val speedL = label(46, 12f)
        val trashI = icon(R.drawable.ic_trash, 11)
        val closeI = icon(R.drawable.ic_close, 11).apply {
            imageTintList = ColorStateList.valueOf(Color.WHITE)
        }

        val p = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(COLOR_PANEL)
                setStroke(dp(1), COLOR_BORDER)
            }
            addView(slot, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
            addView(recI, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(playI, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(loopL, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
            addView(speedL, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
            addView(trashI, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(closeI, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
        val plp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WIN_FLAGS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (store.macroX >= 0) store.macroX else dp(8)
            y = if (store.macroY >= 0) store.macroY else dp(200)
            x = x.coerceIn(0, maxOf(0, dm.widthPixels - dp(120)))
            y = y.coerceIn(0, maxOf(0, dm.heightPixels - dp(60)))
        }
        makeDraggable(p, plp, onTap = { x -> onPillTap(x) }) {
            store.macroX = plp.x
            store.macroY = plp.y
        }

        try {
            wm.addView(p, plp)
        } catch (e: Throwable) {
            toast("Macro gagal ditampilkan: ${e.message ?: e.javaClass.simpleName}")
            return
        }

        pill = p
        pillLp = plp
        slotLabel = slot
        recIcon = recI
        playIcon = playI
        loopLabel = loopL
        speedLabel = speedL
        trashIcon = trashI
        closeIcon = closeI
        shown = true
        mode = Mode.IDLE
        render()
    }

    private fun hide(notify: Boolean) {
        if (mode == Mode.RECORDING) finishRecording(save = true)
        stopPlay()
        removeCapture()
        pill?.let { v -> runCatching { wm.removeView(v) } }
        pill = null
        pillLp = null
        slotLabel = null
        recIcon = null
        playIcon = null
        loopLabel = null
        speedLabel = null
        trashIcon = null
        closeIcon = null
        val was = shown
        shown = false
        if (notify && was) onHidden()
    }

    private fun render() {
        val idle = mode == Mode.IDLE
        val slot = store.macroSlot

        slotLabel?.apply {
            text = when (mode) {
                Mode.RECORDING -> "● ${rec.size}"
                Mode.PLAYING -> {
                    val loops = store.macroLoops
                    "▶ ${loopsDone + 1}/" + if (loops == 0) "∞" else "$loops"
                }
                Mode.IDLE -> "M$slot·${store.getMacro(slot).size}"
            }
            setTextColor(
                when (mode) {
                    Mode.RECORDING -> COLOR_REC
                    Mode.PLAYING -> COLOR_GREEN
                    Mode.IDLE -> Color.WHITE
                }
            )
        }
        recIcon?.apply {
            val on = mode == Mode.RECORDING
            setImageResource(if (on) R.drawable.ic_stop else R.drawable.ic_record)
            imageTintList = ColorStateList.valueOf(
                if (on) COLOR_REC else if (idle) COLOR_REC else COLOR_MUTED
            )
            alpha = if (mode == Mode.PLAYING) 0.4f else 1f
        }
        playIcon?.apply {
            val on = mode == Mode.PLAYING
            setImageResource(if (on) R.drawable.ic_stop else R.drawable.ic_play)
            imageTintList = ColorStateList.valueOf(if (on) COLOR_ALERT else COLOR_GREEN)
            alpha = if (mode == Mode.RECORDING) 0.4f else 1f
        }
        loopLabel?.apply {
            text = loopsLabel(store.macroLoops)
            alpha = if (idle) 1f else 0.5f
        }
        speedLabel?.apply {
            text = "${store.macroSpeed}%"
            alpha = if (idle) 1f else 0.5f
        }
        trashIcon?.apply {
            imageTintList = ColorStateList.valueOf(COLOR_MUTED)
            alpha = if (idle) 1f else 0.4f
        }
    }

    private fun onPillTap(x: Float) {
        // Cari tombol yang disentuh dari batas kanan tiap anak; sentuhan di tepi kiri dianggap slot.
        val actions = listOf<Pair<View?, () -> Unit>>(
            slotLabel to { cycleSlot() },
            recIcon to { onRecordTap() },
            playIcon to { onPlayTap() },
            loopLabel to { cycleLoops() },
            speedLabel to { cycleSpeed() },
            trashIcon to { clearSlot() },
            closeIcon to { hide(notify = true) },
        )
        for ((v, act) in actions) {
            if (v != null && x < v.right) {
                act()
                return
            }
        }
        hide(notify = true)
    }

    private fun cycleSlot() {
        if (mode != Mode.IDLE) return
        store.macroSlot = store.macroSlot % GameStore.MACRO_SLOTS + 1
        render()
    }

    private fun cycleLoops() {
        if (mode != Mode.IDLE) return
        val i = LOOPS.indexOf(store.macroLoops)
        store.macroLoops = LOOPS[(i + 1) % LOOPS.size]
        render()
    }

    private fun cycleSpeed() {
        if (mode != Mode.IDLE) return
        val i = SPEEDS.indexOf(store.macroSpeed)
        store.macroSpeed = SPEEDS[(i + 1) % SPEEDS.size]
        render()
    }

    private fun clearSlot() {
        if (mode != Mode.IDLE) return
        val slot = store.macroSlot
        if (store.getMacro(slot).isEmpty()) {
            toast("Slot M$slot sudah kosong.")
            return
        }
        store.setMacro(slot, emptyList())
        toast("Rekaman M$slot dihapus.")
        render()
    }

    // ------------------------------------------------------------ merekam

    private fun onRecordTap() {
        when (mode) {
            Mode.IDLE -> startRecording()
            Mode.RECORDING -> finishRecording(save = true)
            Mode.PLAYING -> Unit
        }
    }

    private fun startRecording() {
        if (mode != Mode.IDLE || !shown) return
        rec.clear()
        lastUp = -1L
        val cv = RecordView(context) { x1, y1, x2, y2, downAt, upAt -> onStroke(x1, y1, x2, y2, downAt, upAt) }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        cv.setBackgroundColor(0x33000000)
        try {
            wm.addView(cv, lp)
        } catch (e: Throwable) {
            toast("Perekam gagal ditampilkan: ${e.message ?: e.javaClass.simpleName}")
            return
        }
        capture = cv
        mode = Mode.RECORDING

        // Kapsul harus berada di atas lapisan perekam supaya tombol ■ tetap bisa ditekan.
        val p = pill
        val plp = pillLp
        if (p != null && plp != null) {
            runCatching { wm.removeView(p) }
            runCatching { wm.addView(p, plp) }
        }
        render()
    }

    private fun onStroke(x1: Int, y1: Int, x2: Int, y2: Int, downAt: Long, upAt: Long) {
        if (mode != Mode.RECORDING) return
        val same = abs(x2 - x1) < SAME_SPOT_PX && abs(y2 - y1) < SAME_SPOT_PX
        val delay = if (lastUp < 0) 0L else (downAt - lastUp).coerceIn(0L, MAX_DELAY_MS)
        val dur = (upAt - downAt).coerceIn(10L, MAX_DUR_MS)
        lastUp = upAt
        rec += MacroStep(
            x1, y1,
            if (same) x1 else x2,
            if (same) y1 else y2,
            delay.toInt(), dur.toInt()
        )
        capture?.count = rec.size
        slotLabel?.text = "● ${rec.size}"
        if (rec.size >= MacroCodec.MAX_STEPS) {
            toast("Batas ${MacroCodec.MAX_STEPS} langkah tercapai, rekaman disimpan.")
            finishRecording(save = true)
        }
    }

    private fun finishRecording(save: Boolean) {
        if (mode != Mode.RECORDING) return
        mode = Mode.IDLE
        removeCapture()
        val slot = store.macroSlot
        if (save && rec.isNotEmpty()) {
            store.setMacro(slot, rec.toList())
            toast("Tersimpan di M$slot: ${rec.size} langkah.")
        } else if (save) {
            toast("Tidak ada yang direkam, M$slot tidak diubah.")
        }
        rec.clear()
        render()
    }

    private fun removeCapture() {
        capture?.let { v -> runCatching { wm.removeView(v) } }
        capture = null
    }

    // ----------------------------------------------------------- memutar

    private fun onPlayTap() {
        when (mode) {
            Mode.IDLE -> startPlay()
            Mode.PLAYING -> stopPlay()
            Mode.RECORDING -> Unit
        }
    }

    private fun startPlay() {
        if (mode != Mode.IDLE || !shown) return
        val slot = store.macroSlot
        val s = store.getMacro(slot)
        if (s.isEmpty()) {
            toast("Slot M$slot masih kosong. Tekan ● untuk merekam dulu.")
            return
        }
        if (TapService.instance != null) {
            beginPlay(s)
            return
        }
        // Tanpa layanan aksesibilitas, ketukan dikirim lewat Shizuku/root; pastikan aksesnya ada.
        try {
            worker.execute {
                val access = ShellRunner.detect()
                main.post {
                    if (!shown) return@post
                    if (access == ShellRunner.Mode.NONE) {
                        toast("Nyalakan Layanan Aksesibilitas atau Shizuku dulu (Pengaturan, kartu Macro).")
                    } else {
                        beginPlay(s)
                    }
                }
            }
        } catch (_: Throwable) {
            // worker sudah dimatikan
        }
    }

    private fun beginPlay(s: List<MacroStep>) {
        if (mode != Mode.IDLE || !shown) return
        steps = s
        stepIdx = 0
        loopsDone = 0
        fails = 0
        mode = Mode.PLAYING
        render()
        scheduleStep(START_DELAY_MS)
    }

    private fun stopPlay() {
        if (mode != Mode.PLAYING) return
        mode = Mode.IDLE
        token++
        main.removeCallbacks(stepRunner)
        render()
    }

    private val stepRunner = Runnable { runStep() }

    private fun scheduleStep(delayMs: Long) {
        main.removeCallbacks(stepRunner)
        main.postDelayed(stepRunner, delayMs)
    }

    private fun scaledDelay(ms: Int): Long =
        (ms.toLong() * 100L / store.macroSpeed.coerceIn(10, 1000)).coerceAtLeast(0L)

    private fun runStep() {
        if (mode != Mode.PLAYING) return
        val pm = context.getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isInteractive) {
            stopPlay()
            return
        }
        val st = steps.getOrNull(stepIdx)
        if (st == null) {
            stopPlay()
            return
        }
        val my = ++token
        val dur = st.durMs.toLong().coerceAtLeast(1L)

        val svc = TapService.instance
        if (svc != null) {
            val accepted = svc.gesture(
                st.x1.toFloat(), st.y1.toFloat(), st.x2.toFloat(), st.y2.toFloat(), dur
            ) { done -> finishStep(my, done) }
            if (!accepted) {
                finishStep(my, false)
                return
            }
        } else {
            val cmd = if (st.isTap && dur < 120L) {
                "input tap ${st.x1} ${st.y1}"
            } else {
                "input swipe ${st.x1} ${st.y1} ${st.x2} ${st.y2} $dur"
            }
            try {
                worker.execute {
                    val r = ShellRunner.exec(cmd)
                    main.post { finishStep(my, r.ok) }
                }
            } catch (_: Throwable) {
                finishStep(my, false)
                return
            }
        }
        // Pengaman bila sistem tidak pernah memberi kabar selesai.
        main.postDelayed({ finishStep(my, false) }, dur + 2500L)
    }

    private fun finishStep(my: Int, ok: Boolean) {
        if (my != token || mode != Mode.PLAYING) return
        token++

        if (ok) {
            fails = 0
        } else {
            fails++
            if (fails >= MAX_FAILS) {
                stopPlay()
                toast("Macro berhenti: ketukan gagal terus. Cek Layanan Aksesibilitas atau Shizuku.")
                return
            }
        }

        stepIdx++
        if (stepIdx >= steps.size) {
            loopsDone++
            val loops = store.macroLoops
            if (loops > 0 && loopsDone >= loops) {
                stopPlay()
                toast("Macro selesai.")
                return
            }
            stepIdx = 0
            render()
            scheduleStep(LOOP_GAP_MS)
            return
        }
        scheduleStep(scaledDelay(steps[stepIdx].delayMs))
    }

    // ------------------------------------------------------------ helpers

    /**
     * Geser jendela [window] dengan menyentuhnya. Ketukan singkat memanggil [onTap] dengan posisi x
     * sentuhan (relatif terhadap jendela); setelah digeser, [onDropped] dipanggil.
     */
    private fun makeDraggable(
        window: View,
        lp: WindowManager.LayoutParams,
        onTap: (Float) -> Unit,
        onDropped: () -> Unit,
    ) {
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        window.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        runCatching { wm.updateViewLayout(window, lp) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) onDropped() else onTap(e.x)
                    true
                }
                else -> false
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
    }

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()
}
