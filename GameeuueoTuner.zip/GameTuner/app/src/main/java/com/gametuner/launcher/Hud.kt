package com.gametuner.launcher

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.PowerManager
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs

/** Angka yang bisa ditampilkan HUD Mini. Urutan enum = urutan tampil. */
enum class HudItem(val key: String, val title: String) {
    FPS("fps", "FPS"),
    TEMP("temp", "Suhu"),
    BATT("batt", "Baterai"),
    CPU("cpu", "CPU"),
    GPU("gpu", "GPU"),
    RAM("ram", "RAM");

    companion object {
        const val FPS_ONLY = "fps"
        const val FULL = "fps,temp,batt,cpu,ram"

        /** Baca daftar tersimpan (dipisah koma). Kosong atau rusak berarti hanya FPS. */
        fun parse(csv: String?): List<HudItem> {
            val keys = csv.orEmpty().split(',').map { it.trim() }.toSet()
            val items = entries.filter { it.key in keys }
            return items.ifEmpty { listOf(FPS) }
        }

        fun toCsv(items: Collection<HudItem>): String =
            entries.filter { it in items }.joinToString(",") { it.key }
    }
}

/**
 * HUD Mini: pil kecil melayang di atas game: logo NX, angka FPS, label kualitas (Smooth / Normal /
 * Laggy) dan tombol X. Angka pilihan lain (suhu, baterai, CPU, GPU, RAM) ikut tampil di sebelahnya.
 * Geser untuk memindahkan; ketuk X atau tekan lama untuk menutup.
 *
 * Angka diambil tiap beberapa detik; yang tidak bisa dibaca HP ini tampil "—", bukan angka karangan.
 * FPS diukur pada aplikasi yang sedang di depan, jadi HUD juga berguna di luar game dari Nexus.
 * Semua fungsi publik harus dipanggil dari main thread.
 */
class HudController(
    private val context: Context,
    private val wm: WindowManager,
    private val store: GameStore,
    private val main: Handler,
    private val onHidden: () -> Unit,
) {
    companion object {
        private const val TICK_MS = 2000L
        private const val LONG_PRESS_MS = 700L

        private const val WIN_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

        private val COLOR_BG = 0xE60A0414.toInt()
        private val COLOR_BORDER = 0xFF8B2CF5.toInt()
        private val COLOR_SMOOTH = 0xFFA855F7.toInt()
        private val COLOR_FPS_UNIT = 0xFFC9C2E6.toInt()
        private val COLOR_GREEN = 0xFF34D399.toInt()
        private val COLOR_AMBER = 0xFFFFA94D.toInt()
        private val COLOR_ALERT = 0xFFFF6B5A.toInt()
        private val COLOR_ACCENT = 0xFFA78BFA.toInt()
        private val COLOR_MUTED = 0xFFA79FC4.toInt()
    }

    /** Teks dan warna satu angka HUD. */
    private class Reading(val text: String, val color: Int, val fps: Int? = null)

    var shown: Boolean = false
        private set

    private val worker: ExecutorService = Executors.newSingleThreadExecutor()

    private var box: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var items: List<HudItem> = emptyList()
    private val views = mutableMapOf<HudItem, TextView>()

    // Bagian FPS (hanya ada bila FPS dipilih): angka, dan chip kualitas di sebelahnya.
    private var fpsView: TextView? = null
    private var chipText: TextView? = null
    private var chipIcon: ImageView? = null
    private var chipBg: GradientDrawable? = null

    @Volatile
    private var measuring = false

    // Sentuhan: geser memindahkan, tekan lama menutup.
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    fun setShown(on: Boolean) {
        if (on == shown) return
        if (on) show() else hide(notify = true)
    }

    /** Dipanggil saat layanan overlay dihentikan. */
    fun destroy() {
        hide(notify = false)
        worker.shutdownNow()
    }

    // ----------------------------------------------------------- tampilan

    private fun show() {
        val b = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(8), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(COLOR_BG)
                setStroke(dp(2), COLOR_BORDER)
            }
        }
        val params = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WIN_FLAGS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (store.hudX >= 0) store.hudX else dp(8)
            y = if (store.hudY >= 0) store.hudY else dp(28)
        }
        installTouch(b, params)

        try {
            wm.addView(b, params)
        } catch (e: Throwable) {
            Toast.makeText(
                context,
                "HUD gagal ditampilkan: ${e.message ?: e.javaClass.simpleName}",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        box = b
        lp = params
        shown = true
        rebuild(HudItem.parse(store.hudItems))
        main.removeCallbacks(tick)
        main.post(tick)
    }

    private fun hide(notify: Boolean) {
        main.removeCallbacks(tick)
        main.removeCallbacks(longPress)
        box?.let { v -> runCatching { wm.removeView(v) } }
        box = null
        lp = null
        views.clear()
        fpsView = null
        chipText = null
        chipIcon = null
        chipBg = null
        items = emptyList()
        val was = shown
        shown = false
        if (notify && was) onHidden()
    }

    /** Susun ulang pil sesuai angka yang dipilih: [NX] | FPS [chip] | angka lain | [X]. */
    private fun rebuild(wanted: List<HudItem>) {
        val b = box ?: return
        items = wanted
        views.clear()
        fpsView = null
        chipText = null
        chipIcon = null
        chipBg = null
        b.removeAllViews()

        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        b.addView(
            ImageView(context).apply {
                setImageResource(R.drawable.hud_nx)
                scaleType = ImageView.ScaleType.FIT_CENTER
            },
            LinearLayout.LayoutParams(dp(34), dp(20))
        )
        b.addView(
            View(context).apply { setBackgroundColor(0x66FFFFFF) },
            LinearLayout.LayoutParams(dp(1), dp(22)).apply {
                marginStart = dp(8)
                marginEnd = dp(10)
            }
        )

        wanted.forEach { item ->
            if (item == HudItem.FPS) {
                val tv = TextView(context).apply {
                    typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
                    maxLines = 1
                    includeFontPadding = false
                }
                fpsView = tv
                b.addView(tv, LinearLayout.LayoutParams(wrap, wrap))
                b.addView(buildChip(), LinearLayout.LayoutParams(wrap, dp(24)).apply { marginStart = dp(8) })
                applyFps(null)
            } else {
                val tv = TextView(context).apply {
                    text = "—"
                    textSize = 12f
                    typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                    setTextColor(COLOR_MUTED)
                    maxLines = 1
                }
                views[item] = tv
                b.addView(tv, LinearLayout.LayoutParams(wrap, wrap).apply { marginStart = dp(10) })
            }
        }

        b.addView(
            ImageView(context).apply {
                setImageResource(R.drawable.ic_close)
                setColorFilter(0xFFD8D0F0.toInt())
                setPadding(dp(6), dp(6), dp(6), dp(6))
                contentDescription = "Tutup HUD"
                setOnClickListener { hide(notify = true) }
            },
            LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginStart = dp(6) }
        )
    }

    /** Chip kualitas: ikon denyut + label ("Smooth", "Normal", "Laggy"). */
    private fun buildChip(): LinearLayout {
        val bg = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(0x33000000)
            setStroke(dp(1), COLOR_MUTED)
        }
        chipBg = bg
        val icon = ImageView(context).apply {
            setImageResource(R.drawable.ic_pulse)
            setColorFilter(COLOR_MUTED)
        }
        chipIcon = icon
        val label = TextView(context).apply {
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            includeFontPadding = false
            setTextColor(COLOR_MUTED)
        }
        chipText = label
        return LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = bg
            setPadding(dp(8), 0, dp(10), 0)
            addView(icon, LinearLayout.LayoutParams(dp(14), dp(14)))
            addView(
                label,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { marginStart = dp(5) }
            )
        }
    }

    /** Isi angka FPS dan chip kualitas. null = belum bisa diukur. */
    private fun applyFps(fps: Int?) {
        val tv = fpsView ?: return
        val number = fps?.toString() ?: "—"
        val text = SpannableStringBuilder(number).apply {
            setSpan(AbsoluteSizeSpan(18, true), 0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            setSpan(
                ForegroundColorSpan(if (fps == null) COLOR_MUTED else 0xFFFFFFFF.toInt()),
                0, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            val start = length
            append(" FPS")
            setSpan(AbsoluteSizeSpan(10, true), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            setSpan(ForegroundColorSpan(COLOR_FPS_UNIT), start, length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        tv.text = text

        val (label, color) = when {
            fps == null -> "Mengukur" to COLOR_MUTED
            fps >= 55 -> "Smooth" to COLOR_SMOOTH
            fps >= 30 -> "Normal" to COLOR_AMBER
            else -> "Laggy" to COLOR_ALERT
        }
        chipText?.apply {
            this.text = label
            setTextColor(color)
        }
        chipIcon?.setColorFilter(color)
        chipBg?.setStroke(dp(1), color)
    }

    // ------------------------------------------------------------ sentuhan

    private val longPress = Runnable {
        if (shown && !moved) {
            Toast.makeText(context, "HUD ditutup", Toast.LENGTH_SHORT).show()
            hide(notify = true)
        }
    }

    private fun installTouch(view: LinearLayout, params: WindowManager.LayoutParams) {
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = params.x
                    startY = params.y
                    moved = false
                    main.postDelayed(longPress, LONG_PRESS_MS)
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) {
                        moved = true
                        main.removeCallbacks(longPress)
                    }
                    if (moved) {
                        val dm = context.resources.displayMetrics
                        params.x = (startX + dx.toInt()).coerceIn(0, maxOf(0, dm.widthPixels - view.width))
                        params.y = (startY + dy.toInt()).coerceIn(0, maxOf(0, dm.heightPixels - view.height))
                        runCatching { wm.updateViewLayout(view, params) }
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(longPress)
                    if (moved) {
                        store.hudX = params.x
                        store.hudY = params.y
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ------------------------------------------------------------ pengukuran

    private val tick = object : Runnable {
        override fun run() {
            if (!shown) return
            // Pilihan angka bisa diubah dari Pengaturan selagi HUD tampil.
            val wanted = HudItem.parse(store.hudItems)
            if (wanted != items) rebuild(wanted)
            sample(wanted)
            main.postDelayed(this, TICK_MS)
        }
    }

    private fun sample(wanted: List<HudItem>) {
        if (measuring) return
        // Layar mati: tidak ada yang perlu diukur.
        val pm = context.getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isInteractive) return
        measuring = true
        try {
            worker.execute {
                val out = try {
                    readAll(wanted)
                } catch (_: Throwable) {
                    emptyMap()
                }
                main.post {
                    measuring = false
                    if (!shown) return@post
                    out.forEach { (item, r) ->
                        if (item == HudItem.FPS) {
                            applyFps(r.fps)
                        } else {
                            views[item]?.apply {
                                text = r.text
                                setTextColor(r.color)
                            }
                        }
                    }
                }
            }
        } catch (_: Throwable) {
            measuring = false // worker sudah dimatikan
        }
    }

    /** Dijalankan di thread background: hanya mengukur angka yang dipilih. */
    private fun readAll(wanted: List<HudItem>): Map<HudItem, Reading> {
        val out = mutableMapOf<HudItem, Reading>()
        val stats = if (wanted.any { it == HudItem.TEMP || it == HudItem.BATT || it == HudItem.RAM }) {
            SystemStats.read(context)
        } else {
            null
        }

        for (item in wanted) {
            out[item] = when (item) {
                HudItem.FPS -> {
                    // FPS aplikasi yang sedang di depan; bila tidak terdeteksi, pakai game terakhir dari Nexus.
                    val pkg = ForegroundWatcher.foregroundPackage() ?: store.currentGame
                    val fps = pkg?.let { FpsMeter.measure(it) }
                    if (fps != null) Reading("$fps FPS", COLOR_GREEN, fps) else Reading("— FPS", COLOR_MUTED)
                }
                HudItem.TEMP -> stats?.let {
                    val c = when {
                        it.tempC >= 44f -> COLOR_ALERT
                        it.tempC >= 38f -> COLOR_AMBER
                        else -> COLOR_GREEN
                    }
                    Reading(String.format(java.util.Locale.US, "%.0f°C", it.tempC), c)
                } ?: Reading("—", COLOR_MUTED)
                HudItem.BATT -> stats?.let {
                    val c = if (it.batteryPct <= 15 && !it.charging) COLOR_ALERT else COLOR_GREEN
                    Reading("${it.batteryPct}%" + if (it.charging) "⚡" else "", c)
                } ?: Reading("—", COLOR_MUTED)
                HudItem.CPU -> LoadMeter.cpuPercent()?.let { loadReading("CPU", it) }
                    ?: Reading("CPU —", COLOR_MUTED)
                HudItem.GPU -> LoadMeter.gpuPercent()?.let { loadReading("GPU", it) }
                    ?: Reading("GPU —", COLOR_MUTED)
                HudItem.RAM -> stats?.let {
                    if (it.ramTotalMb > 0) {
                        val used = ((it.ramTotalMb - it.ramFreeMb) * 100 / it.ramTotalMb).toInt().coerceIn(0, 100)
                        // RAM wajar terisi banyak (cache), jadi baru diwarnai saat benar-benar penuh.
                        val c = when {
                            used >= 93 -> COLOR_ALERT
                            used >= 85 -> COLOR_AMBER
                            else -> COLOR_ACCENT
                        }
                        Reading("RAM $used%", c)
                    } else {
                        null
                    }
                } ?: Reading("RAM —", COLOR_MUTED)
            }
        }
        return out
    }

    private fun loadReading(name: String, percent: Int): Reading {
        val c = when {
            percent >= 90 -> COLOR_ALERT
            percent >= 70 -> COLOR_AMBER
            else -> COLOR_ACCENT
        }
        return Reading("$name $percent%", c)
    }

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()
}
