package com.gametuner.launcher

// Fitur Trigger (auto tap) sudah diganti oleh Macro (lihat Macro.kt).
// File ini sengaja dikosongkan: build memakai semua zip lama di repo, dan zip tidak bisa menghapus file,
// jadi Trigger.kt versi lama harus ditimpa dengan file kosong ini. Aman dihapus kalau Trigger.kt lama sudah
// tidak ada di repo.
