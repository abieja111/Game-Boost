package com.gametuner.launcher

import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

/**
 * Kerangka aplikasi. HOME dan BASE memakai kerangka launcher (Game Lobby / Super Base);
 * halaman lain tampil penuh dengan tombol kembali.
 */
@Composable
fun NexusApp(ui: UiState, act: AppActions, rates: List<Int>) {
    BackHandler(enabled = ui.tab != Tab.HOME) { ui.tab = Tab.HOME }
    val back = { ui.tab = Tab.HOME }

    Box(
        Modifier
            .fillMaxSize()
            .background(Nx.Bg)
            .appBackdrop()
    ) {
        when (ui.tab) {
            Tab.HOME, Tab.BASE -> LobbyFrame(ui, act, rates)
            Tab.GAMES -> SubPage("Semua Aplikasi", back) { GamesScreen(ui, act, rates) }
            Tab.STATS -> SubPage("Statistik", back) { ScrollPage { StatsScreen(ui, act) } }
            Tab.SETTINGS -> SubPage("Pengaturan", back) { ScrollPage { SettingsScreen(ui, act) } }
            Tab.ABOUT -> SubPage("Tentang", back) { ScrollPage { AboutScreen() } }
        }
    }
}

@Composable
private fun ScrollPage(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content,
    )
}

// --------------------------------------------------------------- helpers

private fun describeDisplay(i: DisplayInfo, hz: Int): String {
    val size = if (i.isOverridden) {
        "${i.physW}×${i.physH} → ${i.curW}×${i.curH} (${i.currentPercent}%)"
    } else {
        "${i.physW}×${i.physH} (asli)"
    }
    return if (hz > 0) "$size · $hz Hz" else size
}

private fun accessSubtitle(st: SysStatus): String = when {
    st.mode == ShellRunner.Mode.SHIZUKU -> "Shizuku aktif. Fitur maksimal tersedia."
    st.mode == ShellRunner.Mode.ROOT -> "Root aktif. Fitur maksimal tersedia."
    st.shizuku == ShizukuState.NOT_INSTALLED -> "Shizuku belum dipasang. Ketuk untuk membuka halaman unduh."
    st.shizuku == ShizukuState.NOT_RUNNING -> "Shizuku belum dijalankan. Ketuk untuk membukanya."
    st.shizuku == ShizukuState.NEED_PERMISSION -> "Shizuku jalan. Ketuk untuk memberi izin."
    st.shizuku == ShizukuState.DENIED -> "Izin ditolak. Aktifkan di Shizuku, Aplikasi terotorisasi."
    else -> "Diperlukan untuk fitur maksimal"
}

// ---------------------------------------------------------------- Beranda

private enum class HomeDialog { LAYAR, DENSITY, MODE_MAIN }

@Composable
fun HomeScreen(ui: UiState, act: AppActions) {
    val live = rememberLive()
    val st = ui.status
    var dialog by remember { mutableStateOf<HomeDialog?>(null) }

    StatusCard(ui, live)

    SectionCard("Akses & Izin", R.drawable.ic_shield) {
        SettingRow(
            icon = R.drawable.ic_crown,
            title = "Akses Sistem Root / Shizuku",
            subtitle = accessSubtitle(st),
            onClick = { if (st.hasAccess) act.recheck() else act.fixAccess() },
        ) {
            NxSwitch(st.hasAccess) { if (st.hasAccess) act.recheck() else act.fixAccess() }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_overlay,
            title = "Izin Pop Up Overlay",
            subtitle = "Izinkan overlay di atas aplikasi lain",
            onClick = { act.openOverlaySettings() },
        ) {
            NxSwitch(ui.overlayGranted) { act.openOverlaySettings() }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_monitor,
            title = if (st.hasAccess) "Layar" else "Layar Butuh Akses Sistem",
            subtitle = st.info?.let { describeDisplay(it, st.pinnedHz) }
                ?: "Untuk menyesuaikan tampilan game",
            onClick = { dialog = HomeDialog.LAYAR },
        ) {
            PillButton("Atur") { dialog = HomeDialog.LAYAR }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_grid,
            title = "Sesuaikan Density",
            subtitle = if (ui.scaleDensity) "Aktif: ukuran UI tetap normal saat resolusi turun"
            else "Mati: UI mengecil mengikuti resolusi",
            onClick = { dialog = HomeDialog.DENSITY },
        ) {
            PillButton("Atur") { dialog = HomeDialog.DENSITY }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_refresh,
            title = "Reset Otomatis Saat Game Ditutup",
            subtitle = "Mengembalikan pengaturan setelah game selesai",
            onClick = { ui.updateAutoReset(!ui.autoReset) },
        ) {
            NxSwitch(ui.autoReset) { ui.updateAutoReset(it) }
        }
    }

    SectionCard("Mode Game", R.drawable.ic_gamepad) {
        SettingRow(
            icon = R.drawable.ic_speed,
            title = "Mode Main",
            subtitle = "Terapkan resolusi & FPS pilihanmu saat game dibuka",
            onClick = { ui.updatePlayOptimize(!ui.playOptimize) },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clickable { dialog = HomeDialog.MODE_MAIN }.padding(4.dp)) {
                    NxIcon(R.drawable.ic_info, tint = Nx.PurpleLight, size = 20.dp)
                }
                Spacer(Modifier.width(8.dp))
                RadioDot(ui.playOptimize) { ui.updatePlayOptimize(!ui.playOptimize) }
            }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_focus,
            title = "Mode Fokus (Jangan Ganggu)",
            subtitle = "Blokir notifikasi dan gangguan saat bermain",
            onClick = { ui.updateFocusMode(!ui.focusMode) },
        ) {
            RadioDot(ui.focusMode) { ui.updateFocusMode(!ui.focusMode) }
        }
    }

    SectionCard("Penghemat & Peringatan", R.drawable.ic_battery) {
        SettingRow(
            icon = R.drawable.ic_leaf,
            iconTint = Nx.Green,
            title = "Matikan Mode Hemat Baterai",
            subtitle = "Agar performa tidak terbatas",
            onClick = { ui.updateBatterySaverOff(!ui.batterySaverOff) },
        ) {
            NxSwitch(ui.batterySaverOff) { ui.updateBatterySaverOff(it) }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_warning,
            title = "Peringatan Panas",
            subtitle = "Notifikasi jika suhu HP mencapai batas tertentu",
        ) {
            HeatDropdown(ui.heatWarnC, listOf(0, 40, 42, 44, 46, 48)) { ui.updateHeatWarn(it) }
        }
    }

    SectionCard("Suhu & RAM (Boost)", R.drawable.ic_rocket) {
        SettingRow(
            icon = R.drawable.ic_memory,
            title = "Boost Otomatis",
            subtitle = "Bersihkan RAM saat RAM bebas menipis selama main",
            onClick = { ui.updateAutoBoost(!ui.autoBoost) },
        ) {
            NxSwitch(ui.autoBoost) { ui.updateAutoBoost(it) }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_bolt,
            title = "Boost Sekarang",
            subtitle = "Tutup aplikasi latar untuk melegakan RAM",
        ) {
            PillButton(
                text = if (ui.boosting) "…" else "Boost",
                icon = null,
            ) { if (!ui.boosting) act.boost() }
        }
    }

    when (dialog) {
        HomeDialog.LAYAR -> NxDialog(
            title = "Layar",
            onDismiss = { dialog = null },
            confirmText = if (st.hasAccess) "Reset Layar" else null,
            onConfirm = {
                act.resetDisplay()
                dialog = null
            },
        ) {
            Text(
                st.info?.let { describeDisplay(it, st.pinnedHz) }
                    ?: "Butuh akses sistem (Shizuku atau root).",
                color = Nx.Text,
            )
            Text(
                "Resolusi dan refresh rate diubah otomatis saat game diluncurkan dari Game Lobby " +
                    "atau lewat bubble. Tombol Reset mengembalikan semuanya ke bawaan layar.",
                fontSize = 13.sp,
            )
        }

        HomeDialog.DENSITY -> NxDialog(
            title = "Sesuaikan Density",
            onDismiss = { dialog = null },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Skalakan density ikut resolusi",
                    color = Nx.Text,
                    modifier = Modifier.weight(1f),
                )
                NxSwitch(ui.scaleDensity) { ui.updateScaleDensity(it) }
            }
            Text(
                "Aktif: ukuran UI dan teks tetap normal saat resolusi turun, game tampil lebih " +
                    "ringan tanpa membuat tombol mengecil. Mati: hanya resolusi yang turun, " +
                    "UI ikut mengecil.",
                fontSize = 13.sp,
            )
        }

        HomeDialog.MODE_MAIN -> NxDialog(
            title = "Mode Main",
            onDismiss = { dialog = null },
        ) {
            Text(
                "Saat aktif, resolusi dan batas FPS yang kamu pilih untuk sebuah game langsung " +
                    "diterapkan sebelum game dibuka. Saat mati, game dibuka apa adanya " +
                    "(bubble pop-up tetap muncul).",
                fontSize = 13.sp,
            )
        }

        null -> Unit
    }
}

@Composable
private fun StatusCard(ui: UiState, live: Live) {
    val st = ui.status
    val ready = st.hasAccess && ui.overlayGranted
    val hint = when {
        !st.hasAccess -> "Akses sistem belum aktif"
        !ui.overlayGranted -> "Izin overlay belum aktif"
        else -> ""
    }
    Column(
        Modifier
            .fillMaxWidth()
            .nxCard(22.dp)
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .border(2.dp, Nx.Purple, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                NxIcon(R.drawable.ic_gamepad, tint = Nx.PurpleLight, size = 32.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Status", color = Nx.Text, fontSize = 14.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (ready) "Siap Digunakan" else "Belum Siap",
                        color = if (ready) Nx.PurpleLight else Nx.Amber,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.width(8.dp))
                    NxIcon(
                        if (ready) R.drawable.ic_check_circle else R.drawable.ic_warning,
                        tint = if (ready) Nx.Green else Nx.Amber,
                        size = 20.dp,
                    )
                }
                if (hint.isNotEmpty()) {
                    Text(hint, color = Nx.Amber, fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Nx.Divider)
        )
        Spacer(Modifier.height(12.dp))

        val s = live.stats
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            StatColumn(
                R.drawable.ic_bolt, "Hz Layar",
                if (live.hz > 0) "${live.hz}" else "—",
                Nx.Text, Nx.PurpleLight, Modifier.weight(1f),
            )
            VDivider()
            StatColumn(
                R.drawable.ic_thermo, "Suhu HP",
                "%.0f°C".format(java.util.Locale.US, s.tempC),
                tempColor(s.tempC), Nx.Red, Modifier.weight(1f),
            )
            VDivider()
            StatColumn(
                R.drawable.ic_battery, "Baterai",
                "${s.batteryPct}%",
                batteryColor(s.batteryPct), Nx.Green, Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun StatColumn(
    icon: Int,
    label: String,
    value: String,
    valueColor: Color,
    iconTint: Color,
    modifier: Modifier,
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NxIcon(icon, tint = iconTint, size = 16.dp)
            Spacer(Modifier.width(4.dp))
            Text(label, color = Nx.Text, fontSize = 12.sp)
        }
        Spacer(Modifier.height(2.dp))
        Text(value, color = valueColor, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun VDivider() {
    Box(
        Modifier
            .width(1.dp)
            .height(44.dp)
            .background(Nx.Divider)
    )
}

// ------------------------------------------------------------------- Game

@Composable
fun GamesScreen(ui: UiState, act: AppActions, rates: List<Int>) {
    var showAll by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<GameApp?>(null) }

    val games = ui.apps.filter { it.isGame }
    val shown = if (showAll || games.isEmpty()) ui.apps else games

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (games.isEmpty()) "Semua Aplikasi" else "Game",
                        color = Nx.Text,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        "Ketuk game untuk atur resolusi & FPS, lalu luncurkan",
                        color = Nx.Muted,
                        fontSize = 12.sp,
                    )
                }
                if (games.isNotEmpty()) {
                    Text("Semua", color = Nx.Muted, fontSize = 12.sp)
                    Spacer(Modifier.width(8.dp))
                    NxSwitch(showAll) { showAll = it }
                }
            }
        }
        if (ui.apps.isEmpty()) {
            item { Text("Memuat daftar aplikasi…", color = Nx.Muted) }
        }
        items(shown, key = { it.pkg }) { app ->
            GameRow(app, ui.scaleOf(app.pkg), ui.fpsOf(app.pkg)) { selected = app }
        }
    }

    selected?.let { app ->
        ScaleDialog(
            app = app,
            ui = ui,
            rates = rates,
            onDismiss = { selected = null },
            onLaunch = { percent, fps ->
                selected = null
                act.launchGame(app, percent, fps)
            },
        )
    }
}

@Composable
private fun GameRow(app: GameApp, scale: Int, fps: Int, onClick: () -> Unit) {
    val parts = buildList {
        if (scale < 100) add("Resolusi ${DisplayController.scaleLabel(scale)}")
        if (fps > 0) add("$fps Hz")
    }
    Row(
        Modifier
            .fillMaxWidth()
            .nxCard(16.dp, Nx.BorderSoft)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = null,
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp)),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                app.label,
                color = Nx.Text,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                if (parts.isEmpty()) "Pengaturan asli" else parts.joinToString(" · "),
                color = if (parts.isEmpty()) Nx.Muted else Nx.PurpleLight,
                fontSize = 12.sp,
            )
        }
        NxIcon(R.drawable.ic_chevron_right, tint = Nx.Muted, size = 20.dp)
    }
}

@Composable
internal fun ScaleDialog(
    app: GameApp,
    ui: UiState,
    rates: List<Int>,
    onDismiss: () -> Unit,
    onLaunch: (Int, Int) -> Unit,
) {
    val savedScale = ui.scaleOf(app.pkg)
    val savedFps = ui.fpsOf(app.pkg)
    var scalePick by remember {
        mutableIntStateOf(DisplayController.PRESETS.minByOrNull { abs(it - savedScale) } ?: 100)
    }
    val fpsOptions = GameDownscale.fpsOptions(rates, ui.perGameFps)
    var fpsPick by remember { mutableIntStateOf(if (savedFps in fpsOptions) savedFps else 0) }
    val info = ui.status.info

    NxDialog(
        title = app.label,
        onDismiss = onDismiss,
        confirmText = "Luncurkan",
        onConfirm = { onLaunch(scalePick, fpsPick) },
    ) {
        Text("Resolusi render", color = Nx.Text, fontWeight = FontWeight.SemiBold)
        ChipGrid(
            items = DisplayController.PRESETS,
            selected = scalePick,
            columns = 4,
            label = { DisplayController.scaleLabel(it) },
        ) { scalePick = it }

        val perGame = ui.perGameResolution && GameDownscale.available
        val t = info?.let { DisplayController.target(it, scalePick, ui.scaleDensity, ui.baseDpiFor(it)) }
        Text(
            when {
                perGame && scalePick >= 100 -> "Resolusi game: asli"
                perGame -> "Hanya game ini yang turun ke ${DisplayController.scaleLabel(scalePick)}. " +
                    "Layar dan aplikasi lain tidak berubah."
                t != null -> "Hasil: ${t.w}×${t.h} @${t.dpi}dpi"
                else -> "Pratinjau butuh akses sistem"
            },
            fontSize = 12.sp,
        )

        if (fpsOptions.size > 1) {
            Text(
                if (ui.perGameFps && GameDownscale.available) "Batas FPS (hanya game ini)" else "Batas FPS (refresh rate)",
                color = Nx.Text,
                fontWeight = FontWeight.SemiBold,
            )
            ChipGrid(
                items = listOf(0) + fpsOptions,
                selected = fpsPick,
                columns = 4,
                label = { if (it == 0) "Auto" else "$it" },
            ) { fpsPick = it }
        }
    }
}

// --------------------------------------------------------------- Statistik

@Composable
fun StatsScreen(ui: UiState, act: AppActions) {
    val live = rememberLive()
    val s = live.stats
    val st = ui.status

    SectionCard("Statistik Perangkat", R.drawable.ic_chart) {
        SettingRow(
            icon = R.drawable.ic_thermo,
            iconTint = tempColor(s.tempC),
            title = "Suhu Baterai",
            subtitle = "Cerminan panas HP saat ini",
        ) { ValueText("%.1f°C".format(java.util.Locale.US, s.tempC), tempColor(s.tempC)) }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_battery,
            iconTint = batteryColor(s.batteryPct),
            title = "Baterai",
            subtitle = if (s.charging) "Sedang mengisi daya" else "Tidak mengisi daya",
        ) { ValueText("${s.batteryPct}%", batteryColor(s.batteryPct)) }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_speed,
            title = "Refresh Rate Layar",
            subtitle = if (st.pinnedHz > 0) "Dikunci di ${st.pinnedHz} Hz" else "Otomatis",
        ) { ValueText(if (live.hz > 0) "${live.hz} Hz" else "—", Nx.Text) }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_monitor,
            title = "Resolusi",
            subtitle = st.info?.let { describeDisplay(it, 0) } ?: "Butuh akses sistem",
        )
    }

    SectionCard("Memori (RAM)", R.drawable.ic_memory) {
        val total = s.ramTotalMb.coerceAtLeast(1L)
        val usedFraction = ((total - s.ramFreeMb).toFloat() / total).coerceIn(0f, 1f)
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("RAM bebas", color = Nx.Text, modifier = Modifier.weight(1f))
                Text(
                    "%.1f GB dari %.1f GB".format(java.util.Locale.US, s.ramFreeMb / 1024f, s.ramTotalMb / 1024f),
                    color = Nx.PurpleLight,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Nx.Chip)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(usedFraction)
                        .fillMaxHeight()
                        .background(Brush.horizontalGradient(listOf(Nx.PurpleDeep, Nx.Purple)))
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Terpakai ${(usedFraction * 100).toInt()}%",
                color = Nx.Muted,
                fontSize = 12.sp,
            )
        }
        NxDivider()
        Row(Modifier.padding(14.dp)) {
            NxButton(
                text = if (ui.boosting) "Membersihkan…" else "Boost RAM Sekarang",
                modifier = Modifier.fillMaxWidth(),
                enabled = !ui.boosting && st.hasAccess,
            ) { act.boost() }
        }
        if (!st.hasAccess) {
            Text(
                "Boost butuh akses sistem (Shizuku atau root).",
                color = Nx.Amber,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 10.dp),
            )
        }
    }
}

@Composable
private fun ValueText(text: String, color: Color) {
    Text(text, color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold)
}

// -------------------------------------------------------------- Pengaturan

@Composable
private fun CheckRow(ok: Boolean, text: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NxIcon(
            if (ok) R.drawable.ic_check_circle else R.drawable.ic_warning,
            tint = if (ok) Nx.Green else Nx.Amber,
            size = 22.dp,
        )
        Spacer(Modifier.width(12.dp))
        Text(text, color = Nx.Text, fontSize = 14.sp)
    }
}

@Composable
private fun ResultRow(item: CheckItem) {
    val color = when (item.level) {
        CheckLevel.OK -> Nx.Green
        CheckLevel.WARN -> Nx.Amber
        CheckLevel.FAIL -> Nx.Red
    }
    val glyph = when (item.level) {
        CheckLevel.OK -> "✓"
        CheckLevel.WARN -> "!"
        CheckLevel.FAIL -> "✕"
    }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Text(
            glyph,
            color = color,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.width(24.dp),
        )
        Column(Modifier.weight(1f)) {
            Text(item.title, color = Nx.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(item.detail, color = Nx.Muted, fontSize = 12.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
fun SettingsScreen(ui: UiState, act: AppActions) {
    val st = ui.status
    val running = st.shizuku == ShizukuState.NEED_PERMISSION ||
        st.shizuku == ShizukuState.DENIED ||
        st.shizuku == ShizukuState.READY
    val rootOk = st.mode == ShellRunner.Mode.ROOT
    var showDpi by remember { mutableStateOf(false) }

    SectionCard("Sambungan Shizuku", R.drawable.ic_shield) {
        CheckRow(st.shizuku != ShizukuState.NOT_INSTALLED, "Aplikasi Shizuku terpasang")
        NxDivider()
        CheckRow(running, "Layanan Shizuku berjalan")
        NxDivider()
        CheckRow(st.shizuku == ShizukuState.READY, "Izin untuk Nexus Game Boost")
        if (rootOk) {
            NxDivider()
            CheckRow(true, "Akses root aktif (dipakai sebagai cadangan)")
        }

        val guide = when (st.shizuku) {
            ShizukuState.NOT_INSTALLED ->
                "1. Pasang aplikasi Shizuku (Play Store atau shizuku.rikka.app).\n" +
                    "2. Buka Shizuku lalu jalankan lewat Debugging Nirkabel.\n" +
                    "3. Kembali ke sini dan ketuk Cek Ulang."
            ShizukuState.NOT_RUNNING ->
                "Shizuku terpasang tapi belum dijalankan. Buka Shizuku lalu ketuk Mulai. " +
                    "Tanpa root: aktifkan Opsi Pengembang, Debugging Nirkabel, pasangkan, lalu " +
                    "Mulai. Ini perlu diulang setiap HP dihidupkan ulang."
            ShizukuState.NEED_PERMISSION ->
                "Shizuku sudah jalan. Ketuk Beri Izin lalu pilih Izinkan pada dialog yang muncul."
            ShizukuState.DENIED ->
                "Izin pernah ditolak. Buka Shizuku, masuk ke Aplikasi terotorisasi, lalu " +
                    "aktifkan Nexus Game Boost. Setelah itu ketuk Cek Ulang."
            ShizukuState.READY ->
                "Semua siap. Resolusi, FPS, dan Boost bisa dipakai."
        }
        Text(
            guide,
            color = Nx.Muted,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 8.dp),
        )

        Row(
            Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val primary = when (st.shizuku) {
                ShizukuState.NOT_INSTALLED -> "Unduh Shizuku"
                ShizukuState.NOT_RUNNING -> "Buka Shizuku"
                ShizukuState.NEED_PERMISSION -> "Beri Izin"
                ShizukuState.DENIED -> "Buka Shizuku"
                ShizukuState.READY -> null
            }
            if (primary != null) {
                PillButton(primary, icon = null) { act.fixAccess() }
            }
            PillButton("Cek Ulang", icon = R.drawable.ic_refresh) { act.recheck() }
        }

        if (st.lastError.isNotBlank()) {
            Text(
                "Pesan error terakhir:\n${st.lastError}",
                color = Nx.Amber,
                fontSize = 11.sp,
                maxLines = 6,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
            )
        }
    }

    SectionCard("Preferensi", R.drawable.ic_tune) {
        SettingRow(
            icon = R.drawable.ic_speed,
            title = "Auto FPS",
            subtitle = "Turunkan FPS ke 60 saat HP panas, naik lagi saat dingin",
            onClick = { ui.updateAutoFps(!ui.autoFps) },
        ) { NxSwitch(ui.autoFps) { ui.updateAutoFps(it) } }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_grid,
            title = "Sesuaikan Density",
            subtitle = "Ukuran UI tetap normal saat resolusi turun",
            onClick = { ui.updateScaleDensity(!ui.scaleDensity) },
        ) { NxSwitch(ui.scaleDensity) { ui.updateScaleDensity(it) } }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_overlay,
            title = "Izin Pop Up Overlay",
            subtitle = if (ui.overlayGranted) "Sudah diizinkan" else "Belum diizinkan",
            onClick = { act.openOverlaySettings() },
        ) { PillButton("Buka") { act.openOverlaySettings() } }
    }

    SectionCard("Layar", R.drawable.ic_monitor) {
        SettingRow(
            icon = R.drawable.ic_monitor,
            title = "Resolusi per Game",
            subtitle = when {
                !GameDownscale.available -> "Butuh Android 14 ke atas. Memakai cara seluruh layar."
                ui.perGameResolution -> "Hanya game yang turun resolusinya (Game Mode). Game harus dibuka ulang."
                else -> "Mati: seluruh layar HP diturunkan resolusinya."
            },
            onClick = { if (GameDownscale.available) ui.updatePerGameResolution(!ui.perGameResolution) },
        ) {
            NxSwitch(ui.perGameResolution && GameDownscale.available) {
                if (GameDownscale.available) ui.updatePerGameResolution(it)
            }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_speed,
            title = "FPS per Game",
            subtitle = when {
                !GameDownscale.available -> "Butuh Android 14 ke atas. Memakai kunci refresh rate layar."
                ui.perGameFps -> "Batas FPS hanya untuk game (Game Mode). Bila ditolak HP, memakai kunci refresh rate."
                else -> "Mati: batas FPS mengunci refresh rate seluruh layar."
            },
            onClick = { if (GameDownscale.available) ui.updatePerGameFps(!ui.perGameFps) },
        ) {
            NxSwitch(ui.perGameFps && GameDownscale.available) {
                if (GameDownscale.available) ui.updatePerGameFps(it)
            }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_grid,
            title = "DPI Normal",
            subtitle = if (ui.baseDpi > 0) "${ui.baseDpi} dpi. Dikembalikan setelah main."
            else "Otomatis (DPI saat layar pertama kali diubah)",
            onClick = { showDpi = true },
        ) {
            PillButton("Atur") { showDpi = true }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_refresh,
            title = "Reset Layar Sekarang",
            subtitle = "Kembalikan resolusi, density (ke DPI Normal), dan refresh rate",
        ) {
            PillButton("Reset", icon = null) { act.resetDisplay() }
        }
    }

    SectionCard("Crosshair", R.drawable.ic_crosshair) {
        val cx = ui.crosshair
        val density = LocalDensity.current.density
        val painter = remember { CrosshairPainter() }

        Text(
            "Titik bidik kecil di tengah layar, tidak bisa disentuh (ketukanmu tetap sampai ke game). " +
                "Atur bentuk, warna, dan ukurannya di sini; perubahan langsung terlihat di pratinjau dan di game.",
            color = Nx.Muted,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 10.dp),
        )

        // Pratinjau di atas latar gelap seperti layar game.
        Box(
            Modifier
                .padding(horizontal = 14.dp)
                .fillMaxWidth()
                .height(110.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFF34443B), Color(0xFF18221C)))),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                drawIntoCanvas { c ->
                    painter.draw(c.nativeCanvas, size.width / 2f, size.height / 2f, cx, density)
                }
            }
        }

        Text(
            "Bentuk",
            color = Nx.Text,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 6.dp),
        )
        Box(Modifier.padding(horizontal = 14.dp)) {
            ChipGrid(
                items = CrosshairConfig.STYLES,
                selected = cx.style,
                columns = 4,
                label = { CrosshairConfig.styleName(it) },
            ) { ui.updateCrosshair(cx.copy(style = it)) }
        }

        Text(
            "Warna",
            color = Nx.Text,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 8.dp),
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            CrosshairConfig.COLORS.forEach { col ->
                val on = col == cx.color
                Box(
                    Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(col))
                        .border(
                            if (on) 3.dp else 1.dp,
                            if (on) Color.White else Nx.BorderSoft,
                            CircleShape,
                        )
                        .clickable { ui.updateCrosshair(cx.copy(color = col)) }
                )
            }
        }

        Spacer(Modifier.height(6.dp))
        NxSlider("Ukuran", cx.sizeDp, 8..120, "${cx.sizeDp} dp") { ui.updateCrosshair(cx.copy(sizeDp = it)) }
        NxSlider("Ketebalan", cx.thickDp, 1..8, "${cx.thickDp} dp") { ui.updateCrosshair(cx.copy(thickDp = it)) }
        NxSlider("Kecerahan", cx.alphaPct, 10..100, "${cx.alphaPct}%") { ui.updateCrosshair(cx.copy(alphaPct = it)) }
        NxSlider("Geser kiri / kanan", cx.dxDp, -300..300, "${cx.dxDp} dp") { ui.updateCrosshair(cx.copy(dxDp = it)) }
        NxSlider("Geser atas / bawah", cx.dyDp, -300..300, "${cx.dyDp} dp") { ui.updateCrosshair(cx.copy(dyDp = it)) }

        NxDivider()
        SettingRow(
            icon = R.drawable.ic_crosshair,
            title = "Otomatis saat game dibuka",
            subtitle = "Crosshair ikut tampil begitu game dibuka dari Game Lobby",
            onClick = { ui.updateCrossAuto(!ui.crossAuto) },
        ) {
            NxSwitch(ui.crossAuto) { ui.updateCrossAuto(it) }
        }

        Text(
            "Karena aturan sentuhan Android 12 ke atas, crosshair paling terang tampil sekitar 80% supaya " +
                "ketukanmu tetap sampai ke game. Sebagian game melarang overlay bidik, jadi pakai dengan bijak. " +
                "Saklar yang sama ada di panel pop-up (tombol pena di pop-up lebar).",
            color = Nx.Muted,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 6.dp, bottom = 8.dp),
        )
        Row(
            Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            PillButton("Tampilkan / Sembunyikan", icon = null) { act.toggleCrosshair() }
            PillButton("Pusatkan", icon = null) { ui.updateCrosshair(cx.copy(dxDp = 0, dyDp = 0)) }
        }
    }

    SectionCard("Macro (Rekam & Putar)", R.drawable.ic_touch) {
        SettingRow(
            icon = R.drawable.ic_shield,
            title = "Layanan Aksesibilitas",
            subtitle = if (ui.tapServiceOn) "Aktif: ketukan cepat"
            else "Belum aktif: ketukan lewat Shizuku, lebih lambat (jeda 0,2 sampai 0,5 detik per langkah)",
            onClick = { if (!ui.tapServiceOn) act.openAccessibilitySettings() },
        ) {
            if (!ui.tapServiceOn) PillButton("Buka", icon = null) { act.openAccessibilitySettings() }
        }
        if (!ui.tapServiceOn && st.hasAccess) {
            NxDivider()
            SettingRow(
                icon = R.drawable.ic_bolt,
                title = "Nyalakan Otomatis",
                subtitle = "Lewat Shizuku, tanpa buka pengaturan Aksesibilitas",
                onClick = { act.enableTapService() },
            ) { PillButton("Nyalakan", icon = null) { act.enableTapService() } }
        }

        Text(
            "Slot rekaman",
            color = Nx.Text,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 6.dp),
        )
        Row(
            Modifier.padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            for (slot in 1..GameStore.MACRO_SLOTS) {
                val n = ui.macroCounts.getOrElse(slot - 1) { 0 }
                NxChip(
                    "M$slot (${if (n == 0) "kosong" else n.toString()})",
                    ui.macroSlot == slot,
                    Modifier.weight(1f),
                ) { ui.updateMacroSlot(slot) }
            }
        }

        Text(
            "Diulang",
            color = Nx.Text,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 6.dp),
        )
        Box(Modifier.padding(horizontal = 14.dp)) {
            ChipGrid(
                items = MacroController.LOOPS,
                selected = ui.macroLoops,
                columns = 5,
                label = { MacroController.loopsLabel(it) },
            ) { ui.updateMacroLoops(it) }
        }

        Text(
            "Kecepatan putar ulang (jeda antar langkah)",
            color = Nx.Text,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 6.dp),
        )
        Box(Modifier.padding(horizontal = 14.dp)) {
            ChipGrid(
                items = MacroController.SPEEDS,
                selected = ui.macroSpeed,
                columns = 5,
                label = { "$it%" },
            ) { ui.updateMacroSpeed(it) }
        }

        Text(
            "Cara pakai: ketuk Tampilkan Macro. Tekan ● untuk mulai merekam, lalu ketuk atau geser layar " +
                "seperti biasa (selama merekam, game tidak menerima sentuhanmu). Tekan ■ untuk menyimpan " +
                "ke slot, lalu ▶ untuk memutar ulang. Di kapsulnya: ketuk M1 untuk ganti slot, ×1 untuk " +
                "jumlah ulangan, 100% untuk kecepatan, dan tong sampah untuk menghapus slot. Kapsul bisa " +
                "digeser. Hanya satu jari yang direkam (gerak multi-jari belum didukung), dan geseran " +
                "diputar sebagai garis lurus. Putaran berhenti sendiri saat layar mati. Sebagian game " +
                "melarang ketukan otomatis, jadi pakai dengan bijak.",
            color = Nx.Muted,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 6.dp),
        )
        Row(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp)) {
            PillButton("Tampilkan Macro", icon = null) { act.showMacro() }
        }
    }

    SectionCard("Buka Pop-up", R.drawable.ic_overlay) {
        val edge = ui.openMode == GameStore.OPEN_EDGE
        Text(
            "Cara memanggil pop-up saat main. Geser dari tepi: garis ungu tipis muncul di pinggir " +
                "layar, geser ke dalam dari garis itu untuk membuka pop-up (mengetuk garisnya juga bisa). " +
                "Bubble: lingkaran NX melayang yang diketuk.",
            color = Nx.Muted,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 8.dp),
        )
        Row(
            Modifier.padding(horizontal = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            NxChip("Geser dari tepi", edge, Modifier.weight(1f)) { ui.updateOpenMode(GameStore.OPEN_EDGE) }
            NxChip("Bubble", !edge, Modifier.weight(1f)) { ui.updateOpenMode(GameStore.OPEN_BUBBLE) }
        }
        if (edge) {
            Text(
                "Sisi layar",
                color = Nx.Text,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 6.dp),
            )
            Row(
                Modifier.padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                NxChip("Kiri", !ui.edgeRight, Modifier.weight(1f)) { ui.updateEdgeRight(false) }
                NxChip("Kanan", ui.edgeRight, Modifier.weight(1f)) { ui.updateEdgeRight(true) }
            }
        }
        Text(
            "Berlaku saat game dibuka berikutnya dari Game Lobby. Kalau gestur Kembali HP ikut " +
                "bereaksi saat menggeser, pakai tombol Buka pop-up di notifikasi Nexus, atau pilih Bubble.",
            color = Nx.Muted,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 12.dp),
        )
    }

    SectionCard("HUD Mini (FPS dll)", R.drawable.ic_chart) {
        val picked = HudItem.parse(ui.hudItems)
        Text(
            "Kotak kecil melayang di atas layar yang hanya menampilkan angka yang kamu pilih. " +
                "Pilih FPS saja, atau tambah suhu, baterai, CPU, GPU, dan RAM. Angka yang tidak bisa " +
                "dibaca HP-mu tampil \"—\".",
            color = Nx.Muted,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 8.dp),
        )
        Box(Modifier.padding(horizontal = 14.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HudItem.entries.chunked(3).forEach { rowItems ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowItems.forEach { item ->
                            NxChip(item.title, item in picked, Modifier.weight(1f)) {
                                val next = if (item in picked) picked - item else picked + item
                                ui.updateHudItems(HudItem.toCsv(next))
                            }
                        }
                    }
                }
            }
        }
        Row(
            Modifier.padding(start = 14.dp, end = 14.dp, top = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            PillButton("FPS saja", icon = null) { ui.updateHudItems(HudItem.FPS_ONLY) }
            PillButton("Lengkap", icon = null) { ui.updateHudItems(HudItem.FULL) }
        }
        Text(
            "FPS diukur pada aplikasi yang sedang di depan. Chip di sebelah angka FPS menunjukkan " +
                "kualitasnya: Smooth (55 ke atas), Normal (30 sampai 54), Laggy (di bawah 30). " +
                "Geser HUD untuk memindahkan, ketuk X untuk menutup. Di panel bubble ada saklar HUD yang sama.",
            color = Nx.Muted,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 10.dp, bottom = 6.dp),
        )
        Row(Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp)) {
            PillButton("Tampilkan HUD", icon = null) { act.showHud() }
        }
    }

    SectionCard("Tes Kompatibilitas", R.drawable.ic_check_circle) {
        val context = LocalContext.current
        val scope = rememberCoroutineScope()
        var testRunning by remember { mutableStateOf(false) }
        var testResults by remember { mutableStateOf<List<CheckItem>?>(null) }

        Text(
            "Mengecek fitur mana yang benar-benar didukung HP-mu (Game Mode, FPS, akses sistem, dan lain-lain). " +
                "Tidak mengubah pengaturanmu dan tidak menyentuh game.",
            color = Nx.Muted,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 8.dp),
        )
        Row(
            Modifier.padding(start = 14.dp, end = 14.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val dpiNow = ui.baseDpi
            PillButton(if (testRunning) "Menguji…" else "Jalankan Tes", icon = null) {
                if (!testRunning) {
                    testRunning = true
                    scope.launch {
                        val r = withContext(Dispatchers.IO) { Diagnostics.run(context, dpiNow) }
                        testResults = r
                        testRunning = false
                    }
                }
            }
            if (testResults != null) {
                PillButton("Salin Hasil", icon = null) {
                    val cm = context.getSystemService(ClipboardManager::class.java)
                    cm?.setPrimaryClip(
                        ClipData.newPlainText("Tes Kompatibilitas", Diagnostics.toText(testResults.orEmpty()))
                    )
                    Toast.makeText(context, "Hasil disalin. Tempel ke chat.", Toast.LENGTH_SHORT).show()
                }
            }
        }
        testResults?.forEach { item -> ResultRow(item) }
    }

    if (showDpi) {
        var text by remember { mutableStateOf(if (ui.baseDpi > 0) ui.baseDpi.toString() else "") }
        NxDialog(
            title = "DPI Normal",
            onDismiss = { showDpi = false },
            confirmText = "Simpan",
            onConfirm = {
                val v = text.toIntOrNull()
                if (v != null && v in 120..1000) {
                    ui.updateBaseDpi(v)
                    showDpi = false
                }
            },
        ) {
            Text(
                "DPI yang kamu pakai sehari-hari. Setelah main, density dikembalikan ke angka ini, " +
                    "bukan ke bawaan pabrik. Saat resolusi layar diturunkan, density dihitung dari angka ini.",
                fontSize = 13.sp,
            )
            OutlinedTextField(
                value = text,
                onValueChange = { v -> text = v.filter { it.isDigit() }.take(4) },
                singleLine = true,
                label = { Text("DPI (120 sampai 1000)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            )
            PillButton("Otomatis", icon = null) {
                ui.updateBaseDpi(0)
                showDpi = false
            }
            Text(
                "Otomatis: memakai DPI yang terbaca saat pertama kali layar diubah.",
                fontSize = 12.sp,
            )
        }
    }
}

// ----------------------------------------------------------------- Tentang

@Composable
fun AboutScreen() {
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            painter = painterResource(R.drawable.logo_nx),
            contentDescription = "Logo NX",
            modifier = Modifier
                .size(112.dp)
                .clip(RoundedCornerShape(28.dp)),
        )
        Spacer(Modifier.height(12.dp))
        Text("Nexus Game Boost", color = Nx.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Max Performance, No Lag", color = Nx.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        Text("Versi 1.0", color = Nx.PurpleLight, fontSize = 12.sp, textAlign = TextAlign.Center)
    }

    SectionCard("Fitur", R.drawable.ic_rocket) {
        AboutLine("Turunkan resolusi render game (0.9x sampai 0.3x) supaya lebih ringan.")
        NxDivider()
        AboutLine("Batasi FPS khusus game (Android 14 ke atas) atau lewat refresh rate layar, dengan Auto FPS saat HP panas.")
        NxDivider()
        AboutLine("Crosshair: titik bidik di tengah layar dengan warna, bentuk, ukuran, dan posisi yang bisa diatur.")
        AboutLine("Macro: rekam ketukan dan geseran, lalu putar ulang otomatis (3 slot, bisa diulang dan dipercepat).")
        NxDivider()
        AboutLine("Tes Kompatibilitas untuk melihat fitur mana yang didukung HP-mu.")
        NxDivider()
        AboutLine("Bubble pop-up di atas game untuk mengubah pengaturan langsung.")
        NxDivider()
        AboutLine("Mode Fokus, matikan Penghemat Baterai, Boost RAM, dan peringatan panas.")
        NxDivider()
        AboutLine("Semua perubahan dikembalikan otomatis saat game ditutup.")
    }

    SectionCard("Catatan", R.drawable.ic_info) {
        AboutLine(
            "Mengubah resolusi, density, dan refresh rate memakai perintah sistem lewat " +
                "Shizuku (tanpa root) atau root. Aplikasi ini tidak memodifikasi file game."
        )
        NxDivider()
        AboutLine(
            "Shizuku oleh RikkaApps (Apache-2.0). Ikon antarmuka digambar sendiri; " +
                "logo NX dan desain tampilan dari pemilik aplikasi."
        )
    }
}

@Composable
private fun AboutLine(text: String) {
    Text(
        text,
        color = Nx.Muted,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
    )
}
