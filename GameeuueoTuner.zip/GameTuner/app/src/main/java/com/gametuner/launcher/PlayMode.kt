package com.gametuner.launcher

/**
 * Pengaturan tambahan selama main: Jangan Ganggu dan mematikan Penghemat Baterai.
 *
 * Aturan keselamatan: hanya mengubah dan memulihkan apa yang KITA ubah. Kalau Jangan Ganggu
 * sudah menyala atau Penghemat Baterai sudah mati sebelum main, keduanya tidak disentuh,
 * sehingga pengaturan milik pengguna tidak pernah tertimpa. Semua fungsi memanggil shell
 * (blocking): panggil dari thread background.
 */
object PlayMode {

    fun enter(store: GameStore): CmdResult {
        val errors = mutableListOf<String>()

        if (store.focusMode && !store.focusApplied) {
            val zen = ShellRunner.exec("settings get global zen_mode")
            if (!zen.ok) {
                errors += zen.err.ifBlank { zen.out }
            } else if (zen.out.trim().let { it == "0" || it == "null" }) {
                // "priority": hanya gangguan prioritas yang lolos; notifikasi biasa dibisukan.
                val r = ShellRunner.exec("cmd notification set_dnd priority")
                if (r.ok) {
                    store.focusApplied = true
                } else {
                    errors += r.err.ifBlank { r.out }
                }
            }
        }

        if (store.batterySaverOff && !store.batterySaverApplied) {
            val lp = ShellRunner.exec("settings get global low_power")
            if (!lp.ok) {
                errors += lp.err.ifBlank { lp.out }
            } else if (lp.out.trim() == "1") {
                val r = ShellRunner.exec("settings put global low_power 0")
                if (r.ok) {
                    store.batterySaverApplied = true
                } else {
                    errors += r.err.ifBlank { r.out }
                }
            }
        }

        return CmdResult(errors.isEmpty(), "", errors.joinToString("\n"))
    }

    /**
     * Saklar Mode Fokus di bubble: nyalakan atau matikan Jangan Ganggu sekarang. Jangan Ganggu yang sudah
     * menyala sebelumnya tidak disentuh, dan hanya dimatikan bila KITA yang menyalakannya.
     */
    fun setFocus(on: Boolean, store: GameStore): CmdResult {
        store.focusMode = on
        if (on) {
            if (store.focusApplied) return CmdResult(true, "", "")
            val zen = ShellRunner.exec("settings get global zen_mode")
            if (!zen.ok) return zen
            if (zen.out.trim().let { it != "0" && it != "null" }) return CmdResult(true, "", "")
            val r = ShellRunner.exec("cmd notification set_dnd priority")
            if (r.ok) store.focusApplied = true
            return r
        }
        if (!store.focusApplied) return CmdResult(true, "", "")
        val r = ShellRunner.exec("cmd notification set_dnd off")
        if (r.ok) store.focusApplied = false
        return r
    }

    /** Penghemat Baterai sedang menyala? Null bila tidak bisa dibaca. */
    fun batterySaverOn(): Boolean? {
        val r = ShellRunner.exec("settings get global low_power")
        if (!r.ok) return null
        return when (r.out.trim()) {
            "1" -> true
            "0", "null" -> false
            else -> null
        }
    }

    /** Dipakai saklar manual di bubble. Pengguna mengambil alih, jadi tidak ada pemulihan otomatis lagi. */
    fun setBatterySaver(on: Boolean, store: GameStore): CmdResult {
        store.batterySaverApplied = false
        return ShellRunner.exec("settings put global low_power ${if (on) 1 else 0}")
    }

    /** Pulihkan hanya yang tadi kita ubah. Tidak melakukan apa-apa bila tidak ada yang diubah. */
    fun restore(store: GameStore): CmdResult {
        val errors = mutableListOf<String>()

        if (store.focusApplied) {
            val r = ShellRunner.exec("cmd notification set_dnd off")
            if (r.ok) {
                store.focusApplied = false
            } else {
                errors += r.err.ifBlank { r.out }
            }
        }

        if (store.batterySaverApplied) {
            val r = ShellRunner.exec("settings put global low_power 1")
            if (r.ok) {
                store.batterySaverApplied = false
            } else {
                errors += r.err.ifBlank { r.out }
            }
        }

        return CmdResult(errors.isEmpty(), "", errors.joinToString("\n"))
    }
}
