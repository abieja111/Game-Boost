package com.gametuner.launcher

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap

data class GameApp(
    val pkg: String,
    val label: String,
    val icon: ImageBitmap,
    val isGame: Boolean,
    /** Ukuran berkas aplikasi (APK dan split), bukan data game. 0 = tidak terbaca. */
    val sizeBytes: Long = 0L,
)

/** Keadaan sambungan ke Shizuku, dari yang paling awal gagal sampai siap dipakai. */
enum class ShizukuState {
    /** Aplikasi Shizuku belum dipasang. */
    NOT_INSTALLED,

    /** Terpasang tapi layanannya belum dijalankan (harus dinyalakan lagi tiap HP restart). */
    NOT_RUNNING,

    /** Layanan jalan, tapi aplikasi ini belum diberi izin. */
    NEED_PERMISSION,

    /** Izin sudah ditolak; harus diaktifkan manual lewat daftar aplikasi di Shizuku. */
    DENIED,

    /** Siap dipakai. */
    READY,
}

data class SysStatus(
    val mode: ShellRunner.Mode = ShellRunner.Mode.NONE,
    val shizuku: ShizukuState = ShizukuState.NOT_RUNNING,
    val info: DisplayInfo? = null,
    /** Refresh rate yang sedang dikunci (Hz); 0 = otomatis. */
    val pinnedHz: Int = 0,
    /** True bila Jangan Ganggu / Penghemat Baterai sedang kita terapkan. */
    val modeActive: Boolean = false,
    /** Pesan error terakhir dari shell, untuk diagnosis di halaman Pengaturan. */
    val lastError: String = "",
) {
    val hasAccess: Boolean get() = mode != ShellRunner.Mode.NONE
}

/**
 * HOME = Game Lobby (menu utama bergaya launcher), BASE = Super Base (akses, mode game, boost),
 * sisanya halaman penuh yang dibuka dari tombol segi enam.
 */
enum class Tab { HOME, BASE, GAMES, STATS, SETTINGS, ABOUT }

/** Semua aksi yang bisa dipicu UI. Diimplementasikan oleh MainActivity. */
interface AppActions {
    /** Lakukan langkah berikutnya untuk menyambung ke Shizuku (pasang / jalankan / beri izin). */
    fun fixAccess()
    fun openShizuku()
    fun recheck()
    fun openOverlaySettings()
    fun resetDisplay()

    /** Buka pengaturan Aksesibilitas Android untuk menyalakan layanan Macro. */
    fun openAccessibilitySettings()

    /** Nyalakan layanan Macro lewat Shizuku/root tanpa membuka pengaturan. */
    fun enableTapService()

    /** Tampilkan kapsul Macro (rekam/putar) di atas layar sekarang. */
    fun showMacro()

    /** Tampilkan atau sembunyikan crosshair di atas layar sekarang. */
    fun toggleCrosshair()

    /** Tampilkan HUD Mini (FPS dan angka pilihan lain) di atas layar sekarang. */
    fun showHud()
    fun boost()
    fun launchGame(app: GameApp, percent: Int, fps: Int)
}

/** Keadaan UI. Setiap perubahan pengaturan langsung disimpan ke [GameStore]. */
class UiState(private val store: GameStore) {

    var apps by mutableStateOf<List<GameApp>>(emptyList())
    var status by mutableStateOf(SysStatus())
    var overlayGranted by mutableStateOf(false)
    var boosting by mutableStateOf(false)
    var tab by mutableStateOf(Tab.HOME)

    var scaleDensity by mutableStateOf(store.scaleDensity)
        private set
    var autoReset by mutableStateOf(store.autoReset)
        private set
    var playOptimize by mutableStateOf(store.playOptimize)
        private set
    var focusMode by mutableStateOf(store.focusMode)
        private set
    var batterySaverOff by mutableStateOf(store.batterySaverOff)
        private set
    var heatWarnC by mutableIntStateOf(store.heatWarnC)
        private set
    var autoBoost by mutableStateOf(store.autoBoost)
        private set
    var autoFps by mutableStateOf(store.autoFps)
        private set
    var perGameResolution by mutableStateOf(store.perGameResolution)
        private set
    var perGameFps by mutableStateOf(store.perGameFps)
        private set
    var baseDpi by mutableIntStateOf(store.baseDpi)
        private set
    var macroSlot by mutableIntStateOf(store.macroSlot)
        private set
    var macroLoops by mutableIntStateOf(store.macroLoops)
        private set
    var macroSpeed by mutableIntStateOf(store.macroSpeed)
        private set

    /** Jumlah langkah tiap slot Macro (indeks 0 = slot 1). */
    var macroCounts by mutableStateOf(macroCountsNow())
        private set

    var crosshair by mutableStateOf(store.crosshair)
        private set
    var crossAuto by mutableStateOf(store.crossAuto)
        private set
    var hudItems by mutableStateOf(store.hudItems)
        private set

    /** Cara membuka pop-up in-game ([GameStore.OPEN_EDGE] atau [GameStore.OPEN_BUBBLE]). */
    var openMode by mutableStateOf(store.openMode)
        private set
    var edgeRight by mutableStateOf(store.edgeRight)
        private set

    /** Game terpilih di Game Lobby (disimpan, supaya tetap terpilih saat aplikasi dibuka lagi). */
    var lobbyPkg by mutableStateOf(store.lobbyPkg ?: store.currentGame)
        private set

    /** Aplikasi bukan-game yang ditambahkan ke Game Lobby dengan tombol +. */
    var lobbyAdd by mutableStateOf(store.lobbyAdd)
        private set

    /** Game terdeteksi yang disembunyikan dari Game Lobby. */
    var lobbyHide by mutableStateOf(store.lobbyHide)
        private set

    /** True bila Layanan Aksesibilitas Macro aktif; diperbarui tiap aplikasi dibuka kembali. */
    var tapServiceOn by mutableStateOf(false)

    private val scales = mutableStateMapOf<String, Int>()
    private val fpsByGame = mutableStateMapOf<String, Int>()

    fun scaleOf(pkg: String): Int = scales[pkg] ?: store.getScale(pkg)
    fun fpsOf(pkg: String): Int = fpsByGame[pkg] ?: store.getFps(pkg)

    fun rememberProfile(pkg: String, percent: Int, fps: Int) {
        scales[pkg] = percent
        fpsByGame[pkg] = fps
    }

    /** Overlay bisa mengubah profil saat game jalan; baca ulang dari penyimpanan. */
    fun reloadProfiles() {
        scales.clear()
        fpsByGame.clear()
        autoFps = store.autoFps
        heatWarnC = store.heatWarnC
        macroSlot = store.macroSlot
        macroLoops = store.macroLoops
        macroSpeed = store.macroSpeed
        macroCounts = macroCountsNow()
        crosshair = store.crosshair
        crossAuto = store.crossAuto
        hudItems = store.hudItems
    }

    private fun macroCountsNow(): List<Int> =
        (1..GameStore.MACRO_SLOTS).map { store.getMacro(it).size }

    fun updateScaleDensity(v: Boolean) { scaleDensity = v; store.scaleDensity = v }
    fun updateAutoReset(v: Boolean) { autoReset = v; store.autoReset = v }
    fun updatePlayOptimize(v: Boolean) { playOptimize = v; store.playOptimize = v }
    fun updateFocusMode(v: Boolean) { focusMode = v; store.focusMode = v }
    fun updateBatterySaverOff(v: Boolean) { batterySaverOff = v; store.batterySaverOff = v }
    fun updateAutoBoost(v: Boolean) { autoBoost = v; store.autoBoost = v }
    fun updateAutoFps(v: Boolean) { autoFps = v; store.autoFps = v }
    fun updatePerGameResolution(v: Boolean) { perGameResolution = v; store.perGameResolution = v }
    fun updatePerGameFps(v: Boolean) { perGameFps = v; store.perGameFps = v }
    fun updateMacroSlot(v: Int) { macroSlot = v; store.macroSlot = v }
    fun updateMacroLoops(v: Int) { macroLoops = v; store.macroLoops = v }
    fun updateMacroSpeed(v: Int) { macroSpeed = v; store.macroSpeed = v }
    fun updateCrosshair(v: CrosshairConfig) { crosshair = v; store.crosshair = v }
    fun updateCrossAuto(v: Boolean) { crossAuto = v; store.crossAuto = v }
    fun updateHudItems(v: String) { hudItems = v; store.hudItems = v }

    fun updateOpenMode(v: String) { openMode = v; store.openMode = v }
    fun updateEdgeRight(v: Boolean) { edgeRight = v; store.edgeRight = v }

    fun selectLobby(pkg: String) { lobbyPkg = pkg; store.lobbyPkg = pkg }

    /** True bila [app] tampil di Game Lobby: game terdeteksi kecuali yang disembunyikan, atau yang ditambahkan. */
    fun inLobby(app: GameApp): Boolean =
        if (app.isGame) app.pkg !in lobbyHide else app.pkg in lobbyAdd

    /** Tampilkan atau sembunyikan [app] di Game Lobby. */
    fun toggleLobby(app: GameApp) {
        val show = !inLobby(app)
        if (app.isGame) {
            lobbyHide = if (show) lobbyHide - app.pkg else lobbyHide + app.pkg
            store.lobbyHide = lobbyHide
        } else {
            lobbyAdd = if (show) lobbyAdd + app.pkg else lobbyAdd - app.pkg
            store.lobbyAdd = lobbyAdd
        }
    }

    /** 0 = otomatis. */
    fun updateBaseDpi(v: Int) { baseDpi = v; store.baseDpi = v }

    /** DPI yang dipakai untuk pratinjau: angka manual, atau DPI layar saat ini bila otomatis. */
    fun baseDpiFor(info: DisplayInfo): Int = DisplayController.baseDpi(info, store)

    /** 0 = peringatan mati. */
    fun updateHeatWarn(c: Int) {
        heatWarnC = c
        store.heatWarnC = c
        if (c > 0) store.lastHeatWarnC = c
    }
}
