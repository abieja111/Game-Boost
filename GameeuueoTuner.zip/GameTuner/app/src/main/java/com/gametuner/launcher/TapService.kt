package com.gametuner.launcher

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent

/**
 * Layanan aksesibilitas yang hanya dipakai untuk mengetuk dan menggeser layar (fitur Macro).
 * Tidak meminta izin membaca isi jendela, jadi tidak bisa melihat apa yang ada di layar;
 * semua fungsi event sengaja dikosongkan.
 */
class TapService : AccessibilityService() {

    companion object {
        /** Terisi selama layanan tersambung; null bila belum dinyalakan di pengaturan Aksesibilitas. */
        @Volatile
        var instance: TapService? = null
            private set

        fun component(context: Context): ComponentName =
            ComponentName(context, TapService::class.java)

        /** True bila layanan ini tercatat aktif di pengaturan Aksesibilitas. */
        fun isEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ).orEmpty()
            val me = component(context)
            return flat.split(':').any { ComponentName.unflattenFromString(it.trim()) == me }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /**
     * Kirim satu gerakan dari ([x1], [y1]) ke ([x2], [y2]) selama [durationMs]. Bila titiknya sama,
     * hasilnya ketukan (atau tahan bila durasinya panjang). [onDone] dipanggil dari main thread saat
     * gerakan selesai atau dibatalkan, dengan true bila selesai. False bila sistem menolak gerakannya.
     */
    fun gesture(
        x1: Float, y1: Float, x2: Float, y2: Float,
        durationMs: Long,
        onDone: ((Boolean) -> Unit)? = null,
    ): Boolean {
        val path = Path().apply {
            moveTo(x1, y1)
            if (x1 != x2 || y1 != y2) lineTo(x2, y2)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceIn(1L, 60_000L))
        val g = GestureDescription.Builder().addStroke(stroke).build()
        val cb = if (onDone == null) null else object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { onDone?.invoke(true) }
            override fun onCancelled(gestureDescription: GestureDescription?) { onDone?.invoke(false) }
        }
        return dispatchGesture(g, cb, null)
    }
}

/** Menyalakan [TapService] lewat Shizuku/root supaya tidak perlu membuka pengaturan Aksesibilitas. */
object TapSetup {

    private val SAFE = Regex("^[A-Za-z0-9_.:/$-]*$")

    /** Blocking: panggil dari thread background. */
    fun enable(context: Context): CmdResult {
        val me = TapService.component(context).flattenToString()

        val current = ShellRunner.exec("settings get secure enabled_accessibility_services")
        if (!current.ok) {
            return CmdResult(false, current.out, current.err.ifBlank { "Tidak bisa membaca pengaturan Aksesibilitas." })
        }
        val raw = current.out.trim().let { if (it == "null") "" else it }
        if (!SAFE.matches(raw)) {
            // Daftar layanan lain berisi karakter tak terduga: jangan ditimpa, biar pengguna yang menyalakan.
            return CmdResult(false, "", "Daftar layanan aksesibilitas tidak dikenali. Nyalakan manual lewat Pengaturan.")
        }
        val items = raw.split(':').map { it.trim() }.filter { it.isNotEmpty() }
        val merged = (items + me).distinct().joinToString(":")

        val put = ShellRunner.exec("settings put secure enabled_accessibility_services '$merged'")
        if (!put.ok) return put
        return ShellRunner.exec("settings put secure accessibility_enabled 1")
    }
}
