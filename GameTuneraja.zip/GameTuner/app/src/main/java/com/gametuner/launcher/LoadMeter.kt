package com.gametuner.launcher

/**
 * Beban CPU dan GPU untuk cincin di panel bubble. Dibaca dari sistem lewat shell (Shizuku/root);
 * bila HP tidak menyediakan datanya hasilnya null dan panel menampilkan "—", bukan angka karangan.
 * Semua fungsi blocking dan harus dipanggil berurutan dari satu thread background.
 */
object LoadMeter {

    private var prevTotal = 0L
    private var prevIdle = 0L

    /** Jalur sysfs beban GPU yang umum, dicoba berurutan. Parser menerima keluaran `cat` jalur itu. */
    private class GpuSource(val path: String, val parse: (String) -> Int?)

    private fun firstInt(s: String): Int? = Regex("\\d+").find(s)?.value?.toIntOrNull()

    private val GPU_SOURCES = listOf(
        // Qualcomm Adreno
        GpuSource("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage") { firstInt(it) },
        GpuSource("/sys/class/kgsl/kgsl-3d0/gpubusy") { s ->
            val n = Regex("\\d+").findAll(s).mapNotNull { it.value.toLongOrNull() }.toList()
            if (n.size >= 2 && n[1] > 0) (n[0] * 100 / n[1]).toInt() else null
        },
        // MediaTek (GED)
        GpuSource("/sys/kernel/ged/hal/gpu_utilization") { firstInt(it) },
        // Mali
        GpuSource("/sys/devices/platform/*mali*/utilization") { firstInt(it) },
        GpuSource("/sys/class/misc/mali0/device/utilisation") { firstInt(it) },
        GpuSource("/proc/mali/utilization") { firstInt(it) },
    )

    /** Indeks sumber GPU yang berhasil; -1 = belum dicari, -2 = tidak ada yang bisa dibaca. */
    private var gpuIndex = -1

    private fun readCpuSample(): Pair<Long, Long>? {
        val r = ShellRunner.exec("head -n 1 /proc/stat")
        if (!r.ok) return null
        val parts = r.out.trim().split(Regex("\\s+"))
        if (parts.size < 8 || parts[0] != "cpu") return null
        val n = parts.drop(1).mapNotNull { it.toLongOrNull() }
        if (n.size < 7) return null
        val idle = n[3] + n[4]
        val total = n.take(8).sum()
        return total to idle
    }

    /** Beban CPU 0 sampai 100, atau null bila tidak terbaca. */
    fun cpuPercent(): Int? {
        if (prevTotal == 0L) {
            // Pembacaan pertama butuh pembanding: ambil dua contoh berjarak singkat.
            val first = readCpuSample() ?: return null
            prevTotal = first.first
            prevIdle = first.second
            Thread.sleep(400)
        }
        val now = readCpuSample() ?: return null
        val dTotal = now.first - prevTotal
        val dIdle = now.second - prevIdle
        prevTotal = now.first
        prevIdle = now.second
        if (dTotal <= 0) return null
        return ((dTotal - dIdle) * 100 / dTotal).toInt().coerceIn(0, 100)
    }

    /** Beban GPU 0 sampai 100, atau null bila HP ini tidak membuka datanya. */
    fun gpuPercent(): Int? {
        if (gpuIndex == -2) return null
        if (gpuIndex >= 0) {
            val src = GPU_SOURCES[gpuIndex]
            val r = ShellRunner.exec("cat ${src.path}")
            return if (r.ok) src.parse(r.out)?.coerceIn(0, 100) else null
        }
        for ((i, src) in GPU_SOURCES.withIndex()) {
            val r = ShellRunner.exec("cat ${src.path}")
            if (!r.ok) continue
            val v = src.parse(r.out) ?: continue
            gpuIndex = i
            return v.coerceIn(0, 100)
        }
        // Tidak ada sumber yang terbaca: jangan dicoba lagi tiap 3 detik.
        gpuIndex = -2
        return null
    }
}
