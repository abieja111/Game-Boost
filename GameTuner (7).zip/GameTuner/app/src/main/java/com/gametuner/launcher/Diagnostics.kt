package com.gametuner.launcher

import android.content.Context
import android.os.Build
import android.provider.Settings

enum class CheckLevel { OK, WARN, FAIL }

data class CheckItem(val title: String, val level: CheckLevel, val detail: String)

/**
 * Tes Kompatibilitas: mengecek fitur mana yang benar-benar didukung HP ini, supaya tidak perlu
 * menebak. Tidak mengubah pengaturan pengguna: uji Game Mode memakai paket aplikasi ini sendiri
 * (bukan game milik pengguna) dan langsung dibersihkan lagi.
 * Blocking: panggil dari thread background.
 */
object Diagnostics {

    fun run(context: Context, baseDpi: Int): List<CheckItem> {
        val out = mutableListOf<CheckItem>()

        // --- Perangkat
        val android = "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        out += CheckItem(
            "Perangkat",
            if (GameDownscale.available) CheckLevel.OK else CheckLevel.WARN,
            "${Build.MANUFACTURER} ${Build.MODEL}, $android." +
                if (GameDownscale.available) "" else " Resolusi/FPS per game butuh Android 14, jadi memakai cara seluruh layar.",
        )

        // --- Akses sistem
        val id = ShellRunner.exec("id")
        if (!id.ok) {
            out += CheckItem(
                "Akses sistem",
                CheckLevel.FAIL,
                id.err.ifBlank { "Shizuku belum jalan atau belum diberi izin." } +
                    " Tes lain butuh akses ini, jadi dihentikan.",
            )
            out += permissionItem(context)
            return out
        }
        val who = when {
            id.out.contains("uid=2000") -> "Shizuku (shell)"
            id.out.contains("uid=0") -> "root"
            else -> id.out.take(60)
        }
        out += CheckItem("Akses sistem", CheckLevel.OK, "Tersambung lewat $who.")

        // --- Game Mode
        val help = ShellRunner.exec("cmd game help")
        val helpText = (help.out + "\n" + help.err).lowercase()
        val hasDownscale = "downscale" in helpText
        val hasFps = "fps" in helpText
        out += CheckItem(
            "Game Mode: resolusi",
            if (hasDownscale) CheckLevel.OK else CheckLevel.WARN,
            if (hasDownscale) "Perintah downscale dikenal sistem."
            else "Perintah downscale tidak ditemukan. Resolusi per game tidak akan jalan; pakai cara seluruh layar.",
        )
        out += CheckItem(
            "Game Mode: FPS",
            if (hasFps) CheckLevel.OK else CheckLevel.WARN,
            if (hasFps) "Perintah batas FPS dikenal sistem."
            else "Perintah FPS tidak ditemukan. Batas FPS memakai kunci refresh rate layar.",
        )

        // --- Uji perintah pada paket aplikasi ini sendiri (bukan game pengguna)
        if (hasDownscale || hasFps) {
            val pkg = context.packageName
            try {
                if (hasDownscale) out += probe("Uji downscale", "cmd game set --downscale 0.9 $pkg", pkg, "0.9")
                if (hasFps) out += probe("Uji batas FPS", "cmd game set --fps 60 $pkg", pkg, null)
            } finally {
                ShellRunner.exec("cmd game reset $pkg")
                ShellRunner.exec("cmd game mode standard $pkg")
            }
        }

        // --- Layar, DPI
        val info = DisplayController.read()
        if (info == null) {
            out += CheckItem("Layar dan DPI", CheckLevel.WARN, "Ukuran dan DPI tidak terbaca (perintah wm).")
        } else {
            val saved = if (baseDpi > 0) "$baseDpi" else "Otomatis"
            val differs = baseDpi > 0 && baseDpi != info.curDpi
            out += CheckItem(
                "Layar dan DPI",
                if (differs) CheckLevel.WARN else CheckLevel.OK,
                "Ukuran ${info.curW}x${info.curH}, DPI real ${info.curDpi} (bawaan panel ${info.physDpi}). " +
                    "DPI Normal di Nexus: $saved." +
                    if (differs) " Angkanya beda dari DPI real: tombol Reset akan mengubah DPI ke angka Nexus." else "",
            )
        }

        // --- Refresh rate
        val rates = DisplayController.supportedRates(context)
        val hz = DisplayController.currentRefreshHz(context)
        val setting = ShellRunner.exec("settings get system peak_refresh_rate")
        out += CheckItem(
            "Refresh rate",
            if (setting.ok) CheckLevel.OK else CheckLevel.WARN,
            "Panel: ${if (rates.isEmpty()) "tidak terbaca" else rates.joinToString(", ") + " Hz"}, sekarang $hz Hz. " +
                if (setting.ok) "Pengaturan bisa dibaca dan diubah; efeknya tetap tergantung HP."
                else "Pengaturan tidak bisa dibaca: kunci refresh rate mungkin tidak jalan.",
        )

        // --- Pengukur FPS
        val layers = ShellRunner.exec("dumpsys SurfaceFlinger --list")
        val layerCount = layers.out.lines().count { it.isNotBlank() }
        out += CheckItem(
            "Pengukur FPS",
            if (layers.ok && layerCount > 0) CheckLevel.OK else CheckLevel.WARN,
            if (layers.ok && layerCount > 0) "Daftar layer layar terbaca ($layerCount). Angka FPS baru muncul saat game tampil."
            else "Data layar tidak terbaca: FPS di bubble akan tampil sebagai tanda strip.",
        )

        // --- Deteksi aplikasi di depan
        val fg = ForegroundWatcher.foregroundPackage()
        out += CheckItem(
            "Deteksi aplikasi di depan",
            if (fg != null) CheckLevel.OK else CheckLevel.WARN,
            if (fg != null) "Terbaca: $fg."
            else "Tidak terbaca: reset otomatis setelah game ditutup tidak bisa jalan. Tekan Selesai secara manual.",
        )

        // --- Izin
        out += permissionItem(context)

        // --- Trigger
        val tapOn = TapService.isEnabled(context)
        out += CheckItem(
            "Trigger (auto tap)",
            if (tapOn) CheckLevel.OK else CheckLevel.WARN,
            if (tapOn) "Layanan Aksesibilitas aktif: ketukan cepat."
            else "Layanan Aksesibilitas belum aktif: ketukan lewat Shizuku, lebih lambat (sekitar 3 sampai 5 per detik).",
        )
        return out
    }

    private fun permissionItem(context: Context): CheckItem {
        val ok = Settings.canDrawOverlays(context)
        return CheckItem(
            "Izin pop-up overlay",
            if (ok) CheckLevel.OK else CheckLevel.WARN,
            if (ok) "Diizinkan." else "Belum diizinkan: bubble dan Trigger tidak bisa tampil.",
        )
    }

    /** Jalankan satu perintah uji; hasil negatif dihaluskan karena aplikasi ini bukan game. */
    private fun probe(title: String, cmd: String, pkg: String, expect: String?): CheckItem {
        val r = ShellRunner.exec(cmd)
        if (GameDownscale.failed(r)) {
            val msg = r.err.ifBlank { r.out }.lines().firstOrNull().orEmpty().take(120)
            return CheckItem(
                title,
                CheckLevel.WARN,
                "Ditolak saat diuji pada aplikasi ini (bukan game): $msg. Belum tentu ditolak untuk game; coba langsung di game.",
            )
        }
        val check = ShellRunner.exec("cmd game list-configs $pkg")
        val verified = expect != null && check.ok && expect in check.out
        return CheckItem(
            title,
            CheckLevel.OK,
            if (verified) "Diterima dan tersimpan di konfigurasi Game Mode."
            else "Diterima oleh sistem. Efek nyatanya baru terlihat di game.",
        )
    }

    fun toText(items: List<CheckItem>): String = buildString {
        appendLine("Nexus Game Boost, Tes Kompatibilitas")
        for (i in items) {
            val tag = when (i.level) {
                CheckLevel.OK -> "[OK]"
                CheckLevel.WARN -> "[!]"
                CheckLevel.FAIL -> "[GAGAL]"
            }
            appendLine("$tag ${i.title}: ${i.detail}")
        }
    }
}
