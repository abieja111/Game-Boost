package com.gametuner.launcher

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.PowerManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min

/** Lingkaran bidik yang menandai titik yang akan diketuk. */
private class TargetView(context: Context) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3 * d
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    var running: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        val color = if (running) 0xFFFF6B5A.toInt() else 0xFFA78BFA.toInt()
        ring.color = color
        dot.color = color
        fill.color = if (running) 0x33FF6B5A else 0x33A78BFA

        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 3 * d
        canvas.drawCircle(cx, cy, r, fill)
        canvas.drawCircle(cx, cy, r, ring)
        val inner = r * 0.55f
        canvas.drawLine(cx, cy - r, cx, cy - inner, ring)
        canvas.drawLine(cx, cy + inner, cx, cy + r, ring)
        canvas.drawLine(cx - r, cy, cx - inner, cy, ring)
        canvas.drawLine(cx + inner, cy, cx + r, cy, ring)
        canvas.drawCircle(cx, cy, 3 * d, dot)
    }
}

/**
 * Trigger (auto tap): lingkaran bidik yang bisa digeser ke titik mana pun di layar, dan tombol kecil
 * dengan Mulai/Berhenti, kecepatan, dan Tutup. Setelah Mulai, titik itu diketuk berulang-ulang
 * sampai dihentikan, sampai batas ketukan tercapai, atau layar mati.
 *
 * Mengetuk memakai [TapService] (cepat) bila layanan aksesibilitas aktif; bila tidak, memakai
 * `input tap` lewat Shizuku/root (lebih lambat, sekitar 3 sampai 5 ketukan per detik).
 * Semua fungsi publik harus dipanggil dari main thread.
 */
class TriggerController(
    private val context: Context,
    private val wm: WindowManager,
    private val store: GameStore,
    private val main: Handler,
    private val onHidden: () -> Unit,
) {
    companion object {
        /** Pilihan kecepatan (ketukan per detik). */
        val SPEEDS = listOf(1, 2, 5, 10, 15, 20)

        /** Pilihan batas ketukan; 0 = tanpa batas. */
        val LIMITS = listOf(0, 50, 100, 500, 1000)

        private const val TAP_MS = 20L
        private const val MIN_INTERVAL_MS = 40L
        private const val MAX_FAILS = 15

        private const val FIRED = 1
        private const val SKIPPED = 0
        private const val FAILED = -1

        private const val WIN_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL

        private val COLOR_PANEL = 0xF2100B22.toInt()
        private val COLOR_BORDER = 0xFF3A1FA0.toInt()
        private val COLOR_GREEN = 0xFF34D399.toInt()
        private val COLOR_ALERT = 0xFFFF6B5A.toInt()
    }

    var shown: Boolean = false
        private set

    private val worker: ExecutorService = Executors.newSingleThreadExecutor()

    private var target: TargetView? = null
    private var targetLp: WindowManager.LayoutParams? = null
    private var pill: LinearLayout? = null
    private var pillLp: WindowManager.LayoutParams? = null
    private var playIcon: ImageView? = null
    private var speedLabel: TextView? = null

    private var running = false
    private var count = 0
    private var fails = 0

    @Volatile
    private var shellBusy = false

    fun setShown(on: Boolean) {
        if (on == shown) return
        if (on) show() else hide(notify = true)
    }

    /** Dipanggil saat layanan overlay dihentikan. */
    fun destroy() {
        hide(notify = false)
        worker.shutdownNow()
    }

    // ----------------------------------------------------------- tampilan

    private fun show() {
        val dm = context.resources.displayMetrics
        val size = dp(64)

        val t = TargetView(context)
        val tlp = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WIN_FLAGS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val cx = if (store.triggerX >= 0) store.triggerX else dm.widthPixels / 2
            val cy = if (store.triggerY >= 0) store.triggerY else dm.heightPixels / 2
            x = (cx - size / 2).coerceIn(0, maxOf(0, dm.widthPixels - size))
            y = (cy - size / 2).coerceIn(0, maxOf(0, dm.heightPixels - size))
            // Android 12 ke atas memblokir sentuhan yang menembus overlay yang terlalu pekat.
            alpha = 0.8f
        }
        makeDraggable(t, t, tlp, onTap = null) {
            store.triggerX = tlp.x + size / 2
            store.triggerY = tlp.y + size / 2
        }

        val play = ImageView(context).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        val speed = TextView(context).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            minWidth = dp(60)
        }
        val close = ImageView(context).apply {
            setImageResource(R.drawable.ic_close)
            imageTintList = ColorStateList.valueOf(Color.WHITE)
            setPadding(dp(11), dp(11), dp(11), dp(11))
        }
        val p = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(COLOR_PANEL)
                setStroke(dp(1), COLOR_BORDER)
            }
            addView(play, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(speed, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)))
            addView(close, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
        val plp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WIN_FLAGS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(200)
        }
        makeDraggable(p, p, plp, onTap = { x -> onPillTap(x) }) { }

        try {
            wm.addView(t, tlp)
            wm.addView(p, plp)
        } catch (e: Throwable) {
            runCatching { wm.removeView(t) }
            runCatching { wm.removeView(p) }
            toast("Trigger gagal ditampilkan: ${e.message ?: e.javaClass.simpleName}")
            return
        }

        target = t
        targetLp = tlp
        pill = p
        pillLp = plp
        playIcon = play
        speedLabel = speed
        shown = true
        render()
    }

    private fun hide(notify: Boolean) {
        stop()
        target?.let { v -> runCatching { wm.removeView(v) } }
        pill?.let { v -> runCatching { wm.removeView(v) } }
        target = null
        targetLp = null
        pill = null
        pillLp = null
        playIcon = null
        speedLabel = null
        val was = shown
        shown = false
        if (notify && was) onHidden()
    }

    private fun render() {
        val active = running
        playIcon?.apply {
            setImageResource(if (active) R.drawable.ic_stop else R.drawable.ic_play)
            imageTintList = ColorStateList.valueOf(if (active) COLOR_ALERT else COLOR_GREEN)
        }
        speedLabel?.text = if (active) "$count" else "${store.triggerCps}/dtk"
    }

    private fun onPillTap(x: Float) {
        val p = playIcon ?: return
        val l = speedLabel ?: return
        when {
            x < p.right -> if (running) stop() else start()
            x < l.right -> cycleSpeed()
            else -> hide(notify = true)
        }
    }

    private fun cycleSpeed() {
        if (running) return
        val i = SPEEDS.indexOf(store.triggerCps)
        store.triggerCps = SPEEDS[(i + 1) % SPEEDS.size]
        render()
    }

    // ------------------------------------------------------------ ketukan

    private fun start() {
        if (running || !shown) return
        if (TapService.instance != null) {
            begin()
            return
        }
        // Tanpa layanan aksesibilitas, ketukan dikirim lewat Shizuku/root; pastikan aksesnya ada.
        try {
            worker.execute {
                val mode = ShellRunner.detect()
                main.post {
                    if (!shown) return@post
                    if (mode == ShellRunner.Mode.NONE) {
                        toast("Nyalakan Layanan Aksesibilitas atau Shizuku dulu (Pengaturan, kartu Trigger).")
                    } else {
                        begin()
                    }
                }
            }
        } catch (_: Throwable) {
            // worker sudah dimatikan
        }
    }

    private fun begin() {
        if (running || !shown) return
        running = true
        count = 0
        fails = 0
        target?.running = true
        setTargetTouchable(false)
        render()
        main.removeCallbacks(tick)
        main.post(tick)
    }

    private fun stop() {
        if (!running) return
        running = false
        main.removeCallbacks(tick)
        target?.running = false
        setTargetTouchable(true)
        render()
    }

    /** Saat berjalan, lingkaran tidak boleh menangkap sentuhan supaya ketukan tembus ke game di bawahnya. */
    private fun setTargetTouchable(touchable: Boolean) {
        val v = target ?: return
        val lp = targetLp ?: return
        lp.flags = if (touchable) WIN_FLAGS else WIN_FLAGS or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        runCatching { wm.updateViewLayout(v, lp) }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val pm = context.getSystemService(PowerManager::class.java)
            if (pm != null && !pm.isInteractive) {
                stop()
                return
            }
            val t = target
            if (t == null) {
                stop()
                return
            }
            val loc = IntArray(2)
            t.getLocationOnScreen(loc)
            val x = loc[0] + t.width / 2f
            val y = loc[1] + t.height / 2f

            when (fire(x, y)) {
                FIRED -> {
                    fails = 0
                    count++
                    render()
                }
                FAILED -> fails++
                else -> Unit
            }
            if (fails >= MAX_FAILS) {
                stop()
                toast("Trigger berhenti: ketukan gagal terus. Cek Layanan Aksesibilitas atau Shizuku.")
                return
            }
            val limit = store.triggerLimit
            if (limit > 0 && count >= limit) {
                val done = count
                stop()
                toast("Trigger selesai: $done ketukan")
                return
            }
            val interval = (1000L / store.triggerCps.coerceIn(1, 20)).coerceAtLeast(MIN_INTERVAL_MS)
            main.postDelayed(this, interval)
        }
    }

    private fun fire(x: Float, y: Float): Int {
        val svc = TapService.instance
        if (svc != null) return if (svc.tap(x, y, TAP_MS)) FIRED else FAILED

        if (shellBusy) return SKIPPED
        shellBusy = true
        val xi = x.toInt()
        val yi = y.toInt()
        return try {
            worker.execute {
                try {
                    ShellRunner.exec("input tap $xi $yi")
                } finally {
                    shellBusy = false
                }
            }
            FIRED
        } catch (_: Throwable) {
            shellBusy = false
            FAILED
        }
    }

    // ------------------------------------------------------------ helpers

    /**
     * Geser jendela [window] dengan menyentuh [handle]. Ketukan singkat memanggil [onTap] dengan
     * posisi x sentuhan (relatif terhadap [handle]); setelah digeser, [onDropped] dipanggil.
     */
    private fun makeDraggable(
        handle: View,
        window: View,
        lp: WindowManager.LayoutParams,
        onTap: ((Float) -> Unit)?,
        onDropped: () -> Unit,
    ) {
        val slop = ViewConfiguration.get(context).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        runCatching { wm.updateViewLayout(window, lp) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) onDropped() else onTap?.invoke(e.x)
                    true
                }
                else -> false
            }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
    }

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()
}
