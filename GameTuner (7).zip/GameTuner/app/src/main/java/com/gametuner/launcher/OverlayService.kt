package com.gametuner.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.concurrent.Executors
import kotlin.math.abs

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** ScrollView yang tingginya dibatasi, supaya panel tidak lebih tinggi dari layar. */
private class MaxHeightScrollView(context: Context) : ScrollView(context) {
    var maxHeightPx: Int = 100_000
        set(value) {
            field = value
            requestLayout()
        }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val capped = View.MeasureSpec.makeMeasureSpec(maxHeightPx, View.MeasureSpec.AT_MOST)
        super.onMeasure(widthMeasureSpec, capped)
    }
}

/** Saklar berbentuk pil, digambar dengan View biasa supaya tampilannya sama di semua HP. */
private class PillSwitch(context: Context) : FrameLayout(context) {
    private val d = context.resources.displayMetrics.density
    private val thumb = View(context)

    var checked: Boolean = false
        set(value) {
            field = value
            render()
        }

    init {
        addView(
            thumb,
            FrameLayout.LayoutParams((18 * d).toInt(), (18 * d).toInt(), Gravity.CENTER_VERTICAL)
        )
        render()
    }

    private fun render() {
        background = GradientDrawable().apply {
            cornerRadius = 12 * d
            setColor(if (checked) 0xFF6D3CF5.toInt() else 0xFF2A2540.toInt())
        }
        thumb.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (checked) Color.WHITE else 0xFFC9C3DD.toInt())
        }
        val lp = thumb.layoutParams as FrameLayout.LayoutParams
        lp.marginStart = ((if (checked) 21 else 3) * d).toInt()
        thumb.layoutParams = lp
    }
}

/**
 * Bubble melayang di atas game. Ketuk untuk membuka panel Nexus: skala resolusi, batas FPS,
 * statistik langsung, Auto FPS, peringatan panas, Penghemat Baterai, dan Boost RAM.
 * Dibuat dengan View biasa (bukan Compose) supaya tidak butuh lifecycle owner di Service.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_RESET = "com.gametuner.launcher.RESET"
        const val ACTION_FINISH = "com.gametuner.launcher.FINISH"
        const val ACTION_TRIGGER = "com.gametuner.launcher.TRIGGER"
        private const val CHANNEL_ID = "overlay"
        private const val NOTIF_ID = 1
        private const val COLUMNS = 4

        // Pemantau game: cek tiap POLL_MS; reset bila game ditinggalkan terus-menerus selama GRACE_MS.
        private const val POLL_MS = 4000L
        private const val GRACE_MS = 12_000L
        private const val ARM_TIMEOUT_MS = 60_000L

        // Suhu, Auto FPS, dan Boost otomatis dicek tiap HEAT_POLL_MS.
        private const val HEAT_POLL_MS = 10_000L
        private const val DEFAULT_HOT_C = 44
        private const val AUTO_BOOST_COOLDOWN_MS = 90_000L
        private const val STATS_MS = 3000L

        private val COLOR_PANEL = 0xF2100B22.toInt()
        private val COLOR_BORDER = 0xFF3A1FA0.toInt()
        private val COLOR_DIVIDER = 0xFF241848.toInt()
        private val COLOR_CHIP = 0xFF1A1430.toInt()
        private val COLOR_CHIP_ACTIVE = 0xFF2A1A66.toInt()
        private val COLOR_TILE = 0xFF150F2C.toInt()
        private val COLOR_ACCENT = 0xFFA78BFA.toInt()
        private val COLOR_MUTED = 0xFFA79FC4.toInt()
        private val COLOR_GREEN = 0xFF34D399.toInt()
        private val COLOR_AMBER = 0xFFFFA94D.toInt()
        private val COLOR_ALERT = 0xFFFF6B5A.toInt()
        private val COLOR_PILL_BG = 0xFF0F3D2C.toInt()
    }

    private lateinit var wm: WindowManager
    private lateinit var store: GameStore
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var bubbleView: ImageView? = null
    private var panel: LinearLayout? = null
    private var scroll: MaxHeightScrollView? = null
    private var pillView: TextView? = null
    private var resStatus: TextView? = null
    private var fpsValue: TextView? = null
    private var tempValue: TextView? = null
    private var battValue: TextView? = null
    private var extraView: TextView? = null
    private var autoFpsSwitch: PillSwitch? = null
    private var heatSwitch: PillSwitch? = null
    private var saverSwitch: PillSwitch? = null
    private var triggerSwitch: PillSwitch? = null
    private var trigger: TriggerController? = null
    private val scaleChips = mutableMapOf<Int, TextView>()
    private val fpsChips = mutableMapOf<Int, TextView>()

    private var heatWarned = false
    private var measuringFps = false

    // Auto FPS: true bila KITA yang menurunkan FPS karena panas, jadi KITA yang menaikkannya lagi.
    private var autoFpsThrottled = false
    private var autoFpsBusy = false
    private var autoFpsPrev = 0
    private var lastAutoBoost = 0L

    // Pemantau game di depan: layar dikembalikan otomatis setelah game ditinggalkan.
    @Volatile private var alive = true
    private var finishing = false
    private var armed = false      // true setelah game pernah terlihat di depan
    private var awaySince = 0L     // 0 = game sedang di depan / belum dianggap ditinggalkan
    private var startedAt = 0L

    private val heatTick = object : Runnable {
        override fun run() {
            if (finishing) return
            checkHeatAndAuto()
            main.postDelayed(this, HEAT_POLL_MS)
        }
    }

    private val watchTick = object : Runnable {
        override fun run() {
            if (finishing) return
            val game = store.currentGame
            // Selama Trigger tampil, pemantau game dijeda: Trigger bisa dipakai di aplikasi apa pun.
            if (!store.autoReset || game == null || trigger?.shown == true) {
                main.postDelayed(this, POLL_MS)
                return
            }
            io.execute {
                val fg = ForegroundWatcher.foregroundPackage()
                main.post {
                    if (alive && !finishing) {
                        onForeground(fg, game)
                        if (!finishing) main.postDelayed(this, POLL_MS)
                    }
                }
            }
        }
    }

    /** Memperbarui statistik tiap 3 detik selama panel terbuka. */
    private val statsTick = object : Runnable {
        override fun run() {
            if (finishing || panel?.visibility != View.VISIBLE) return
            updateStatsViews()
            measureFps()
            main.postDelayed(this, STATS_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = GameStore(this)

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Bubble Nexus Game Boost", NotificationManager.IMPORTANCE_LOW)
        )
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin pop-up overlay belum aktif", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        trigger = TriggerController(this, wm, store, main) { triggerSwitch?.checked = false }
        buildOverlay()
        refreshStatus()
        startWatching()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RESET -> resetAll()
            ACTION_FINISH -> finishAndReset()
            ACTION_TRIGGER -> {
                trigger?.setShown(true)
                triggerSwitch?.checked = trigger?.shown == true
            }
            // dimulai lagi dari launcher (mungkin untuk game lain): mulai pantauan dari awal
            else -> resetWatchState()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        alive = false
        trigger?.destroy()
        trigger = null
        main.removeCallbacksAndMessages(null)
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        io.shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------ actions

    private fun applyScale(percent: Int) {
        resStatus?.text = "Mengatur…"
        io.execute {
            val game = store.currentGame
            val perGame = GameDownscale.enabled(store)
            val res = if (perGame) {
                if (game == null) {
                    CmdResult(false, "", "Belum ada game yang diluncurkan dari Nexus.")
                } else {
                    GameDownscale.apply(game, percent, store)
                }
            } else {
                val info = DisplayController.read()
                if (info == null) {
                    CmdResult(false, "", "Tidak ada akses sistem (Shizuku/root).")
                } else {
                    DisplayController.setScale(percent, store.scaleDensity, info, store)
                }
            }
            if (res.ok) {
                game?.let { store.setScale(it, percent) }
                if (perGame) toastFromBackground("Berlaku setelah game dibuka ulang")
            } else {
                toastFromBackground("Gagal: ${res.err.ifBlank { res.out }}")
            }
            refreshStatus()
        }
    }

    private fun applyFps(hz: Int) {
        io.execute {
            val game = store.currentGame
            // Game Mode untuk game ini bila diizinkan dan nilainya dikenal; kalau tidak, kunci refresh rate.
            val gm: CmdResult? =
                if (game != null && GameDownscale.fpsEnabled(store) && (hz == 0 || GameDownscale.fpsSupported(hz))) {
                    if (hz == 0 && GameDownscale.activeFps(game, store) == 0) {
                        CmdResult(true, "", "")
                    } else {
                        GameDownscale.applyFps(game, hz, store)
                    }
                } else {
                    null
                }
            val useLock = gm == null || !gm.ok
            val res = if (useLock && hz > 0) {
                DisplayController.setRefreshRate(hz, store)
            } else {
                DisplayController.resetRefreshRate(store)
            }
            if (res.ok) {
                game?.let { store.setFps(it, hz) }
                // Pengguna memilih sendiri; Auto FPS tidak boleh menimpanya lagi.
                main.post { autoFpsThrottled = false }
                if (hz > 0 && gm != null && !gm.ok) {
                    toastFromBackground("Game Mode menolak batas FPS, dipakai kunci refresh rate layar")
                } else if (hz > 0 && gm != null) {
                    toastFromBackground("Batas FPS game diatur. Buka ulang game bila belum terasa.")
                }
            } else {
                toastFromBackground("Gagal: ${res.err.ifBlank { res.out }}")
            }
            refreshStatus()
        }
    }

    private fun boost() {
        toastFromBackground("Boost berjalan…")
        io.execute {
            val out = Boost.run(this)
            main.post {
                Toast.makeText(this, Boost.message(out), Toast.LENGTH_LONG).show()
                updateStatsViews()
            }
        }
    }

    private fun resetAll() {
        autoFpsThrottled = false
        io.execute {
            DisplayController.resetAll(store)
            refreshStatus()
        }
    }

    private fun finishAndReset() {
        finishing = true
        autoFpsThrottled = false
        io.execute {
            DisplayController.resetAll(store)
            PlayMode.restore(store)
            main.post { stopSelf() }
        }
    }

    private fun startWatching() {
        resetWatchState()
        main.postDelayed(watchTick, POLL_MS)
        main.postDelayed(heatTick, HEAT_POLL_MS)
    }

    // --------------------------------------------- panas, Auto FPS, Boost

    private fun checkHeatAndAuto() {
        val temp = SystemStats.read(this).tempC
        checkHeat(temp)
        checkAutoFps(temp)
        checkAutoBoost()
    }

    /** Bandingkan suhu baterai dengan batas pengguna; ubah bubble dan beri pesan bila terlalu panas. */
    private fun checkHeat(temp: Float) {
        val limit = store.heatWarnC
        if (limit <= 0) {
            if (heatWarned) {
                heatWarned = false
                setAlert(false)
            }
            return
        }
        if (!heatWarned && temp >= limit) {
            heatWarned = true
            setAlert(true)
            Toast.makeText(
                this,
                String.format(java.util.Locale.US, "⚠ HP panas (%.1f°C). Turunkan resolusi/FPS atau istirahat sebentar.", temp),
                Toast.LENGTH_LONG
            ).show()
        } else if (heatWarned && temp < limit - 2) {
            heatWarned = false
            setAlert(false)
        }
    }

    /** Auto FPS: turun ke 60 Hz saat panas, kembali ke pilihan sebelumnya setelah suhu turun 3°C. */
    private fun checkAutoFps(temp: Float) {
        if (!store.autoFps || autoFpsBusy) return
        val limit = if (store.heatWarnC > 0) store.heatWarnC else DEFAULT_HOT_C

        if (!autoFpsThrottled && temp >= limit) {
            val rates = DisplayController.supportedRates(this)
            val target = rates.lastOrNull { it <= 60 } ?: rates.firstOrNull() ?: return
            autoFpsBusy = true
            io.execute {
                val current = DisplayController.readRefreshRate()
                if (current in 1..target) {
                    main.post { autoFpsBusy = false }
                    return@execute
                }
                val r = DisplayController.setRefreshRate(target, store)
                main.post {
                    autoFpsBusy = false
                    if (r.ok) {
                        autoFpsThrottled = true
                        autoFpsPrev = current
                        Toast.makeText(
                            this,
                            "Auto FPS: turun ke $target Hz karena HP panas",
                            Toast.LENGTH_LONG
                        ).show()
                        refreshStatus()
                    }
                }
            }
        } else if (autoFpsThrottled && temp < limit - 3) {
            restoreAutoFps()
        }
    }

    private fun restoreAutoFps() {
        if (!autoFpsThrottled || autoFpsBusy) return
        autoFpsBusy = true
        val prev = autoFpsPrev
        io.execute {
            val r = if (prev > 0) {
                DisplayController.setRefreshRate(prev, store)
            } else {
                DisplayController.resetRefreshRate(store)
            }
            main.post {
                autoFpsBusy = false
                if (r.ok) {
                    autoFpsThrottled = false
                    Toast.makeText(this, "Auto FPS: FPS dikembalikan", Toast.LENGTH_SHORT).show()
                    refreshStatus()
                }
            }
        }
    }

    /** Boost otomatis bila RAM bebas menipis; jeda 90 detik antar-boost supaya tidak berulang terus. */
    private fun checkAutoBoost() {
        if (!store.autoBoost) return
        val now = SystemClock.elapsedRealtime()
        if (lastAutoBoost != 0L && now - lastAutoBoost < AUTO_BOOST_COOLDOWN_MS) return
        val s = SystemStats.read(this)
        val low = s.ramFreeMb < maxOf(s.ramTotalMb * 12 / 100, 700L)
        if (!low) return
        lastAutoBoost = now
        io.execute {
            val out = Boost.run(this)
            main.post {
                Toast.makeText(this, "Boost otomatis. " + Boost.message(out), Toast.LENGTH_SHORT).show()
                updateStatsViews()
            }
        }
    }

    private fun setAlert(alert: Boolean) {
        bubbleView?.foreground = ring(alert)
        pillView?.apply {
            text = if (alert) "● PANAS" else "● ACTIVE"
            setTextColor(if (alert) COLOR_ALERT else COLOR_GREEN)
        }
    }

    // ----------------------------------------------------- pemantau game

    private fun resetWatchState() {
        armed = false
        awaySince = 0L
        startedAt = SystemClock.elapsedRealtime()
    }

    /**
     * Dipanggil di main thread dengan paket yang sedang di depan ([fg], null = tidak diketahui).
     * Fail-safe: layar hanya dikembalikan bila SECARA PASTI terlihat aplikasi lain di depan
     * terus-menerus selama [GRACE_MS]. Bila tidak yakin (null), tidak ada yang dilakukan.
     */
    private fun onForeground(fg: String?, game: String) {
        if (finishing || fg == null) return
        val now = SystemClock.elapsedRealtime()
        when {
            fg == game -> {
                armed = true
                awaySince = 0L
            }
            // Nexus sendiri di depan: pengguna mungkin sedang mengubah profil, jangan reset.
            fg == packageName -> awaySince = 0L
            // Aplikasi lain di depan. Baru dihitung setelah game pernah terlihat, atau setelah
            // ARM_TIMEOUT_MS bila game ternyata tidak pernah terbuka.
            armed || now - startedAt > ARM_TIMEOUT_MS -> {
                if (awaySince == 0L) {
                    awaySince = now
                } else if (now - awaySince >= GRACE_MS) {
                    toastFromBackground("Game ditutup, layar dikembalikan")
                    finishAndReset()
                }
            }
        }
    }

    private fun toastFromBackground(msg: String) {
        main.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    // ----------------------------------------------------------- statistik

    private fun clock(): String {
        val secs = (SystemClock.elapsedRealtime() - startedAt) / 1000
        return if (secs >= 3600) {
            String.format(java.util.Locale.US, "%d:%02d:%02d", secs / 3600, secs % 3600 / 60, secs % 60)
        } else {
            String.format(java.util.Locale.US, "%d:%02d", secs / 60, secs % 60)
        }
    }

    private fun heatColor(c: Float): Int = when {
        c >= 44f -> COLOR_ALERT
        c >= 38f -> COLOR_AMBER
        else -> COLOR_GREEN
    }

    private fun updateStatsViews() {
        val s = SystemStats.read(this)
        tempValue?.apply {
            text = String.format(java.util.Locale.US, "%.0f°C", s.tempC)
            setTextColor(heatColor(s.tempC))
        }
        battValue?.apply {
            text = "${s.batteryPct}%"
            setTextColor(if (s.batteryPct <= 15) COLOR_ALERT else COLOR_GREEN)
        }
        extraView?.text = String.format(java.util.Locale.US, "RAM %.1f GB bebas  ·  Main %s", s.ramFreeMb / 1024f, clock())
    }

    /** Perkiraan FPS game dari SurfaceFlinger; "—" bila HP tidak menyediakan datanya. */
    private fun measureFps() {
        val game = store.currentGame
        if (game == null) {
            fpsValue?.text = "—"
            return
        }
        if (measuringFps) return
        measuringFps = true
        io.execute {
            val fps = FpsMeter.measure(game)
            main.post {
                measuringFps = false
                fpsValue?.text = fps?.toString() ?: "—"
            }
        }
    }

    /** Skala game yang benar-benar aktif: 100 (asli) bila downscale-nya sudah dibersihkan oleh Reset. */
    private fun effectiveGameScale(game: String): Int = GameDownscale.activeScale(game, store)

    /** Baca resolusi dan refresh rate saat ini di background, lalu perbarui teks dan chip di main thread. */
    private fun refreshStatus() {
        io.execute {
            val info = DisplayController.read()
            val hz = if (info != null) DisplayController.readRefreshRate() else 0
            main.post {
                val perGame = GameDownscale.enabled(store)
                val game = store.currentGame
                val label = when {
                    perGame && game == null -> "Resolusi per game (belum ada game)"
                    perGame -> "Game ${DisplayController.scaleLabel(effectiveGameScale(game!!))} · layar tetap asli"
                    info == null -> "Akses sistem tidak tersedia"
                    info.isOverridden -> "${info.curW}×${info.curH} (${info.currentPercent}%)"
                    else -> "${info.physW}×${info.physH} (asli)"
                }
                val gameFps = game?.let { GameDownscale.activeFps(it, store) } ?: 0
                resStatus?.text = when {
                    gameFps > 0 -> "$label · maks $gameFps FPS"
                    hz > 0 -> "$label · $hz Hz"
                    else -> label
                }

                val activeScale = when {
                    perGame -> game?.let { g ->
                        DisplayController.PRESETS.minByOrNull { abs(it - effectiveGameScale(g)) }
                    }
                    info == null -> null
                    !info.isOverridden -> 100
                    else -> DisplayController.PRESETS.minByOrNull { abs(it - info.currentPercent) }
                }
                scaleChips.forEach { (p, v) -> styleChip(v, p == activeScale) }
                val activeFps = if (gameFps > 0) gameFps else hz
                fpsChips.forEach { (h, v) -> styleChip(v, h == activeFps) }

                main.postDelayed({ clamp() }, 600) // layar berubah ukuran, jaga bubble tetap terlihat
            }
        }
    }

    /** Sinkronkan saklar panel dengan pengaturan tersimpan dan status Penghemat Baterai saat ini. */
    private fun loadToggles() {
        autoFpsSwitch?.checked = store.autoFps
        heatSwitch?.checked = store.heatWarnC > 0
        triggerSwitch?.checked = trigger?.shown == true
        io.execute {
            val on = PlayMode.batterySaverOn() ?: false
            main.post { saverSwitch?.checked = on }
        }
    }

    // ------------------------------------------------------------ overlay

    private fun buildOverlay() {
        val bubble = ImageView(this).apply {
            setImageResource(R.drawable.logo_nx)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF0B0618.toInt())
            }
            foreground = ring(false)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        bubbleView = bubble

        val panelW = minOf(dp(300), resources.displayMetrics.widthPixels - dp(16))
        val panelView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(COLOR_PANEL)
                setStroke(dp(1), COLOR_BORDER)
            }
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(panelW, WRAP)
        }
        panel = panelView

        panelView.addView(buildHeader())
        panelView.addView(divider())

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(4), dp(14), dp(8))
        }
        val sv = MaxHeightScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        scroll = sv
        panelView.addView(sv, LinearLayout.LayoutParams(MATCH, WRAP))

        // --- Render Resolution
        content.addView(
            sectionHeader(
                R.drawable.ic_settings, "Render Resolution",
                info = "Skala resolusi game (hanya game ini, layar tetap asli). Makin kecil makin ringan, " +
                    "tapi gambar makin kabur. Berlaku setelah game dibuka ulang."
            )
        )
        chipGrid(DisplayController.PRESETS, scaleChips, { DisplayController.scaleLabel(it) }) {
            applyScale(it)
        }.forEach { content.addView(it) }
        resStatus = label("…", 10f, COLOR_MUTED).also {
            it.layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) }
            content.addView(it)
        }

        // --- FPS Limit
        val rates = listOf(0) + GameDownscale.fpsOptions(DisplayController.supportedRates(this), store.perGameFps)
        if (rates.size > 1) {
            content.addView(
                sectionHeader(
                    R.drawable.ic_bolt, "FPS Limit",
                    info = if (GameDownscale.fpsEnabled(store)) {
                        "Batas FPS khusus game ini (Game Mode). Nilai lain mengunci refresh rate layar. " +
                            "Auto = tanpa batas."
                    } else {
                        "Membatasi refresh rate layar. Auto = diatur otomatis oleh sistem."
                    }
                )
            )
            chipGrid(rates, fpsChips, { if (it == 0) "Auto" else "$it FPS" }) {
                applyFps(it)
            }.forEach { content.addView(it) }
        }

        // --- Live Statistics
        content.addView(sectionHeader(R.drawable.ic_chart, "Live Statistics"))
        val tiles = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val (fpsTile, fpsV) = statTile(R.drawable.ic_speed, COLOR_GREEN, "FPS", "—")
        val (tempTile, tempV) = statTile(R.drawable.ic_thermo, COLOR_AMBER, "Suhu HP", "—")
        val (battTile, battV) = statTile(R.drawable.ic_battery, COLOR_GREEN, "Baterai", "—")
        fpsValue = fpsV
        tempValue = tempV
        battValue = battV
        tiles.addView(fpsTile, tileParams(first = true))
        tiles.addView(tempTile, tileParams())
        tiles.addView(battTile, tileParams())
        content.addView(tiles, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        extraView = label("…", 10f, COLOR_MUTED).also {
            it.gravity = Gravity.CENTER
            it.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) }
            content.addView(it)
        }

        // --- Saklar
        content.addView(divider(top = dp(8), bottom = dp(4)))
        autoFpsSwitch = toggleRow(
            content, R.drawable.ic_speed, COLOR_ACCENT,
            "Auto FPS", "Turunkan FPS otomatis saat HP panas",
            badge = "A",
        ) { _, on ->
            store.autoFps = on
            if (!on) restoreAutoFps()
        }
        heatSwitch = toggleRow(
            content, R.drawable.ic_thermo, COLOR_ACCENT,
            "Temperature Warning", "Peringatan saat HP terlalu panas",
        ) { _, on ->
            if (on) {
                store.heatWarnC = store.lastHeatWarnC.takeIf { it > 0 } ?: DEFAULT_HOT_C
            } else {
                if (store.heatWarnC > 0) store.lastHeatWarnC = store.heatWarnC
                store.heatWarnC = 0
            }
        }
        saverSwitch = toggleRow(
            content, R.drawable.ic_leaf, COLOR_GREEN,
            "Battery Saver", "Hemat baterai, kurangi performa",
        ) { sw, on ->
            io.execute {
                val r = PlayMode.setBatterySaver(on, store)
                if (!r.ok) {
                    main.post {
                        sw.checked = !on
                        Toast.makeText(
                            this,
                            "Gagal: ${r.err.ifBlank { r.out }}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }

        triggerSwitch = toggleRow(
            content, R.drawable.ic_touch, COLOR_ACCENT,
            "Trigger", "Auto tap di titik pilihanmu",
        ) { _, on -> trigger?.setShown(on) }

        // --- Tombol aksi
        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(makeButton("Boost") { boost() }, weightParams())
        actionRow.addView(makeButton("Reset") { resetAll() }, weightParams())
        actionRow.addView(makeButton("Selesai") { finishAndReset() }, weightParams())
        content.addView(actionRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        // --- Kaki panel
        panelView.addView(divider())
        panelView.addView(buildFooter())

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bubble)
            addView(panelView)
        }
        root = container

        val lp = WindowManager.LayoutParams(
            WRAP,
            WRAP,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(120)
        }
        params = lp

        installDrag(bubble) { togglePanel() }
        wm.addView(container, lp)
    }

    private fun buildHeader(): LinearLayout {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(12), dp(10))
        }
        header.addView(icon(R.drawable.ic_gamepad, COLOR_ACCENT, 32))

        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label("NEXUS GAME BOOST", 14f, Color.WHITE, bold = true))
        titles.addView(label("Performance Control", 11f, COLOR_MUTED))
        header.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(10) })

        val pill = label("● ACTIVE", 10f, COLOR_GREEN, bold = true).apply {
            setPadding(dp(8), dp(3), dp(8), dp(3))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(COLOR_PILL_BG)
            }
        }
        pillView = pill
        header.addView(pill, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(10) })

        val close = icon(R.drawable.ic_close, Color.WHITE, 22).apply {
            setOnClickListener { togglePanel() }
        }
        header.addView(close)

        // Header dipakai untuk menggeser panel.
        installDrag(header, null)
        return header
    }

    private fun buildFooter(): LinearLayout {
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(12), dp(10))
        }
        footer.addView(icon(R.drawable.ic_trend, COLOR_ACCENT, 18))
        footer.addView(
            label("GAME PERFORMANCE PANEL", 10f, COLOR_MUTED, bold = true),
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(8) }
        )
        footer.addView(label("v1.0", 10f, Color.WHITE, bold = true).apply {
            setPadding(dp(8), dp(3), dp(8), dp(3))
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(0xFF6D3CF5.toInt())
            }
        })
        return footer
    }

    /**
     * Geser overlay dengan jari. [handle] adalah bagian yang disentuh; posisi yang diubah selalu
     * posisi overlay utama ([params] dan [root]), dibaca saat disentuh sehingga boleh dipasang
     * sebelum overlay selesai dibuat. Ketukan singkat memanggil [onTap].
     */
    private fun installDrag(handle: View, onTap: (() -> Unit)?) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        handle.setOnTouchListener { _, e ->
            val lp = params
            val target = root
            if (lp == null || target == null) return@setOnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        wm.updateViewLayout(target, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke() else clamp()
                    true
                }
                else -> false
            }
        }
    }

    private fun togglePanel() {
        val p = panel ?: return
        val b = bubbleView ?: return
        val opening = p.visibility != View.VISIBLE
        if (opening) {
            updateScrollMax()
            b.visibility = View.GONE
            p.visibility = View.VISIBLE
            refreshStatus()
            loadToggles()
            updateStatsViews()
            main.removeCallbacks(statsTick)
            main.post(statsTick)
        } else {
            p.visibility = View.GONE
            b.visibility = View.VISIBLE
            main.removeCallbacks(statsTick)
        }
        root?.post { clamp() }
    }

    /** Batasi tinggi isi panel agar seluruh panel (header + kaki) tetap muat di layar. */
    @Suppress("DEPRECATION")
    private fun updateScrollMax() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        scroll?.maxHeightPx = (dm.heightPixels - dp(130)).coerceAtLeast(dp(140))
    }

    /** Pastikan seluruh overlay (termasuk panel) berada di dalam layar. */
    @Suppress("DEPRECATION")
    private fun clamp() {
        val r = root ?: return
        val lp = params ?: return
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        val maxX = (dm.widthPixels - r.width).coerceAtLeast(0)
        val maxY = (dm.heightPixels - r.height).coerceAtLeast(0)
        lp.x = lp.x.coerceIn(0, maxX)
        lp.y = lp.y.coerceIn(0, maxY)
        runCatching { wm.updateViewLayout(r, lp) }
    }

    // ------------------------------------------------------------ helpers

    private fun ring(alert: Boolean) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.TRANSPARENT)
        setStroke(dp(2), if (alert) COLOR_ALERT else COLOR_ACCENT)
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun icon(res: Int, tint: Int, sizeDp: Int) = ImageView(this).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(tint)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun divider(top: Int = 0, bottom: Int = 0) = View(this).apply {
        setBackgroundColor(COLOR_DIVIDER)
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(1)).apply {
            topMargin = top
            bottomMargin = bottom
        }
    }

    /** Judul bagian. Bila [info] diisi, muncul ikon "i" yang menampilkan penjelasan singkat saat diketuk. */
    private fun sectionHeader(iconRes: Int, title: String, info: String? = null): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) }
        }
        row.addView(icon(iconRes, COLOR_ACCENT, 18))
        row.addView(
            label(title, 14f, Color.WHITE, bold = true),
            LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) }
        )
        if (info != null) {
            val infoIcon = icon(R.drawable.ic_info, COLOR_MUTED, 16)
            infoIcon.setOnClickListener {
                Toast.makeText(this, info, Toast.LENGTH_LONG).show()
            }
            row.addView(infoIcon, LinearLayout.LayoutParams(dp(16), dp(16)).apply { marginStart = dp(8) })
        }
        return row
    }

    /** Baris-baris chip ([COLUMNS] per baris), disimpan di [into] supaya bisa di-highlight. */
    private fun chipGrid(
        values: List<Int>,
        into: MutableMap<Int, TextView>,
        label: (Int) -> String,
        onClick: (Int) -> Unit,
    ): List<LinearLayout> = values.chunked(COLUMNS).map { group ->
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) }
            group.forEach { v ->
                val chip = makeButton(label(v)) { onClick(v) }
                into[v] = chip
                addView(chip, weightParams())
            }
            // isi slot kosong agar lebar chip di baris terakhir tetap sama
            repeat(COLUMNS - group.size) { addView(View(this@OverlayService), weightParams()) }
        }
    }

    private fun statTile(iconRes: Int, tint: Int, caption: String, value: String): Pair<LinearLayout, TextView> {
        val v = label(value, 18f, tint, bold = true).apply { gravity = Gravity.CENTER }
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(COLOR_TILE)
            }
        }
        tile.addView(icon(iconRes, tint, 20))
        tile.addView(v, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(2) })
        tile.addView(label(caption, 11f, Color.WHITE).apply { gravity = Gravity.CENTER })
        return tile to v
    }

    private fun tileParams(first: Boolean = false) =
        LinearLayout.LayoutParams(0, WRAP, 1f).apply { if (!first) marginStart = dp(6) }

    private fun toggleRow(
        parent: LinearLayout,
        iconRes: Int,
        tint: Int,
        title: String,
        subtitle: String,
        badge: String? = null,
        onChange: (PillSwitch, Boolean) -> Unit,
    ): PillSwitch {
        val sw = PillSwitch(this)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), 0, dp(6))
            setOnClickListener {
                sw.checked = !sw.checked
                onChange(sw, sw.checked)
            }
        }
        if (badge != null) {
            // Lingkaran berhuruf (mis. "A") sebagai pengganti ikon, seperti pada desain.
            val letter = label(badge, 12f, tint, bold = true)
            letter.gravity = Gravity.CENTER
            letter.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(2), tint)
            }
            row.addView(letter, LinearLayout.LayoutParams(dp(24), dp(24)))
        } else {
            row.addView(icon(iconRes, tint, 24))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, 13f, Color.WHITE))
        col.addView(label(subtitle, 11f, COLOR_MUTED))
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
            marginStart = dp(12)
            marginEnd = dp(8)
        })
        row.addView(sw, LinearLayout.LayoutParams(dp(42), dp(24)))
        parent.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        return sw
    }

    private fun makeButton(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(10), dp(2), dp(10))
            maxLines = 1
            styleChip(this, false)
            setOnClickListener { onClick() }
        }

    private fun styleChip(v: TextView, active: Boolean) {
        v.setTextColor(Color.WHITE)
        v.setTypeface(null, if (active) Typeface.BOLD else Typeface.NORMAL)
        v.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(if (active) COLOR_CHIP_ACTIVE else COLOR_CHIP)
            if (active) setStroke(dp(2), COLOR_ACCENT)
        }
    }

    private fun weightParams() =
        LinearLayout.LayoutParams(0, WRAP, 1f).apply {
            marginStart = dp(3)
            marginEnd = dp(3)
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildNotification(): Notification {
        fun pending(action: String, code: Int) = PendingIntent.getService(
            this, code,
            Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_bolt)
            .setContentTitle("Nexus Game Boost aktif")
            .setContentText("Ketuk bubble NX untuk atur resolusi dan FPS")
            .setContentIntent(open)
            .addAction(0, "Reset layar", pending(ACTION_RESET, 1))
            .addAction(0, "Selesai", pending(ACTION_FINISH, 2))
            .setOngoing(true)
            .build()
    }
}
