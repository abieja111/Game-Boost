package com.gametuner.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import kotlin.math.max

/** Tampilan crosshair: bentuk, warna, ukuran, ketebalan, transparansi, dan posisi (geser dari tengah layar). */
data class CrosshairConfig(
    val color: Int = 0xFFFF3B30.toInt(),
    /** Garis tengah atau diameter, dalam dp. */
    val sizeDp: Int = 28,
    val thickDp: Int = 2,
    val style: Int = STYLE_PLUS,
    /** 10 sampai 100. */
    val alphaPct: Int = 100,
    /** Geser dari tengah layar, dalam dp (negatif = ke kiri / ke atas). */
    val dxDp: Int = 0,
    val dyDp: Int = 0,
) {
    companion object {
        const val STYLE_PLUS = 0
        const val STYLE_DOT = 1
        const val STYLE_CIRCLE = 2
        const val STYLE_CROSS = 3
        const val STYLE_T = 4
        const val STYLE_RING_PLUS = 5
        const val STYLE_BRACKET = 6
        const val STYLE_SQUARE = 7
        const val STYLE_DIAMOND = 8
        const val STYLE_TRIANGLE = 9
        const val STYLE_DOUBLE_RING = 10
        const val STYLE_CHEVRON = 11
        const val STYLE_STAR = 12
        const val STYLE_LONG = 13
        const val STYLE_DASH = 14

        val STYLES = listOf(
            STYLE_PLUS, STYLE_DOT, STYLE_CIRCLE, STYLE_CROSS, STYLE_T, STYLE_RING_PLUS, STYLE_BRACKET,
            STYLE_SQUARE, STYLE_DIAMOND, STYLE_TRIANGLE, STYLE_DOUBLE_RING, STYLE_CHEVRON, STYLE_STAR,
            STYLE_LONG, STYLE_DASH
        )

        /** Ukuran siap pakai (dp) untuk tombol ganti ukuran cepat di pop-up. */
        val SIZES = listOf(16, 24, 32, 44, 60, 80, 110)

        fun styleName(style: Int): String = when (style) {
            STYLE_DOT -> "Titik"
            STYLE_CIRCLE -> "Lingkaran"
            STYLE_CROSS -> "Silang"
            STYLE_T -> "Huruf T"
            STYLE_RING_PLUS -> "Cincin Plus"
            STYLE_BRACKET -> "Siku"
            STYLE_SQUARE -> "Kotak"
            STYLE_DIAMOND -> "Berlian"
            STYLE_TRIANGLE -> "Segitiga"
            STYLE_DOUBLE_RING -> "Cincin Ganda"
            STYLE_CHEVRON -> "Chevron"
            STYLE_STAR -> "Bintang"
            STYLE_LONG -> "Plus Panjang"
            STYLE_DASH -> "Garis Datar"
            else -> "Plus"
        }

        /** Warna siap pakai: merah, oranye, kuning, hijau, cyan, biru, ungu, putih. */
        val COLORS = listOf(
            0xFFFF3B30.toInt(),
            0xFFFF9500.toInt(),
            0xFFFFE600.toInt(),
            0xFF34D399.toInt(),
            0xFF22D3EE.toInt(),
            0xFF3B82F6.toInt(),
            0xFFA855F7.toInt(),
            0xFFFFFFFF.toInt(),
        )
    }
}

/**
 * Menggambar crosshair di titik ([cx], [cy]). Dipakai oleh overlay dan oleh pratinjau di Pengaturan
 * (lewat canvas bawaan Android), jadi yang terlihat di pratinjau sama dengan yang tampil di game.
 * Gambar diberi garis tepi gelap tipis supaya tetap terbaca di latar terang.
 */
class CrosshairPainter {
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()

    fun draw(canvas: Canvas, cx: Float, cy: Float, cfg: CrosshairConfig, density: Float) {
        val a = cfg.alphaPct.coerceIn(10, 100) * 255 / 100
        val half = cfg.sizeDp.coerceAtLeast(4) * density / 2f
        val t = cfg.thickDp.coerceAtLeast(1) * density
        val gap = half * 0.32f
        val main = (cfg.color and 0x00FFFFFF) or (a shl 24)
        val edge = (a * 6 / 10 shl 24)

        for (pass in 0..1) {
            val outline = pass == 0
            val color = if (outline) edge else main
            stroke.strokeWidth = if (outline) t + 2f * density else t
            stroke.color = color
            fill.color = color
            val grow = if (outline) density else 0f

            when (cfg.style) {
                CrosshairConfig.STYLE_DOT ->
                    canvas.drawCircle(cx, cy, max(half / 3f, t) + grow, fill)

                CrosshairConfig.STYLE_CIRCLE -> {
                    canvas.drawCircle(cx, cy, half * 0.8f, stroke)
                    canvas.drawCircle(cx, cy, t * 0.8f + grow, fill)
                }

                CrosshairConfig.STYLE_CROSS -> {
                    val g = gap * 0.7f
                    val d = half * 0.7f
                    canvas.drawLine(cx - g, cy - g, cx - d, cy - d, stroke)
                    canvas.drawLine(cx + g, cy - g, cx + d, cy - d, stroke)
                    canvas.drawLine(cx - g, cy + g, cx - d, cy + d, stroke)
                    canvas.drawLine(cx + g, cy + g, cx + d, cy + d, stroke)
                }

                CrosshairConfig.STYLE_T -> {
                    // Tanpa lengan atas: enak buat membidik karena kepala target tidak tertutup.
                    canvas.drawLine(cx, cy + gap, cx, cy + half, stroke)
                    canvas.drawLine(cx - half, cy, cx - gap, cy, stroke)
                    canvas.drawLine(cx + gap, cy, cx + half, cy, stroke)
                    canvas.drawCircle(cx, cy, t * 0.8f + grow, fill)
                }

                CrosshairConfig.STYLE_RING_PLUS -> {
                    val r = half * 0.62f
                    canvas.drawCircle(cx, cy, r, stroke)
                    canvas.drawLine(cx, cy - half, cx, cy - r, stroke)
                    canvas.drawLine(cx, cy + r, cx, cy + half, stroke)
                    canvas.drawLine(cx - half, cy, cx - r, cy, stroke)
                    canvas.drawLine(cx + r, cy, cx + half, cy, stroke)
                }

                CrosshairConfig.STYLE_BRACKET -> {
                    // Empat siku di sudut kotak, dengan titik kecil di tengah.
                    val b = half * 0.8f
                    val l = half * 0.38f
                    canvas.drawLine(cx - b, cy - b, cx - b + l, cy - b, stroke)
                    canvas.drawLine(cx - b, cy - b, cx - b, cy - b + l, stroke)
                    canvas.drawLine(cx + b, cy - b, cx + b - l, cy - b, stroke)
                    canvas.drawLine(cx + b, cy - b, cx + b, cy - b + l, stroke)
                    canvas.drawLine(cx - b, cy + b, cx - b + l, cy + b, stroke)
                    canvas.drawLine(cx - b, cy + b, cx - b, cy + b - l, stroke)
                    canvas.drawLine(cx + b, cy + b, cx + b - l, cy + b, stroke)
                    canvas.drawLine(cx + b, cy + b, cx + b, cy + b - l, stroke)
                    canvas.drawCircle(cx, cy, t * 0.8f + grow, fill)
                }

                CrosshairConfig.STYLE_SQUARE -> {
                    val b = half * 0.7f
                    canvas.drawRect(cx - b, cy - b, cx + b, cy + b, stroke)
                    canvas.drawCircle(cx, cy, t * 0.8f + grow, fill)
                }

                CrosshairConfig.STYLE_DIAMOND -> {
                    val b = half * 0.85f
                    path.reset()
                    path.moveTo(cx, cy - b)
                    path.lineTo(cx + b, cy)
                    path.lineTo(cx, cy + b)
                    path.lineTo(cx - b, cy)
                    path.close()
                    canvas.drawPath(path, stroke)
                    canvas.drawCircle(cx, cy, t * 0.8f + grow, fill)
                }

                CrosshairConfig.STYLE_TRIANGLE -> {
                    val b = half * 0.85f
                    path.reset()
                    path.moveTo(cx, cy - b)
                    path.lineTo(cx + b, cy + b * 0.8f)
                    path.lineTo(cx - b, cy + b * 0.8f)
                    path.close()
                    canvas.drawPath(path, stroke)
                    canvas.drawCircle(cx, cy, t * 0.8f + grow, fill)
                }

                CrosshairConfig.STYLE_DOUBLE_RING -> {
                    canvas.drawCircle(cx, cy, half * 0.85f, stroke)
                    canvas.drawCircle(cx, cy, half * 0.45f, stroke)
                    canvas.drawCircle(cx, cy, t * 0.8f + grow, fill)
                }

                CrosshairConfig.STYLE_CHEVRON -> {
                    // Tanda "^" dengan ujung tepat di titik bidik.
                    val w = half * 0.75f
                    val h = half * 0.8f
                    path.reset()
                    path.moveTo(cx - w, cy + h)
                    path.lineTo(cx, cy)
                    path.lineTo(cx + w, cy + h)
                    canvas.drawPath(path, stroke)
                    canvas.drawCircle(cx, cy, t * 0.8f + grow, fill)
                }

                CrosshairConfig.STYLE_STAR -> {
                    // Bintang empat sudut (sisi melengkung ke dalam).
                    val k = half * 0.2f
                    path.reset()
                    path.moveTo(cx, cy - half)
                    path.lineTo(cx + k, cy - k)
                    path.lineTo(cx + half, cy)
                    path.lineTo(cx + k, cy + k)
                    path.lineTo(cx, cy + half)
                    path.lineTo(cx - k, cy + k)
                    path.lineTo(cx - half, cy)
                    path.lineTo(cx - k, cy - k)
                    path.close()
                    if (outline) canvas.drawPath(path, stroke) else canvas.drawPath(path, fill)
                }

                CrosshairConfig.STYLE_LONG -> {
                    // Plus panjang dengan celah besar di tengah dan tanpa titik.
                    val g = half * 0.45f
                    canvas.drawLine(cx, cy - half, cx, cy - g, stroke)
                    canvas.drawLine(cx, cy + g, cx, cy + half, stroke)
                    canvas.drawLine(cx - half, cy, cx - g, cy, stroke)
                    canvas.drawLine(cx + g, cy, cx + half, cy, stroke)
                }

                CrosshairConfig.STYLE_DASH -> {
                    canvas.drawLine(cx - half, cy, cx - gap, cy, stroke)
                    canvas.drawLine(cx + gap, cy, cx + half, cy, stroke)
                    canvas.drawCircle(cx, cy, t * 0.8f + grow, fill)
                }

                else -> {
                    canvas.drawLine(cx, cy - half, cx, cy - gap, stroke)
                    canvas.drawLine(cx, cy + gap, cx, cy + half, stroke)
                    canvas.drawLine(cx - half, cy, cx - gap, cy, stroke)
                    canvas.drawLine(cx + gap, cy, cx + half, cy, stroke)
                    canvas.drawCircle(cx, cy, t * 0.8f + grow, fill)
                }
            }
        }
    }
}

private class CrosshairView(context: Context) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val painter = CrosshairPainter()

    var cfg: CrosshairConfig = CrosshairConfig()
        set(value) {
            field = value
            invalidate()
        }

    override fun onDraw(canvas: Canvas) {
        painter.draw(canvas, width / 2f, height / 2f, cfg, d)
    }
}

/**
 * Crosshair melayang di tengah layar (bisa digeser lewat pengaturan). Tidak menangkap sentuhan,
 * jadi semua sentuhan tetap sampai ke game. Pengaturan dibaca ulang tiap detik selama tampil,
 * sehingga perubahan di Pengaturan langsung terlihat. Semua fungsi publik dipanggil dari main thread.
 */
class CrosshairController(
    private val context: Context,
    private val wm: WindowManager,
    private val store: GameStore,
    private val main: Handler,
    private val onHidden: () -> Unit,
) {
    companion object {
        private const val TICK_MS = 1000L
    }

    var shown: Boolean = false
        private set

    private var view: CrosshairView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var applied: CrosshairConfig? = null

    fun setShown(on: Boolean) {
        if (on == shown) return
        if (on) show() else hide(notify = true)
    }

    /** Dipanggil saat layanan overlay dihentikan. */
    fun destroy() {
        hide(notify = false)
    }

    private fun show() {
        val cfg = store.crosshair
        val v = CrosshairView(context).also { it.cfg = cfg }
        val size = sizeFor(cfg)
        val params = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = dp(cfg.dxDp)
            y = dp(cfg.dyDp)
            // Android 12 ke atas memblokir sentuhan yang menembus overlay yang terlalu pekat.
            alpha = windowAlpha()
        }
        try {
            wm.addView(v, params)
        } catch (e: Throwable) {
            Toast.makeText(
                context,
                "Crosshair gagal ditampilkan: ${e.message ?: e.javaClass.simpleName}",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        view = v
        lp = params
        applied = cfg
        shown = true
        main.removeCallbacks(tick)
        main.postDelayed(tick, TICK_MS)
    }

    private fun hide(notify: Boolean) {
        main.removeCallbacks(tick)
        view?.let { v -> runCatching { wm.removeView(v) } }
        view = null
        lp = null
        applied = null
        val was = shown
        shown = false
        if (notify && was) onHidden()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!shown) return
            val cfg = store.crosshair
            if (cfg != applied) apply(cfg)
            syncAlpha()
            main.postDelayed(this, TICK_MS)
        }
    }

    /**
     * Android 12 menjumlahkan kepekatan semua overlay yang menembus sentuhan dari satu aplikasi. Saat filter layar
     * menyala, crosshair diberi alpha lebih rendah supaya jumlahnya tetap di bawah batas 0,8 dan sentuhan di
     * sekitar crosshair tidak terblokir.
     */
    private fun windowAlpha(): Float = if (store.filterPreset != 0) 0.55f else 0.8f

    private fun syncAlpha() {
        val v = view ?: return
        val params = lp ?: return
        val want = windowAlpha()
        if (params.alpha == want) return
        params.alpha = want
        runCatching { wm.updateViewLayout(v, params) }
    }

    private fun apply(cfg: CrosshairConfig) {
        val v = view ?: return
        val params = lp ?: return
        val size = sizeFor(cfg)
        params.width = size
        params.height = size
        params.x = dp(cfg.dxDp)
        params.y = dp(cfg.dyDp)
        runCatching { wm.updateViewLayout(v, params) }
        v.cfg = cfg
        applied = cfg
    }

    /** Jendela dibuat sedikit lebih besar dari gambarnya supaya garis tepi tidak terpotong. */
    private fun sizeFor(cfg: CrosshairConfig): Int = dp(cfg.sizeDp + cfg.thickDp * 2 + 10)

    private fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()
}
