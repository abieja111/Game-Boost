package com.gametuner.launcher

/**
 * Empat mode performa, dipilih dari pop-up (kotak di kanan, di bawah pengukur GPU/RAM):
 *
 * - **Hemat Baterai:** resolusi 80%, FPS rendah (30 bila ada), Penghemat Baterai Android dinyalakan.
 * - **Balance:** normal. Resolusi Asli, FPS Auto, dan semua yang tadi diubah mode lain dikembalikan.
 * - **Awaken:** performa tinggi. Resolusi 90%, FPS tertinggi sampai 90, lalu Boost RAM.
 * - **Gamma:** performa tertinggi. Resolusi 70%, FPS setinggi yang didukung, Boost RAM, Jangan Ganggu,
 *   dan mode kinerja tetap Android (`cmd power set-fixed-performance-mode-enabled`, bila HP mendukung).
 *
 * Resolusi dan FPS dipasang lewat jalur yang sama dengan pilihan manual (Render Resolution dan FPS Limit),
 * jadi bisa diubah lagi sesudahnya. Aturan keselamatan sama seperti PlayMode: hanya memulihkan yang KITA ubah.
 * Fungsi yang memanggil shell bersifat blocking: panggil dari thread background.
 */
object PerfMode {
    const val SAVER = 0
    const val BALANCE = 1
    const val AWAKEN = 2
    const val GAMMA = 3

    val ALL = listOf(SAVER, BALANCE, AWAKEN, GAMMA)

    fun name(mode: Int): String = when (mode) {
        SAVER -> "Hemat Baterai"
        AWAKEN -> "Awaken"
        GAMMA -> "Gamma"
        else -> "Balance"
    }

    fun hint(mode: Int): String = when (mode) {
        SAVER -> "resolusi turun, FPS rendah, Penghemat Baterai menyala"
        AWAKEN -> "performa tinggi: FPS tinggi + Boost RAM"
        GAMMA -> "performa tertinggi: FPS maksimal, Boost RAM, Jangan Ganggu"
        else -> "normal: resolusi Asli dan FPS Auto"
    }

    /** Resolusi render (persen) tiap mode. */
    fun scale(mode: Int): Int = when (mode) {
        SAVER -> 80
        AWAKEN -> 90
        GAMMA -> 70
        else -> 100
    }

    /** Pilih batas FPS dari [options] (0 = Auto, tidak dipilih): Hemat paling rendah mulai 30, Awaken sampai 90, Gamma tertinggi. */
    fun pickFps(mode: Int, options: List<Int>): Int {
        val opts = options.filter { it > 0 }.distinct().sorted()
        if (opts.isEmpty()) return 0
        return when (mode) {
            SAVER -> opts.firstOrNull { it >= 30 } ?: opts.first()
            AWAKEN -> opts.lastOrNull { it <= 90 } ?: opts.first()
            GAMMA -> opts.last()
            else -> 0
        }
    }

    /** Hemat Baterai menyalakan Penghemat Baterai; mode lain mematikannya HANYA bila kita yang menyalakannya. */
    fun setSaver(on: Boolean, store: GameStore): CmdResult {
        if (on) {
            if (store.perfSaverSet) return CmdResult(true, "", "")
            // Sudah menyala (atau tidak terbaca): jangan disentuh.
            if (PlayMode.batterySaverOn() != false) return CmdResult(true, "", "")
            val r = ShellRunner.exec("settings put global low_power 1")
            if (r.ok) store.perfSaverSet = true
            return r
        }
        if (!store.perfSaverSet) return CmdResult(true, "", "")
        val r = ShellRunner.exec("settings put global low_power 0")
        if (r.ok) store.perfSaverSet = false
        return r
    }

    /** Mode kinerja tetap (dipakai Gamma). Tidak semua HP mendukung; gagal bukan masalah besar. */
    fun setFixed(on: Boolean, store: GameStore): CmdResult {
        if (on) {
            if (store.perfFixedSet) return CmdResult(true, "", "")
            val r = ShellRunner.exec("cmd power set-fixed-performance-mode-enabled true")
            if (GameDownscale.failed(r)) return CmdResult(false, r.out, r.err.ifBlank { r.out })
            store.perfFixedSet = true
            return CmdResult(true, r.out, r.err)
        }
        if (!store.perfFixedSet) return CmdResult(true, "", "")
        val r = ShellRunner.exec("cmd power set-fixed-performance-mode-enabled false")
        if (r.ok) store.perfFixedSet = false
        return r
    }

    /** Jangan Ganggu untuk Gamma: dinyalakan hanya bila belum menyala, dan dimatikan lagi hanya bila kita yang menyalakan. */
    fun setFocus(on: Boolean, store: GameStore): CmdResult {
        if (on) {
            if (store.focusMode) return CmdResult(true, "", "")
            val r = PlayMode.setFocus(true, store)
            if (r.ok) store.perfFocusSet = true
            return r
        }
        if (!store.perfFocusSet) return CmdResult(true, "", "")
        val r = PlayMode.setFocus(false, store)
        store.perfFocusSet = false
        return r
    }

    /** Kembalikan semua yang diubah mode performa dan set mode ke Balance. Panggil SEBELUM [PlayMode.restore]. */
    fun restore(store: GameStore) {
        setSaver(false, store)
        setFixed(false, store)
        setFocus(false, store)
        store.perfMode = BALANCE
    }
}
