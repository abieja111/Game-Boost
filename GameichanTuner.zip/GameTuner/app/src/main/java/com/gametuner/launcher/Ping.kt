package com.gametuner.launcher

import java.net.InetSocketAddress
import java.net.Socket

/**
 * Ping (latensi jaringan) ke server publik: waktu yang dibutuhkan membuka sambungan TCP. Ini bukan ping
 * ke server game, tapi cukup untuk melihat jaringan sedang lancar atau lag. Hasil terakhir disimpan
 * sebentar sehingga HUD dan pop-up tidak mengukur dua kali. Dipanggil dari thread background.
 */
object PingMeter {
    private val targets = listOf("1.1.1.1" to 443, "8.8.8.8" to 443)
    private const val TIMEOUT_MS = 1500

    @Volatile
    var last: Int? = null
        private set

    @Volatile
    private var lastAt = 0L

    /** Ping dalam milidetik, atau null bila tidak ada jaringan. Memakai hasil terakhir bila masih baru. */
    fun measure(maxAgeMs: Long = 4000L): Int? {
        val now = System.currentTimeMillis()
        if (now - lastAt < maxAgeMs) return last
        var result: Int? = null
        for ((host, port) in targets) {
            val ms = connectMs(host, port)
            if (ms != null) {
                result = ms
                break
            }
        }
        last = result
        lastAt = System.currentTimeMillis()
        return result
    }

    private fun connectMs(host: String, port: Int): Int? = try {
        Socket().use { s ->
            val t0 = System.nanoTime()
            s.connect(InetSocketAddress(host, port), TIMEOUT_MS)
            ((System.nanoTime() - t0) / 1_000_000L).toInt().coerceAtLeast(1)
        }
    } catch (_: Throwable) {
        null
    }

    /** Warna menurut kualitas: bagus sampai 60 ms, sedang sampai 120 ms, lalu buruk. */
    fun quality(ms: Int): Int = when {
        ms <= 60 -> 0
        ms <= 120 -> 1
        else -> 2
    }
}
