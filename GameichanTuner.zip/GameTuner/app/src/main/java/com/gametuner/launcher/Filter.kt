package com.gametuner.launcher

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast

/**
 * Filter layar: lapisan berwarna tipis di atas game yang tidak menangkap sentuhan. Hanya bisa mewarnai,
 * meredupkan, atau mencerahkan (tidak mengubah kontras atau saturasi seperti pengolah warna bawaan layar).
 * 0 = mati.
 */
object ScreenFilter {
    const val COUNT = 7
    const val MIN_PCT = 5
    const val MAX_PCT = 45
    const val DEFAULT_PCT = 25

    fun name(preset: Int): String = when (preset) {
        1 -> "Hangat"
        2 -> "Sejuk"
        3 -> "Hijau"
        4 -> "Sepia"
        5 -> "Merah"
        6 -> "Gelap"
        7 -> "Intai"
        else -> "Mati"
    }

    fun hint(preset: Int): String = when (preset) {
        1 -> "Kurangi cahaya biru, nyaman untuk mata"
        2 -> "Nuansa biru yang dingin"
        3 -> "Nuansa hijau seperti kacamata malam"
        4 -> "Nuansa cokelat seperti foto lawas"
        5 -> "Merah, tidak menyilaukan di tempat gelap"
        6 -> "Redupkan layar lebih rendah dari kecerahan terendah"
        7 -> "Terangkan area gelap supaya musuh di bayangan lebih terlihat"
        else -> "Tanpa filter"
    }

    fun color(preset: Int): Int = when (preset) {
        1 -> 0xFFFF9A3C.toInt()
        2 -> 0xFF4D8DFF.toInt()
        3 -> 0xFF34D399.toInt()
        4 -> 0xFF8B5A2B.toInt()
        5 -> 0xFFFF3B30.toInt()
        6 -> 0xFF000000.toInt()
        7 -> 0xFFC9D4E8.toInt()
        else -> 0xFF000000.toInt()
    }

    /** Pengali kekuatan: lapisan terang (Intai) cepat membuat gambar pucat, jadi dibuat lebih tipis. */
    fun scale(preset: Int): Float = if (preset == 7) 0.6f else 1f
}

/**
 * Jendela filter layar. Dipasang paling awal (lihat [start]) supaya berada di bawah overlay Nexus yang lain,
 * sehingga pop-up, HUD, dan crosshair tidak ikut diwarnai. Jendelanya selalu ada tetapi kosong saat filter
 * mati. Pengaturan dibaca ulang tiap detik, jadi perubahan dari Pengaturan langsung terlihat.
 * Semua fungsi dipanggil dari main thread.
 */
class FilterController(
    private val context: Context,
    private val wm: WindowManager,
    private val store: GameStore,
    private val main: Handler,
) {
    companion object {
        private const val TICK_MS = 1000L
    }

    private var view: View? = null
    private var lp: WindowManager.LayoutParams? = null
    private var applied: Pair<Int, Int>? = null

    fun start() {
        if (view != null) return
        val v = View(context).apply { visibility = View.GONE }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Android 12 ke atas memblokir sentuhan yang menembus overlay dengan alpha jendela di atas 0,8.
            // Alpha jendela dipakai sebagai kekuatan filter, jadi selalu jauh di bawah batas itu.
            alpha = 0f
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            wm.addView(v, params)
        } catch (e: Throwable) {
            Toast.makeText(
                context,
                "Filter layar gagal dipasang: ${e.message ?: e.javaClass.simpleName}",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        view = v
        lp = params
        refresh()
        main.removeCallbacks(tick)
        main.postDelayed(tick, TICK_MS)
    }

    /** Terapkan pengaturan filter saat ini. Aman dipanggil kapan saja. */
    fun refresh() {
        val v = view ?: return
        val params = lp ?: return
        val preset = store.filterPreset
        val pct = store.filterPct
        val key = preset to pct
        if (key == applied) return
        applied = key
        if (preset <= 0) {
            v.visibility = View.GONE
            params.alpha = 0f
        } else {
            v.setBackgroundColor(ScreenFilter.color(preset))
            v.visibility = View.VISIBLE
            params.alpha = (pct / 100f * ScreenFilter.scale(preset)).coerceIn(0.02f, 0.6f)
        }
        runCatching { wm.updateViewLayout(v, params) }
    }

    /** Dipanggil saat layanan overlay dihentikan. */
    fun destroy() {
        main.removeCallbacks(tick)
        view?.let { v -> runCatching { wm.removeView(v) } }
        view = null
        lp = null
        applied = null
    }

    private val tick = object : Runnable {
        override fun run() {
            if (view == null) return
            refresh()
            main.postDelayed(this, TICK_MS)
        }
    }
}
