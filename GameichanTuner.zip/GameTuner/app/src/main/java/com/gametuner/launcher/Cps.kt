package com.gametuner.launcher

import android.content.Context
import android.graphics.PixelFormat
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

/**
 * Penghitung CPS (ketukan per detik) selagi main. Android tidak membolehkan aplikasi membaca sentuhan di
 * aplikasi lain, tetapi sebuah jendela kecil (1 x 1 piksel) yang meminta FLAG_WATCH_OUTSIDE_TOUCH diberi tahu
 * tiap ada sentuhan di luar jendelanya (tanpa koordinat). Itu cukup untuk menghitung ketukan. Sentuhan
 * tidak dicegat, jadi game tetap menerima semuanya.
 *
 * Batasan: yang dihitung adalah sentuhan pertama tiap ketukan (jari kedua yang mengetuk saat jari pertama masih
 * menahan tidak terhitung), dan sebagian HP atau versi Android mungkin tidak mengirim kejadian itu (angka tetap 0).
 * Semua fungsi dipanggil dari main thread.
 */
class CpsMeter(
    private val context: Context,
    private val wm: WindowManager,
) {
    private val stamps = ArrayDeque<Long>()
    private var view: View? = null

    /** Ketukan tertinggi dalam satu detik sejak [start]. */
    var peak: Int = 0
        private set

    fun start() {
        if (view != null) return
        val v = View(context)
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_OUTSIDE || e.actionMasked == MotionEvent.ACTION_DOWN) {
                record()
            }
            false
        }
        val params = WindowManager.LayoutParams(
            1,
            1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
            alpha = 0f
        }
        try {
            wm.addView(v, params)
            view = v
            stamps.clear()
            peak = 0
        } catch (_: Throwable) {
            view = null
        }
    }

    fun stop() {
        view?.let { v -> runCatching { wm.removeView(v) } }
        view = null
        stamps.clear()
    }

    private fun record() {
        stamps.addLast(SystemClock.uptimeMillis())
        val n = cps()
        if (n > peak) peak = n
    }

    /** Jumlah ketukan dalam 1 detik terakhir. */
    fun cps(): Int {
        val limit = SystemClock.uptimeMillis() - 1000L
        while (stamps.isNotEmpty() && stamps.first() < limit) stamps.removeFirst()
        return stamps.size
    }
}
