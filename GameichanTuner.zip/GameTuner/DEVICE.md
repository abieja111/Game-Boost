# HP uji pemilik

Dicatat dari pemilik proyek, supaya pilihan fitur dan angka bawaan disesuaikan dengan HP ini.

| | |
|---|---|
| HP | TECNO SPARK GO 1 (model TECNO KL4) |
| Sistem | HiOS V14.0.1, Android 14 (API 34) |
| Chip | Unisoc T615 |
| RAM / ROM | 4 GB + 1 GB (RAM virtual) / 64 GB |
| Baterai | 5000 mAh |
| Layar | 720 x 1600 |
| Kamera | depan 8 MP, belakang 13 MP |

## Catatan untuk aplikasi

- **Android 14:** Game Mode per game (`cmd game set --downscale / --fps`) tersedia, jadi **Resolusi per Game** dan
  **FPS per Game** bisa dipakai. Di jalur ini DPI dan ukuran layar tidak diubah.
- **Pop-up lebar:** layar landscape 1600 x 720 (diukur dari screenshot), kepadatan sekitar 1,47 (sekitar 235 dpi).
- **RAM 4 GB:** Boost RAM berguna, tetapi hasilnya kecil karena Android memulai ulang sebagian aplikasi.
- **Chip kelas menengah-bawah:** Mode Performa Gamma (FPS maksimal + resolusi 70%) cepat membuat HP panas;
  Peringatan Panas dan Auto FPS sebaiknya tetap nyala.
- Belum dicek di HP ini: refresh rate layar, apakah data GPU terbaca (`LoadMeter`), apakah HiOS menerima
  `cmd game` dan `cmd power set-fixed-performance-mode-enabled`, dan apakah CPS di HUD menerima kejadian sentuhan.
