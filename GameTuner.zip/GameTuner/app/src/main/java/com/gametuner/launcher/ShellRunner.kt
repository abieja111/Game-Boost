package com.gametuner.launcher

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

data class CmdResult(val ok: Boolean, val out: String, val err: String)

/**
 * Menjalankan perintah shell dengan hak akses "shell" (Shizuku) atau root.
 * `wm size` dan `wm density` hanya bisa dijalankan oleh shell/root, bukan aplikasi biasa.
 *
 * Semua fungsi exec/detect bersifat blocking: panggil dari thread background.
 */
object ShellRunner {

    enum class Mode { SHIZUKU, ROOT, NONE }

    const val SHIZUKU_REQUEST_CODE = 4242

    @Volatile
    private var rootState: Boolean? = null

    fun shizukuRunning(): Boolean =
        try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun shizukuGranted(): Boolean =
        try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }
        catch (_: Throwable) { false }

    fun requestShizuku() {
        try { Shizuku.requestPermission(SHIZUKU_REQUEST_CODE) } catch (_: Throwable) { }
    }

    /** Cek akses yang tersedia. Root hanya dicek sekali kecuali [forceRoot]. */
    fun detect(forceRoot: Boolean = false): Mode {
        if (shizukuRunning() && shizukuGranted()) return Mode.SHIZUKU
        if (forceRoot || rootState == null) rootState = checkRoot()
        return if (rootState == true) Mode.ROOT else Mode.NONE
    }

    fun exec(cmd: String): CmdResult = when (detect()) {
        Mode.SHIZUKU -> runProcess { shizukuProcess(cmd) }
        Mode.ROOT -> runProcess { ProcessBuilder("su", "-c", cmd).start() }
        Mode.NONE -> CmdResult(
            ok = false,
            out = "",
            err = "Tidak ada akses sistem. Jalankan Shizuku atau gunakan root."
        )
    }

    private fun checkRoot(): Boolean = try {
        val r = runProcess { ProcessBuilder("su", "-c", "id").start() }
        r.ok && r.out.contains("uid=0")
    } catch (_: Throwable) {
        false
    }

    // Shizuku.newProcess bersifat private sejak API 13, jadi dipanggil lewat reflection.
    private val newProcessMethod by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    private fun shizukuProcess(cmd: String): Process =
        newProcessMethod.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process

    private fun runProcess(start: () -> Process): CmdResult = try {
        val p = start()
        val out = p.inputStream.bufferedReader().use { it.readText() }
        val err = p.errorStream.bufferedReader().use { it.readText() }
        val code = p.waitFor()
        CmdResult(code == 0, out.trim(), err.trim())
    } catch (t: Throwable) {
        CmdResult(false, "", t.message ?: t.javaClass.simpleName)
    }
}
