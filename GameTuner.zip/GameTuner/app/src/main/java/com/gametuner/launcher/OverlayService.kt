package com.gametuner.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Bubble melayang di atas game. Ketuk untuk membuka panel: ganti skala resolusi,
 * batas refresh rate, Boost RAM, dan lihat suhu/baterai/RAM.
 * Dibuat dengan View biasa (bukan Compose) supaya tidak butuh lifecycle owner di Service.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_RESET = "com.gametuner.launcher.RESET"
        const val ACTION_FINISH = "com.gametuner.launcher.FINISH"
        private const val CHANNEL_ID = "overlay"
        private const val NOTIF_ID = 1
        private const val CHIPS_PER_ROW = 5

        // Pemantau game: cek tiap POLL_MS; reset bila game ditinggalkan terus-menerus selama GRACE_MS.
        private const val POLL_MS = 4000L
        private const val GRACE_MS = 12_000L
        private const val ARM_TIMEOUT_MS = 60_000L

        // Peringatan panas: cek suhu tiap HEAT_POLL_MS, hanya peringatkan lagi setelah suhu turun 2°C.
        private const val HEAT_POLL_MS = 10_000L
        private const val COLOR_ALERT = 0xFFFF6B5A.toInt()

        private const val COLOR_PANEL = 0xF01B2030.toInt()
        private const val COLOR_CHIP = 0xFF2B3150.toInt()
        private const val COLOR_ACCENT = 0xFF7C9CFF.toInt()
        private const val COLOR_ACCENT_TEXT = 0xFF0B1230.toInt()
        private const val COLOR_MUTED = 0xFFA7ADC0.toInt()
    }

    private lateinit var wm: WindowManager
    private lateinit var store: GameStore
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var panel: LinearLayout? = null
    private var statusView: TextView? = null
    private var statsView: TextView? = null
    private val scaleChips = mutableMapOf<Int, TextView>()
    private val fpsChips = mutableMapOf<Int, TextView>()
    private var bubbleView: TextView? = null
    private var heatWarned = false

    private val heatTick = object : Runnable {
        override fun run() {
            if (finishing) return
            checkHeat()
            main.postDelayed(this, HEAT_POLL_MS)
        }
    }

    // Pemantau game di depan: layar dikembalikan otomatis setelah game ditinggalkan.
    @Volatile private var alive = true
    private var finishing = false
    private var armed = false      // true setelah game pernah terlihat di depan
    private var awaySince = 0L     // 0 = game sedang di depan / belum dianggap ditinggalkan
    private var startedAt = 0L

    private val watchTick = object : Runnable {
        override fun run() {
            if (finishing) return
            val game = store.currentGame
            if (!store.autoReset || game == null) {
                main.postDelayed(this, POLL_MS)
                return
            }
            io.execute {
                val fg = ForegroundWatcher.foregroundPackage()
                main.post {
                    if (alive && !finishing) {
                        onForeground(fg, game)
                        if (!finishing) main.postDelayed(this, POLL_MS)
                    }
                }
            }
        }
    }

    /** Memperbarui suhu/baterai/RAM tiap 3 detik selama panel terbuka. */
    private val statsTick = object : Runnable {
        override fun run() {
            statsView?.text = describeStats()
            if (panel?.visibility == View.VISIBLE) main.postDelayed(this, 3000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = GameStore(this)

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Bubble Game Tuner", NotificationManager.IMPORTANCE_LOW)
        )
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin pop-up overlay belum aktif", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        buildOverlay()
        refreshStatus()
        startWatching()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RESET -> resetAll()
            ACTION_FINISH -> finishAndReset()
            // dimulai lagi dari launcher (mungkin untuk game lain): mulai pantauan dari awal
            else -> resetWatchState()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        alive = false
        main.removeCallbacksAndMessages(null)
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        io.shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------ actions

    private fun applyScale(percent: Int) {
        statusView?.text = "Mengatur…"
        io.execute {
            val info = DisplayController.read()
            val res = if (info == null) {
                CmdResult(false, "", "Tidak ada akses sistem (Shizuku/root).")
            } else {
                DisplayController.setScale(percent, store.scaleDensity, info)
            }
            if (res.ok) store.currentGame?.let { store.setScale(it, percent) }
            else toastFromBackground("Gagal: ${res.err.ifBlank { res.out }}")
            refreshStatus()
        }
    }

    private fun applyFps(hz: Int) {
        io.execute {
            val res = if (hz > 0) {
                DisplayController.setRefreshRate(hz, store)
            } else {
                DisplayController.resetRefreshRate(store)
            }
            if (res.ok) store.currentGame?.let { store.setFps(it, hz) }
            else toastFromBackground("Gagal: ${res.err.ifBlank { res.out }}")
            refreshStatus()
        }
    }

    private fun boost() {
        toastFromBackground("Boost berjalan…")
        io.execute {
            val out = Boost.run(this)
            main.post {
                Toast.makeText(this, Boost.message(out), Toast.LENGTH_LONG).show()
                statsView?.text = describeStats()
            }
        }
    }

    private fun resetAll() {
        io.execute {
            DisplayController.resetAll(store)
            refreshStatus()
        }
    }

    private fun finishAndReset() {
        finishing = true
        io.execute {
            DisplayController.resetAll(store)
            PlayMode.restore(store)
            main.post { stopSelf() }
        }
    }

    private fun startWatching() {
        resetWatchState()
        main.postDelayed(watchTick, POLL_MS)
        main.postDelayed(heatTick, HEAT_POLL_MS)
    }

    /** Bandingkan suhu baterai dengan batas pengguna; ubah bubble dan beri pesan bila terlalu panas. */
    private fun checkHeat() {
        val limit = store.heatWarnC
        if (limit <= 0) {
            if (heatWarned) {
                heatWarned = false
                setBubbleAlert(false)
            }
            return
        }
        val temp = SystemStats.read(this).tempC
        if (!heatWarned && temp >= limit) {
            heatWarned = true
            setBubbleAlert(true)
            Toast.makeText(
                this,
                String.format("⚠ HP panas (%.1f°C). Turunkan resolusi/FPS atau istirahat sebentar.", temp),
                Toast.LENGTH_LONG
            ).show()
        } else if (heatWarned && temp < limit - 2) {
            heatWarned = false
            setBubbleAlert(false)
        }
    }

    private fun setBubbleAlert(alert: Boolean) {
        bubbleView?.text = if (alert) "🔥" else "⚡"
        bubbleView?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0xE61B2030.toInt())
            setStroke(dp(2), if (alert) COLOR_ALERT else COLOR_ACCENT)
        }
    }

    private fun resetWatchState() {
        armed = false
        awaySince = 0L
        startedAt = SystemClock.elapsedRealtime()
    }

    /**
     * Dipanggil di main thread dengan paket yang sedang di depan ([fg], null = tidak diketahui).
     * Fail-safe: layar hanya dikembalikan bila SECARA PASTI terlihat aplikasi lain di depan
     * terus-menerus selama [GRACE_MS]. Bila tidak yakin (null), tidak ada yang dilakukan.
     */
    private fun onForeground(fg: String?, game: String) {
        if (finishing || fg == null) return
        val now = SystemClock.elapsedRealtime()
        when {
            fg == game -> {
                armed = true
                awaySince = 0L
            }
            // Game Tuner sendiri di depan: pengguna mungkin sedang mengubah profil, jangan reset.
            fg == packageName -> awaySince = 0L
            // Aplikasi lain di depan. Baru dihitung setelah game pernah terlihat, atau setelah
            // ARM_TIMEOUT_MS bila game ternyata tidak pernah terbuka.
            armed || now - startedAt > ARM_TIMEOUT_MS -> {
                if (awaySince == 0L) {
                    awaySince = now
                } else if (now - awaySince >= GRACE_MS) {
                    toastFromBackground("Game ditutup, layar dikembalikan")
                    finishAndReset()
                }
            }
        }
    }

    private fun toastFromBackground(msg: String) {
        main.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    private fun describeStats(): String {
        val s = SystemStats.read(this)
        val secs = (SystemClock.elapsedRealtime() - startedAt) / 1000
        val clock = if (secs >= 3600) {
            String.format("%d:%02d:%02d", secs / 3600, secs % 3600 / 60, secs % 60)
        } else {
            String.format("%d:%02d", secs / 60, secs % 60)
        }
        return String.format(
            "🌡 %.1f°C   🔋 %d%%   RAM %.1f GB\n⏱ Main %s",
            s.tempC, s.batteryPct, s.ramFreeMb / 1024f, clock,
        )
    }

    /** Baca resolusi dan refresh rate saat ini di background, lalu perbarui teks dan chip di main thread. */
    private fun refreshStatus() {
        io.execute {
            val info = DisplayController.read()
            val hz = if (info != null) DisplayController.readRefreshRate() else 0
            main.post {
                val label = when {
                    info == null -> "Akses sistem tidak tersedia"
                    info.isOverridden -> "${info.curW}×${info.curH} (${info.currentPercent}%)"
                    else -> "${info.physW}×${info.physH} (asli)"
                }
                statusView?.text = if (hz > 0) "$label · $hz Hz" else label

                val activeScale = when {
                    info == null -> null
                    !info.isOverridden -> 100
                    else -> DisplayController.PRESETS.minByOrNull { abs(it - info.currentPercent) }
                }
                scaleChips.forEach { (p, v) -> styleChip(v, p == activeScale) }
                fpsChips.forEach { (h, v) -> styleChip(v, h == hz) }

                main.postDelayed({ clamp() }, 600) // layar berubah ukuran, jaga bubble tetap terlihat
            }
        }
    }

    // ------------------------------------------------------------ overlay

    private fun buildOverlay() {
        val bubble = TextView(this).apply {
            text = "⚡"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xE61B2030.toInt())
                setStroke(dp(2), COLOR_ACCENT)
            }
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }

        val panelView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(COLOR_PANEL)
            }
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(dp(270), LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(8) }
        }
        panel = panelView

        panelView.addView(TextView(this).apply {
            text = "Game Tuner"
            setTextColor(Color.WHITE)
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        })

        val status = TextView(this).apply {
            setTextColor(COLOR_MUTED)
            textSize = 12f
            text = "…"
        }
        statusView = status
        panelView.addView(status)

        val stats = TextView(this).apply {
            setTextColor(COLOR_MUTED)
            textSize = 11f
            text = "…"
        }
        statsView = stats
        panelView.addView(stats)

        panelView.addView(sectionLabel("Resolusi"))
        chipRows(DisplayController.PRESETS, scaleChips, { if (it == 100) "Asli" else "$it%" }) {
            applyScale(it)
        }.forEach { panelView.addView(it) }

        val rates = listOf(0) + DisplayController.supportedRates(this)
        if (rates.size > 1) {
            panelView.addView(sectionLabel("Refresh rate (batas FPS)"))
            chipRows(rates, fpsChips, { if (it == 0) "Auto" else "$it" }) {
                applyFps(it)
            }.forEach { panelView.addView(it) }
        }

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        }
        actionRow.addView(makeButton("Boost") { boost() }, weightParams())
        actionRow.addView(makeButton("Reset") { resetAll() }, weightParams())
        actionRow.addView(makeButton("Selesai") { finishAndReset() }, weightParams())
        panelView.addView(actionRow)

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bubble)
            addView(panelView)
        }
        root = container

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(120)
        }
        params = lp

        bubbleView = bubble
        installDrag(bubble, lp, container)
        wm.addView(container, lp)
    }

    /** Geser bubble dengan jari; ketukan singkat membuka/menutup panel. */
    private fun installDrag(handle: View, lp: WindowManager.LayoutParams, container: View) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        wm.updateViewLayout(container, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    true
                }
                else -> false
            }
        }
    }

    private fun togglePanel() {
        val p = panel ?: return
        val opening = p.visibility != View.VISIBLE
        p.visibility = if (opening) View.VISIBLE else View.GONE
        if (opening) {
            refreshStatus()
            main.removeCallbacks(statsTick)
            main.post(statsTick)
        }
        root?.post { clamp() }
    }

    /** Pastikan seluruh overlay (termasuk panel) berada di dalam layar. */
    @Suppress("DEPRECATION")
    private fun clamp() {
        val r = root ?: return
        val lp = params ?: return
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        val maxX = (dm.widthPixels - r.width).coerceAtLeast(0)
        val maxY = (dm.heightPixels - r.height).coerceAtLeast(0)
        lp.x = lp.x.coerceIn(0, maxX)
        lp.y = lp.y.coerceIn(0, maxY)
        runCatching { wm.updateViewLayout(r, lp) }
    }

    // ------------------------------------------------------------ helpers

    /** Baris-baris chip (maks. [CHIPS_PER_ROW] per baris), disimpan di [into] supaya bisa di-highlight. */
    private fun chipRows(
        values: List<Int>,
        into: MutableMap<Int, TextView>,
        label: (Int) -> String,
        onClick: (Int) -> Unit,
    ): List<LinearLayout> = values.chunked(CHIPS_PER_ROW).map { group ->
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4) }
            group.forEach { v ->
                val chip = makeButton(label(v)) { onClick(v) }
                into[v] = chip
                addView(chip, weightParams())
            }
            // isi slot kosong agar lebar chip di baris terakhir tetap sama
            repeat(CHIPS_PER_ROW - group.size) { addView(View(this@OverlayService), weightParams()) }
        }
    }

    private fun sectionLabel(title: String) = TextView(this).apply {
        text = title
        textSize = 11f
        setTextColor(COLOR_MUTED)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(10) }
    }

    private fun makeButton(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(8), dp(4), dp(8))
            styleChip(this, false)
            setOnClickListener { onClick() }
        }

    private fun styleChip(v: TextView, active: Boolean) {
        v.setTextColor(if (active) COLOR_ACCENT_TEXT else Color.WHITE)
        v.background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(if (active) COLOR_ACCENT else COLOR_CHIP)
        }
    }

    private fun weightParams() =
        LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(2)
            marginEnd = dp(2)
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildNotification(): Notification {
        fun pending(action: String, code: Int) = PendingIntent.getService(
            this, code,
            Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_bolt)
            .setContentTitle("Game Tuner aktif")
            .setContentText("Ketuk bubble ⚡ untuk atur resolusi dan FPS")
            .setContentIntent(open)
            .addAction(0, "Reset layar", pending(ACTION_RESET, 1))
            .addAction(0, "Selesai", pending(ACTION_FINISH, 2))
            .setOngoing(true)
            .build()
    }
}
