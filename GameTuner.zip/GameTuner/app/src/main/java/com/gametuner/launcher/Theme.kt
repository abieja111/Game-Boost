package com.gametuner.launcher

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFF7C9CFF),
    onPrimary = Color(0xFF0B1230),
    background = Color(0xFF0F1117),
    onBackground = Color(0xFFE6E8EF),
    surface = Color(0xFF1B2030),
    onSurface = Color(0xFFE6E8EF),
    surfaceVariant = Color(0xFF242A3D),
    onSurfaceVariant = Color(0xFFA7ADC0),
    secondaryContainer = Color(0xFF2B3A6B),
    onSecondaryContainer = Color(0xFFDCE4FF),
    error = Color(0xFFFF8A80),
)

@Composable
fun GameTunerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
