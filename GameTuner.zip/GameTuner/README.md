# Game Tuner

Launcher game untuk Android: **downscale resolusi**, **batas FPS**, **boost RAM**, **monitor perangkat**, dan **mode main**, semuanya bisa diatur langsung dari bubble pop-up saat game berjalan.

## Fitur

**Launcher**
- Daftar game yang terpasang (otomatis dikenali; ada saklar "Tampilkan semua" untuk aplikasi lain)
- Profil per game: skala resolusi (Asli, 85%, 75%, 60%, 50%) dan batas refresh rate
- Tombol **Luncurkan**: pengaturan diterapkan dulu, baru game dibuka
- Kartu monitor: suhu baterai, level baterai, RAM bebas, plus tombol **Boost**
- Kartu **Mode main** (opsional, default mati):
  - **Mode fokus:** nyalakan Jangan Ganggu selama main
  - **Matikan Penghemat Baterai:** supaya performa tidak dibatasi
  - **Peringatan panas:** pilih batas suhu (Mati, 40, 42, 45 °C)

**Bubble pop-up (⚡)** di atas game. Ketuk untuk membuka panel, geser untuk memindahkan.
- Ganti skala resolusi dan batas refresh rate kapan saja
- **Boost**: bersihkan RAM dari proses latar
- Suhu, baterai, RAM bebas, dan **lama main**, diperbarui tiap 3 detik selama panel terbuka
- **Peringatan panas:** bubble berubah jadi 🔥 dan muncul pesan saat suhu baterai melewati batas
- **Reset** mengembalikan resolusi dan refresh rate; **Selesai** mengembalikan semuanya (termasuk Mode main) dan menutup bubble
- Pilihan terakhir di bubble tersimpan sebagai profil game tersebut
- **Reset otomatis:** setelah kamu keluar dari game sekitar 12 detik, semuanya dikembalikan dan bubble ditutup (bisa dimatikan lewat saklar di kartu status)

## Cara kerja dan batasannya

Pengaturan sistem diubah lewat perintah shell (`wm size`, `wm density`, `settings put ...`, `cmd notification`, `am kill-all`). Perintah ini hanya bisa dijalankan akses **shell** atau **root**, bukan aplikasi biasa. Jadi aplikasi ini memakai **Shizuku** (tanpa root, disarankan) atau **root**.

- **Resolusi:** `wm size` menurunkan resolusi **seluruh layar**, bukan hanya game. Tekan **Selesai** atau **Reset** setelah main.
- **Atur FPS:** yang dibatasi adalah **refresh rate layar** (misalnya 60 atau 90 Hz). Game yang mengikuti layar ikut terbatas. Game yang punya pilihan FPS sendiri di dalam game tetap perlu diatur di sana. Beberapa merek HP memakai pengaturan refresh rate sendiri, jadi di sebagian HP pengaturan ini mungkin tidak berpengaruh.
- **Refresh rate asli dipulihkan:** nilai pengaturan sebelum diubah disimpan, lalu dikembalikan persis saat Reset atau Selesai.
- **Mode main hanya memulihkan yang dia ubah:** kalau Jangan Ganggu sudah menyala, atau Penghemat Baterai sudah mati sebelum main, keduanya tidak disentuh sama sekali. Mode fokus memakai mode "prioritas", jadi telepon dari kontak prioritas dan alarm tetap bunyi sesuai pengaturan HP-mu.
- **Boost:** menjalankan `am kill-all`, yang mematikan proses latar yang aman dimatikan. Android sering memulai ulang sebagian aplikasi itu, jadi efeknya bisa sementara dan kadang kecil. Aplikasi menampilkan selisih RAM bebas sesudahnya.
- **Peringatan panas:** memakai suhu baterai, bukan suhu chip. Angkanya hanya perkiraan kasar kondisi HP. Peringatan muncul sekali, lalu baru muncul lagi setelah suhu turun 2 °C.
- **Reset otomatis:** aplikasi memeriksa aplikasi yang sedang di depan tiap 4 detik (lewat `dumpsys`). Kalau kamu keluar dari game lebih dari ±12 detik, semuanya dikembalikan dan bubble ditutup. Membuka Game Tuner sendiri tidak dihitung keluar dari game. Membuka aplikasi lain lebih dari 12 detik (misalnya login lewat browser) juga dianggap keluar. Kalau aplikasi tidak bisa memastikan mana yang di depan (format `dumpsys` berbeda antar HP), tidak ada yang direset otomatis, jadi tetap tekan **Selesai** untuk jaga-jaga. Pemeriksaan berkala ini memakai sedikit baterai; matikan lewat saklar di kartu status bila tidak perlu.
- Layar akan berkedip sebentar saat resolusi berubah. Ini normal.
- Sebagian game membaca resolusi hanya saat dibuka, jadi perubahan dari bubble mungkin baru terasa setelah game dibuka ulang.

## Cara mendapatkan APK

Build dilakukan di server GitHub (gratis), hasilnya APK yang muncul di bagian **Releases** repo kamu. Tinggal tap file `GameTuner-debug.apk` untuk mengunduh.

**Opsi A: dari PC atau laptop**
1. Ekstrak zip ini.
2. Buat repo baru di GitHub (pilih Private), lalu unggah **isi** folder `GameTuner` lewat link "uploading an existing file". Pastikan folder `.github` ikut.
3. Build jalan otomatis. Setelah hijau, buka **Releases** di halaman utama repo dan unduh APK-nya.

**Opsi B: dari HP saja**
Upload web di HP tidak bisa memilih folder, jadi zip diunggah apa adanya dan GitHub yang mengekstraknya.
1. Buat repo baru (Private), centang **Add a README file**.
2. **Add file → Upload files**, pilih zip ini, lalu **Commit changes**.
3. **Add file → Create new file**, ketik nama `.github/workflows/build.yml`, lalu tempel isi file `build-dari-zip.yml` (ada di dalam zip ini) dan **Commit changes**.
4. Tunggu sekitar 5–10 menit sampai build hijau, lalu unduh APK dari **Releases**.

## Memperbarui ke versi baru

1. Unggah zip yang baru ke repo yang sama (**Add file → Upload files**). Workflow otomatis memakai zip yang paling baru, jadi zip lama tidak perlu dihapus.
2. Tunggu build hijau, lalu unduh APK dari **Releases** (pilih build dengan nomor paling besar).
3. Pasang APK-nya. Aplikasi ini memakai kunci tanda tangan tetap (`app/debug.keystore`), jadi APK baru langsung menimpa versi lama. Tidak perlu menghapus aplikasi, dan profil game serta pengaturanmu tetap ada.

**Perhatian, sekali saja:** APK dari zip lama (sebelum ada `app/debug.keystore`) ditandatangani kunci acak yang berbeda di setiap build. Kalau di HP-mu sudah terpasang APK seperti itu, **uninstall dulu** Game Tuner yang lama sebelum memasang yang ini. Kalau tidak, Android menolak dengan pesan "App not installed". Setelah itu izin Shizuku dan pengaturan perlu diatur ulang. Untuk versi-versi berikutnya hal ini tidak perlu diulang.

`app/debug.keystore` adalah kunci debug yang tidak rahasia dan hanya cukup untuk memasang update di HP sendiri. Jangan dipakai untuk merilis ke Play Store.

## Cara pakai pertama kali

1. Pasang **Shizuku** dari Play Store / GitHub, lalu jalankan lewat *Wireless debugging* (ikuti petunjuk di aplikasi Shizuku). Perlu diulang setelah HP restart.
2. Buka Game Tuner. Di kartu status, tekan **Izinkan** pada "Akses sistem" dan setujui permintaan Shizuku.
3. Tekan **Izinkan** pada "Pop-up overlay" dan aktifkan izin tampil di atas aplikasi lain.
4. Pilih game, pilih skala resolusi dan batas refresh rate, tekan **Luncurkan**.

## Kalau layar atau pengaturan tersangkut

Dari Game Tuner tekan **Reset**; ini mengembalikan layar dan Mode main. Kalau aplikasi tidak bisa dibuka, jalankan dari PC lewat ADB:

```
adb shell wm size reset
adb shell wm density reset
adb shell settings delete system min_refresh_rate
adb shell settings delete system peak_refresh_rate
adb shell cmd notification set_dnd off
adb shell settings put global low_power 1
```

Dua perintah terakhir hanya perlu kalau tadi Mode fokus atau Penghemat Baterai ikut diubah. Perintah refresh rate menghapus pengaturan refresh rate; kalau sebelumnya kamu pernah mengaturnya sendiri di Pengaturan HP, atur ulang di sana. `low_power 1` menyalakan Penghemat Baterai, jadi lewati baris itu kalau sebelumnya memang tidak kamu pakai.

## Status

Versi sebelumnya sudah berhasil dibuild di GitHub Actions. Fitur Mode main, peringatan panas, dan timer belum dikompilasi, dan belum ada fitur yang diuji berjalan di HP. Kalau build menampilkan error, kirim pesan errornya agar bisa diperbaiki.

## Ide berikutnya

- Batas FPS per game yang lebih akurat lewat Game Mode bawaan Android (Android 12 ke atas)
- Kunci kecerahan dan rotasi layar selama main
