package com.gametuner.launcher

import android.content.Context

/** Penyimpanan sederhana: profil per game + pengaturan global. */
class GameStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("gametuner", Context.MODE_PRIVATE)

    fun getScale(pkg: String): Int = prefs.getInt("scale_$pkg", 100)

    fun setScale(pkg: String, percent: Int) {
        prefs.edit().putInt("scale_$pkg", percent).apply()
    }

    /** Batas refresh rate (Hz) per game. 0 = otomatis / tidak dibatasi. */
    fun getFps(pkg: String): Int = prefs.getInt("fps_$pkg", 0)

    fun setFps(pkg: String, hz: Int) {
        prefs.edit().putInt("fps_$pkg", hz).apply()
    }

    /** Ikut skala density supaya ukuran UI/teks tetap normal saat resolusi diturunkan. */
    var scaleDensity: Boolean
        get() = prefs.getBoolean("scale_density", true)
        set(value) { prefs.edit().putBoolean("scale_density", value).apply() }

    /** Game yang terakhir diluncurkan; perubahan dari overlay disimpan ke game ini. */
    var currentGame: String?
        get() = prefs.getString("current_game", null)
        set(value) { prefs.edit().putString("current_game", value).apply() }

    /** Kembalikan layar otomatis setelah game ditinggalkan beberapa detik. Default: aktif. */
    var autoReset: Boolean
        get() = prefs.getBoolean("auto_reset", true)
        set(value) { prefs.edit().putBoolean("auto_reset", value).apply() }

    /** Bisukan notifikasi (Jangan Ganggu) selama main. Default: mati. */
    var focusMode: Boolean
        get() = prefs.getBoolean("focus_mode", false)
        set(value) { prefs.edit().putBoolean("focus_mode", value).apply() }

    /** Matikan Penghemat Baterai selama main bila sedang menyala. Default: mati. */
    var batterySaverOff: Boolean
        get() = prefs.getBoolean("bs_off", false)
        set(value) { prefs.edit().putBoolean("bs_off", value).apply() }

    /** True bila KITA yang menyalakan Jangan Ganggu, jadi KITA yang harus mematikannya lagi. */
    var focusApplied: Boolean
        get() = prefs.getBoolean("focus_applied", false)
        set(value) { prefs.edit().putBoolean("focus_applied", value).apply() }

    /** True bila KITA yang mematikan Penghemat Baterai, jadi KITA yang harus menyalakannya lagi. */
    var batterySaverApplied: Boolean
        get() = prefs.getBoolean("bs_applied", false)
        set(value) { prefs.edit().putBoolean("bs_applied", value).apply() }

    /** Batas suhu baterai (°C) untuk peringatan panas di bubble. 0 = mati. */
    var heatWarnC: Int
        get() = prefs.getInt("heat_warn", 44)
        set(value) { prefs.edit().putInt("heat_warn", value).apply() }

    /** Bersihkan RAM otomatis saat RAM bebas menipis selama main. Default: mati. */
    var autoBoost: Boolean
        get() = prefs.getBoolean("auto_boost", false)
        set(value) { prefs.edit().putBoolean("auto_boost", value).apply() }

    /** Mode Main: terapkan profil resolusi/FPS saat game diluncurkan dari aplikasi. Default: aktif. */
    var playOptimize: Boolean
        get() = prefs.getBoolean("play_optimize", true)
        set(value) { prefs.edit().putBoolean("play_optimize", value).apply() }

    /** Auto FPS: turunkan batas refresh rate ke 60 Hz saat HP panas, naikkan lagi saat dingin. Default: mati. */
    var autoFps: Boolean
        get() = prefs.getBoolean("auto_fps", false)
        set(value) { prefs.edit().putBoolean("auto_fps", value).apply() }

    /** Batas suhu terakhir yang dipilih (>0); dipakai saat Peringatan Panas dinyalakan lagi. */
    var lastHeatWarnC: Int
        get() = prefs.getInt("heat_warn_last", 44)
        set(value) { prefs.edit().putInt("heat_warn_last", value).apply() }

    /**
     * Nilai asli pengaturan refresh rate sistem sebelum kita ubah, format "min|peak".
     * Dipakai untuk memulihkan pengaturan pengguna saat reset. Null = belum kita ubah.
     */
    var savedRefresh: String?
        get() = prefs.getString("saved_refresh", null)
        set(value) { prefs.edit().putString("saved_refresh", value).apply() }
}
