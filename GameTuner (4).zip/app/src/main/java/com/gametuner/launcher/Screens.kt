package com.gametuner.launcher

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

/** Kerangka aplikasi: header, isi halaman terpilih, dan bilah bawah. */
@Composable
fun NexusApp(ui: UiState, act: AppActions, rates: List<Int>) {
    BackHandler(enabled = ui.tab != Tab.HOME) { ui.tab = Tab.HOME }

    Column(
        Modifier
            .fillMaxSize()
            .background(Nx.Bg)
    ) {
        Box(
            Modifier
                .background(Brush.verticalGradient(listOf(Color(0xFF1B0D4A), Nx.Bg)))
                .statusBarsPadding()
        ) {
            NxHeader { ui.tab = Tab.SETTINGS }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (ui.tab) {
                Tab.HOME -> ScrollPage { HomeScreen(ui, act) }
                Tab.GAMES -> GamesScreen(ui, act, rates)
                Tab.STATS -> ScrollPage { StatsScreen(ui, act) }
                Tab.SETTINGS -> ScrollPage { SettingsScreen(ui, act) }
                Tab.ABOUT -> ScrollPage { AboutScreen() }
            }
        }

        Box(Modifier.navigationBarsPadding()) {
            NxBottomBar(ui.tab) { ui.tab = it }
        }
    }
}

@Composable
private fun ScrollPage(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content,
    )
}

// --------------------------------------------------------------- helpers

private fun describeDisplay(i: DisplayInfo, hz: Int): String {
    val size = if (i.isOverridden) {
        "${i.physW}×${i.physH} → ${i.curW}×${i.curH} (${i.currentPercent}%)"
    } else {
        "${i.physW}×${i.physH} (asli)"
    }
    return if (hz > 0) "$size · $hz Hz" else size
}

private fun accessSubtitle(st: SysStatus): String = when {
    st.mode == ShellRunner.Mode.SHIZUKU -> "Shizuku aktif. Fitur maksimal tersedia."
    st.mode == ShellRunner.Mode.ROOT -> "Root aktif. Fitur maksimal tersedia."
    st.shizuku == ShizukuState.NOT_INSTALLED -> "Shizuku belum dipasang. Ketuk untuk membuka halaman unduh."
    st.shizuku == ShizukuState.NOT_RUNNING -> "Shizuku belum dijalankan. Ketuk untuk membukanya."
    st.shizuku == ShizukuState.NEED_PERMISSION -> "Shizuku jalan. Ketuk untuk memberi izin."
    st.shizuku == ShizukuState.DENIED -> "Izin ditolak. Aktifkan di Shizuku, Aplikasi terotorisasi."
    else -> "Diperlukan untuk fitur maksimal"
}

// ---------------------------------------------------------------- Beranda

private enum class HomeDialog { LAYAR, DENSITY, MODE_MAIN }

@Composable
fun HomeScreen(ui: UiState, act: AppActions) {
    val live = rememberLive()
    val st = ui.status
    var dialog by remember { mutableStateOf<HomeDialog?>(null) }

    StatusCard(ui, live)

    SectionCard("Akses & Izin", R.drawable.ic_shield) {
        SettingRow(
            icon = R.drawable.ic_crown,
            title = "Akses Sistem Root / Shizuku",
            subtitle = accessSubtitle(st),
            onClick = { if (st.hasAccess) act.recheck() else act.fixAccess() },
        ) {
            NxSwitch(st.hasAccess) { if (st.hasAccess) act.recheck() else act.fixAccess() }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_overlay,
            title = "Izin Pop Up Overlay",
            subtitle = "Izinkan overlay di atas aplikasi lain",
            onClick = { act.openOverlaySettings() },
        ) {
            NxSwitch(ui.overlayGranted) { act.openOverlaySettings() }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_monitor,
            title = if (st.hasAccess) "Layar" else "Layar Butuh Akses Sistem",
            subtitle = st.info?.let { describeDisplay(it, st.pinnedHz) }
                ?: "Untuk menyesuaikan tampilan game",
            onClick = { dialog = HomeDialog.LAYAR },
        ) {
            PillButton("Atur") { dialog = HomeDialog.LAYAR }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_grid,
            title = "Sesuaikan Density",
            subtitle = if (ui.scaleDensity) "Aktif: ukuran UI tetap normal saat resolusi turun"
            else "Mati: UI mengecil mengikuti resolusi",
            onClick = { dialog = HomeDialog.DENSITY },
        ) {
            PillButton("Atur") { dialog = HomeDialog.DENSITY }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_refresh,
            title = "Reset Otomatis Saat Game Ditutup",
            subtitle = "Mengembalikan pengaturan setelah game selesai",
            onClick = { ui.updateAutoReset(!ui.autoReset) },
        ) {
            NxSwitch(ui.autoReset) { ui.updateAutoReset(it) }
        }
    }

    SectionCard("Mode Game", R.drawable.ic_gamepad) {
        SettingRow(
            icon = R.drawable.ic_speed,
            title = "Mode Main",
            subtitle = "Terapkan resolusi & FPS pilihanmu saat game dibuka",
            onClick = { ui.updatePlayOptimize(!ui.playOptimize) },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clickable { dialog = HomeDialog.MODE_MAIN }.padding(4.dp)) {
                    NxIcon(R.drawable.ic_info, tint = Nx.PurpleLight, size = 20.dp)
                }
                Spacer(Modifier.width(8.dp))
                RadioDot(ui.playOptimize) { ui.updatePlayOptimize(!ui.playOptimize) }
            }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_focus,
            title = "Mode Fokus (Jangan Ganggu)",
            subtitle = "Blokir notifikasi dan gangguan saat bermain",
            onClick = { ui.updateFocusMode(!ui.focusMode) },
        ) {
            RadioDot(ui.focusMode) { ui.updateFocusMode(!ui.focusMode) }
        }
    }

    SectionCard("Penghemat & Peringatan", R.drawable.ic_battery) {
        SettingRow(
            icon = R.drawable.ic_leaf,
            iconTint = Nx.Green,
            title = "Matikan Mode Hemat Baterai",
            subtitle = "Agar performa tidak terbatas",
            onClick = { ui.updateBatterySaverOff(!ui.batterySaverOff) },
        ) {
            NxSwitch(ui.batterySaverOff) { ui.updateBatterySaverOff(it) }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_warning,
            title = "Peringatan Panas",
            subtitle = "Notifikasi jika suhu HP mencapai batas tertentu",
        ) {
            HeatDropdown(ui.heatWarnC, listOf(0, 40, 42, 44, 46, 48)) { ui.updateHeatWarn(it) }
        }
    }

    SectionCard("Suhu & RAM (Boost)", R.drawable.ic_rocket) {
        SettingRow(
            icon = R.drawable.ic_memory,
            title = "Boost Otomatis",
            subtitle = "Bersihkan RAM saat RAM bebas menipis selama main",
            onClick = { ui.updateAutoBoost(!ui.autoBoost) },
        ) {
            NxSwitch(ui.autoBoost) { ui.updateAutoBoost(it) }
        }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_bolt,
            title = "Boost Sekarang",
            subtitle = "Tutup aplikasi latar untuk melegakan RAM",
        ) {
            PillButton(
                text = if (ui.boosting) "…" else "Boost",
                icon = null,
            ) { if (!ui.boosting) act.boost() }
        }
    }

    when (dialog) {
        HomeDialog.LAYAR -> NxDialog(
            title = "Layar",
            onDismiss = { dialog = null },
            confirmText = if (st.hasAccess) "Reset Layar" else null,
            onConfirm = {
                act.resetDisplay()
                dialog = null
            },
        ) {
            Text(
                st.info?.let { describeDisplay(it, st.pinnedHz) }
                    ?: "Butuh akses sistem (Shizuku atau root).",
                color = Nx.Text,
            )
            Text(
                "Resolusi dan refresh rate diubah otomatis saat game diluncurkan dari tab Game " +
                    "atau lewat bubble. Tombol Reset mengembalikan semuanya ke bawaan layar.",
                fontSize = 13.sp,
            )
        }

        HomeDialog.DENSITY -> NxDialog(
            title = "Sesuaikan Density",
            onDismiss = { dialog = null },
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Skalakan density ikut resolusi",
                    color = Nx.Text,
                    modifier = Modifier.weight(1f),
                )
                NxSwitch(ui.scaleDensity) { ui.updateScaleDensity(it) }
            }
            Text(
                "Aktif: ukuran UI dan teks tetap normal saat resolusi turun, game tampil lebih " +
                    "ringan tanpa membuat tombol mengecil. Mati: hanya resolusi yang turun, " +
                    "UI ikut mengecil.",
                fontSize = 13.sp,
            )
        }

        HomeDialog.MODE_MAIN -> NxDialog(
            title = "Mode Main",
            onDismiss = { dialog = null },
        ) {
            Text(
                "Saat aktif, resolusi dan batas FPS yang kamu pilih untuk sebuah game langsung " +
                    "diterapkan sebelum game dibuka. Saat mati, game dibuka apa adanya " +
                    "(bubble pop-up tetap muncul).",
                fontSize = 13.sp,
            )
        }

        null -> Unit
    }
}

@Composable
private fun StatusCard(ui: UiState, live: Live) {
    val st = ui.status
    val ready = st.hasAccess && ui.overlayGranted
    val hint = when {
        !st.hasAccess -> "Akses sistem belum aktif"
        !ui.overlayGranted -> "Izin overlay belum aktif"
        else -> ""
    }
    Column(
        Modifier
            .fillMaxWidth()
            .nxCard(22.dp)
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .border(2.dp, Nx.Purple, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                NxIcon(R.drawable.ic_gamepad, tint = Nx.PurpleLight, size = 32.dp)
            }
            Spacer(Modifier.width(14.dp))
            Column {
                Text("Status", color = Nx.Text, fontSize = 14.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (ready) "Siap Digunakan" else "Belum Siap",
                        color = if (ready) Nx.PurpleLight else Nx.Amber,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Spacer(Modifier.width(8.dp))
                    NxIcon(
                        if (ready) R.drawable.ic_check_circle else R.drawable.ic_warning,
                        tint = if (ready) Nx.Green else Nx.Amber,
                        size = 20.dp,
                    )
                }
                if (hint.isNotEmpty()) {
                    Text(hint, color = Nx.Amber, fontSize = 12.sp)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Nx.Divider)
        )
        Spacer(Modifier.height(12.dp))

        val s = live.stats
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            StatColumn(
                R.drawable.ic_bolt, "Hz Layar",
                if (live.hz > 0) "${live.hz}" else "—",
                Nx.Text, Nx.PurpleLight, Modifier.weight(1f),
            )
            VDivider()
            StatColumn(
                R.drawable.ic_thermo, "Suhu HP",
                "%.0f°C".format(java.util.Locale.US, s.tempC),
                tempColor(s.tempC), Nx.Red, Modifier.weight(1f),
            )
            VDivider()
            StatColumn(
                R.drawable.ic_battery, "Baterai",
                "${s.batteryPct}%",
                batteryColor(s.batteryPct), Nx.Green, Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun StatColumn(
    icon: Int,
    label: String,
    value: String,
    valueColor: Color,
    iconTint: Color,
    modifier: Modifier,
) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NxIcon(icon, tint = iconTint, size = 16.dp)
            Spacer(Modifier.width(4.dp))
            Text(label, color = Nx.Text, fontSize = 12.sp)
        }
        Spacer(Modifier.height(2.dp))
        Text(value, color = valueColor, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun VDivider() {
    Box(
        Modifier
            .width(1.dp)
            .height(44.dp)
            .background(Nx.Divider)
    )
}

// ------------------------------------------------------------------- Game

@Composable
fun GamesScreen(ui: UiState, act: AppActions, rates: List<Int>) {
    var showAll by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<GameApp?>(null) }

    val games = ui.apps.filter { it.isGame }
    val shown = if (showAll || games.isEmpty()) ui.apps else games

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        if (games.isEmpty()) "Semua Aplikasi" else "Game",
                        color = Nx.Text,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                    )
                    Text(
                        "Ketuk game untuk atur resolusi & FPS, lalu luncurkan",
                        color = Nx.Muted,
                        fontSize = 12.sp,
                    )
                }
                if (games.isNotEmpty()) {
                    Text("Semua", color = Nx.Muted, fontSize = 12.sp)
                    Spacer(Modifier.width(8.dp))
                    NxSwitch(showAll) { showAll = it }
                }
            }
        }
        if (ui.apps.isEmpty()) {
            item { Text("Memuat daftar aplikasi…", color = Nx.Muted) }
        }
        items(shown, key = { it.pkg }) { app ->
            GameRow(app, ui.scaleOf(app.pkg), ui.fpsOf(app.pkg)) { selected = app }
        }
    }

    selected?.let { app ->
        ScaleDialog(
            app = app,
            ui = ui,
            rates = rates,
            onDismiss = { selected = null },
            onLaunch = { percent, fps ->
                selected = null
                act.launchGame(app, percent, fps)
            },
        )
    }
}

@Composable
private fun GameRow(app: GameApp, scale: Int, fps: Int, onClick: () -> Unit) {
    val parts = buildList {
        if (scale < 100) add("Resolusi ${DisplayController.scaleLabel(scale)}")
        if (fps > 0) add("$fps Hz")
    }
    Row(
        Modifier
            .fillMaxWidth()
            .nxCard(16.dp, Nx.BorderSoft)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = null,
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(12.dp)),
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                app.label,
                color = Nx.Text,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                if (parts.isEmpty()) "Pengaturan asli" else parts.joinToString(" · "),
                color = if (parts.isEmpty()) Nx.Muted else Nx.PurpleLight,
                fontSize = 12.sp,
            )
        }
        NxIcon(R.drawable.ic_chevron_right, tint = Nx.Muted, size = 20.dp)
    }
}

@Composable
private fun ScaleDialog(
    app: GameApp,
    ui: UiState,
    rates: List<Int>,
    onDismiss: () -> Unit,
    onLaunch: (Int, Int) -> Unit,
) {
    val savedScale = ui.scaleOf(app.pkg)
    val savedFps = ui.fpsOf(app.pkg)
    var scalePick by remember {
        mutableIntStateOf(DisplayController.PRESETS.minByOrNull { abs(it - savedScale) } ?: 100)
    }
    var fpsPick by remember { mutableIntStateOf(if (savedFps in rates) savedFps else 0) }
    val info = ui.status.info

    NxDialog(
        title = app.label,
        onDismiss = onDismiss,
        confirmText = "Luncurkan",
        onConfirm = { onLaunch(scalePick, fpsPick) },
    ) {
        Text("Resolusi render", color = Nx.Text, fontWeight = FontWeight.SemiBold)
        ChipGrid(
            items = DisplayController.PRESETS,
            selected = scalePick,
            columns = 4,
            label = { DisplayController.scaleLabel(it) },
        ) { scalePick = it }

        val t = info?.let { DisplayController.target(it, scalePick, ui.scaleDensity) }
        Text(
            if (t != null) "Hasil: ${t.w}×${t.h} @${t.dpi}dpi" else "Pratinjau butuh akses sistem",
            fontSize = 12.sp,
        )

        if (rates.size > 1) {
            Text(
                "Batas FPS (refresh rate)",
                color = Nx.Text,
                fontWeight = FontWeight.SemiBold,
            )
            ChipGrid(
                items = listOf(0) + rates,
                selected = fpsPick,
                columns = 4,
                label = { if (it == 0) "Auto" else "$it" },
            ) { fpsPick = it }
        }
    }
}

// --------------------------------------------------------------- Statistik

@Composable
fun StatsScreen(ui: UiState, act: AppActions) {
    val live = rememberLive()
    val s = live.stats
    val st = ui.status

    SectionCard("Statistik Perangkat", R.drawable.ic_chart) {
        SettingRow(
            icon = R.drawable.ic_thermo,
            iconTint = tempColor(s.tempC),
            title = "Suhu Baterai",
            subtitle = "Cerminan panas HP saat ini",
        ) { ValueText("%.1f°C".format(java.util.Locale.US, s.tempC), tempColor(s.tempC)) }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_battery,
            iconTint = batteryColor(s.batteryPct),
            title = "Baterai",
            subtitle = if (s.charging) "Sedang mengisi daya" else "Tidak mengisi daya",
        ) { ValueText("${s.batteryPct}%", batteryColor(s.batteryPct)) }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_speed,
            title = "Refresh Rate Layar",
            subtitle = if (st.pinnedHz > 0) "Dikunci di ${st.pinnedHz} Hz" else "Otomatis",
        ) { ValueText(if (live.hz > 0) "${live.hz} Hz" else "—", Nx.Text) }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_monitor,
            title = "Resolusi",
            subtitle = st.info?.let { describeDisplay(it, 0) } ?: "Butuh akses sistem",
        )
    }

    SectionCard("Memori (RAM)", R.drawable.ic_memory) {
        val total = s.ramTotalMb.coerceAtLeast(1L)
        val usedFraction = ((total - s.ramFreeMb).toFloat() / total).coerceIn(0f, 1f)
        Column(Modifier.padding(horizontal = 14.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("RAM bebas", color = Nx.Text, modifier = Modifier.weight(1f))
                Text(
                    "%.1f GB dari %.1f GB".format(java.util.Locale.US, s.ramFreeMb / 1024f, s.ramTotalMb / 1024f),
                    color = Nx.PurpleLight,
                    fontWeight = FontWeight.SemiBold,
                )
            }
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Nx.Chip)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(usedFraction)
                        .fillMaxHeight()
                        .background(Brush.horizontalGradient(listOf(Nx.PurpleDeep, Nx.Purple)))
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "Terpakai ${(usedFraction * 100).toInt()}%",
                color = Nx.Muted,
                fontSize = 12.sp,
            )
        }
        NxDivider()
        Row(Modifier.padding(14.dp)) {
            NxButton(
                text = if (ui.boosting) "Membersihkan…" else "Boost RAM Sekarang",
                modifier = Modifier.fillMaxWidth(),
                enabled = !ui.boosting && st.hasAccess,
            ) { act.boost() }
        }
        if (!st.hasAccess) {
            Text(
                "Boost butuh akses sistem (Shizuku atau root).",
                color = Nx.Amber,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 10.dp),
            )
        }
    }
}

@Composable
private fun ValueText(text: String, color: Color) {
    Text(text, color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold)
}

// -------------------------------------------------------------- Pengaturan

@Composable
private fun CheckRow(ok: Boolean, text: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NxIcon(
            if (ok) R.drawable.ic_check_circle else R.drawable.ic_warning,
            tint = if (ok) Nx.Green else Nx.Amber,
            size = 22.dp,
        )
        Spacer(Modifier.width(12.dp))
        Text(text, color = Nx.Text, fontSize = 14.sp)
    }
}

@Composable
fun SettingsScreen(ui: UiState, act: AppActions) {
    val st = ui.status
    val running = st.shizuku == ShizukuState.NEED_PERMISSION ||
        st.shizuku == ShizukuState.DENIED ||
        st.shizuku == ShizukuState.READY
    val rootOk = st.mode == ShellRunner.Mode.ROOT

    SectionCard("Sambungan Shizuku", R.drawable.ic_shield) {
        CheckRow(st.shizuku != ShizukuState.NOT_INSTALLED, "Aplikasi Shizuku terpasang")
        NxDivider()
        CheckRow(running, "Layanan Shizuku berjalan")
        NxDivider()
        CheckRow(st.shizuku == ShizukuState.READY, "Izin untuk Nexus Game Boost")
        if (rootOk) {
            NxDivider()
            CheckRow(true, "Akses root aktif (dipakai sebagai cadangan)")
        }

        val guide = when (st.shizuku) {
            ShizukuState.NOT_INSTALLED ->
                "1. Pasang aplikasi Shizuku (Play Store atau shizuku.rikka.app).\n" +
                    "2. Buka Shizuku lalu jalankan lewat Debugging Nirkabel.\n" +
                    "3. Kembali ke sini dan ketuk Cek Ulang."
            ShizukuState.NOT_RUNNING ->
                "Shizuku terpasang tapi belum dijalankan. Buka Shizuku lalu ketuk Mulai. " +
                    "Tanpa root: aktifkan Opsi Pengembang, Debugging Nirkabel, pasangkan, lalu " +
                    "Mulai. Ini perlu diulang setiap HP dihidupkan ulang."
            ShizukuState.NEED_PERMISSION ->
                "Shizuku sudah jalan. Ketuk Beri Izin lalu pilih Izinkan pada dialog yang muncul."
            ShizukuState.DENIED ->
                "Izin pernah ditolak. Buka Shizuku, masuk ke Aplikasi terotorisasi, lalu " +
                    "aktifkan Nexus Game Boost. Setelah itu ketuk Cek Ulang."
            ShizukuState.READY ->
                "Semua siap. Resolusi, FPS, dan Boost bisa dipakai."
        }
        Text(
            guide,
            color = Nx.Muted,
            fontSize = 12.sp,
            lineHeight = 17.sp,
            modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 4.dp, bottom = 8.dp),
        )

        Row(
            Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            val primary = when (st.shizuku) {
                ShizukuState.NOT_INSTALLED -> "Unduh Shizuku"
                ShizukuState.NOT_RUNNING -> "Buka Shizuku"
                ShizukuState.NEED_PERMISSION -> "Beri Izin"
                ShizukuState.DENIED -> "Buka Shizuku"
                ShizukuState.READY -> null
            }
            if (primary != null) {
                PillButton(primary, icon = null) { act.fixAccess() }
            }
            PillButton("Cek Ulang", icon = R.drawable.ic_refresh) { act.recheck() }
        }

        if (st.lastError.isNotBlank()) {
            Text(
                "Pesan error terakhir:\n${st.lastError}",
                color = Nx.Amber,
                fontSize = 11.sp,
                maxLines = 6,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 12.dp),
            )
        }
    }

    SectionCard("Preferensi", R.drawable.ic_tune) {
        SettingRow(
            icon = R.drawable.ic_speed,
            title = "Auto FPS",
            subtitle = "Turunkan FPS ke 60 saat HP panas, naik lagi saat dingin",
            onClick = { ui.updateAutoFps(!ui.autoFps) },
        ) { NxSwitch(ui.autoFps) { ui.updateAutoFps(it) } }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_grid,
            title = "Sesuaikan Density",
            subtitle = "Ukuran UI tetap normal saat resolusi turun",
            onClick = { ui.updateScaleDensity(!ui.scaleDensity) },
        ) { NxSwitch(ui.scaleDensity) { ui.updateScaleDensity(it) } }
        NxDivider()
        SettingRow(
            icon = R.drawable.ic_overlay,
            title = "Izin Pop Up Overlay",
            subtitle = if (ui.overlayGranted) "Sudah diizinkan" else "Belum diizinkan",
            onClick = { act.openOverlaySettings() },
        ) { PillButton("Buka") { act.openOverlaySettings() } }
    }

    SectionCard("Layar", R.drawable.ic_monitor) {
        SettingRow(
            icon = R.drawable.ic_refresh,
            title = "Reset Layar Sekarang",
            subtitle = "Kembalikan resolusi, density, dan refresh rate ke bawaan",
        ) {
            PillButton("Reset", icon = null) { act.resetDisplay() }
        }
    }
}

// ----------------------------------------------------------------- Tentang

@Composable
fun AboutScreen() {
    Column(
        Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            painter = painterResource(R.drawable.logo_nx),
            contentDescription = "Logo NX",
            modifier = Modifier
                .size(112.dp)
                .clip(RoundedCornerShape(28.dp)),
        )
        Spacer(Modifier.height(12.dp))
        Text("Nexus Game Boost", color = Nx.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Max Performance, No Lag", color = Nx.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        Text("Versi 1.0", color = Nx.PurpleLight, fontSize = 12.sp, textAlign = TextAlign.Center)
    }

    SectionCard("Fitur", R.drawable.ic_rocket) {
        AboutLine("Turunkan resolusi render game (0.9x sampai 0.3x) supaya lebih ringan.")
        NxDivider()
        AboutLine("Batasi FPS lewat refresh rate layar, dengan Auto FPS saat HP panas.")
        NxDivider()
        AboutLine("Bubble pop-up di atas game untuk mengubah pengaturan langsung.")
        NxDivider()
        AboutLine("Mode Fokus, matikan Penghemat Baterai, Boost RAM, dan peringatan panas.")
        NxDivider()
        AboutLine("Semua perubahan dikembalikan otomatis saat game ditutup.")
    }

    SectionCard("Catatan", R.drawable.ic_info) {
        AboutLine(
            "Mengubah resolusi, density, dan refresh rate memakai perintah sistem lewat " +
                "Shizuku (tanpa root) atau root. Aplikasi ini tidak memodifikasi file game."
        )
        NxDivider()
        AboutLine(
            "Shizuku oleh RikkaApps (Apache-2.0). Ikon antarmuka digambar sendiri; " +
                "logo NX dan desain tampilan dari pemilik aplikasi."
        )
    }
}

@Composable
private fun AboutLine(text: String) {
    Text(
        text,
        color = Nx.Muted,
        fontSize = 13.sp,
        lineHeight = 18.sp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
    )
}
