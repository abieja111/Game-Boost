package com.gametuner.launcher

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap

data class GameApp(
    val pkg: String,
    val label: String,
    val icon: ImageBitmap,
    val isGame: Boolean,
)

/** Keadaan sambungan ke Shizuku, dari yang paling awal gagal sampai siap dipakai. */
enum class ShizukuState {
    /** Aplikasi Shizuku belum dipasang. */
    NOT_INSTALLED,

    /** Terpasang tapi layanannya belum dijalankan (harus dinyalakan lagi tiap HP restart). */
    NOT_RUNNING,

    /** Layanan jalan, tapi aplikasi ini belum diberi izin. */
    NEED_PERMISSION,

    /** Izin sudah ditolak; harus diaktifkan manual lewat daftar aplikasi di Shizuku. */
    DENIED,

    /** Siap dipakai. */
    READY,
}

data class SysStatus(
    val mode: ShellRunner.Mode = ShellRunner.Mode.NONE,
    val shizuku: ShizukuState = ShizukuState.NOT_RUNNING,
    val info: DisplayInfo? = null,
    /** Refresh rate yang sedang dikunci (Hz); 0 = otomatis. */
    val pinnedHz: Int = 0,
    /** True bila Jangan Ganggu / Penghemat Baterai sedang kita terapkan. */
    val modeActive: Boolean = false,
    /** Pesan error terakhir dari shell, untuk diagnosis di halaman Pengaturan. */
    val lastError: String = "",
) {
    val hasAccess: Boolean get() = mode != ShellRunner.Mode.NONE
}

enum class Tab { HOME, GAMES, STATS, SETTINGS, ABOUT }

/** Semua aksi yang bisa dipicu UI. Diimplementasikan oleh MainActivity. */
interface AppActions {
    /** Lakukan langkah berikutnya untuk menyambung ke Shizuku (pasang / jalankan / beri izin). */
    fun fixAccess()
    fun openShizuku()
    fun recheck()
    fun openOverlaySettings()
    fun resetDisplay()
    fun boost()
    fun launchGame(app: GameApp, percent: Int, fps: Int)
}

/** Keadaan UI. Setiap perubahan pengaturan langsung disimpan ke [GameStore]. */
class UiState(private val store: GameStore) {

    var apps by mutableStateOf<List<GameApp>>(emptyList())
    var status by mutableStateOf(SysStatus())
    var overlayGranted by mutableStateOf(false)
    var boosting by mutableStateOf(false)
    var tab by mutableStateOf(Tab.HOME)

    var scaleDensity by mutableStateOf(store.scaleDensity)
        private set
    var autoReset by mutableStateOf(store.autoReset)
        private set
    var playOptimize by mutableStateOf(store.playOptimize)
        private set
    var focusMode by mutableStateOf(store.focusMode)
        private set
    var batterySaverOff by mutableStateOf(store.batterySaverOff)
        private set
    var heatWarnC by mutableIntStateOf(store.heatWarnC)
        private set
    var autoBoost by mutableStateOf(store.autoBoost)
        private set
    var autoFps by mutableStateOf(store.autoFps)
        private set

    private val scales = mutableStateMapOf<String, Int>()
    private val fpsByGame = mutableStateMapOf<String, Int>()

    fun scaleOf(pkg: String): Int = scales[pkg] ?: store.getScale(pkg)
    fun fpsOf(pkg: String): Int = fpsByGame[pkg] ?: store.getFps(pkg)

    fun rememberProfile(pkg: String, percent: Int, fps: Int) {
        scales[pkg] = percent
        fpsByGame[pkg] = fps
    }

    /** Overlay bisa mengubah profil saat game jalan; baca ulang dari penyimpanan. */
    fun reloadProfiles() {
        scales.clear()
        fpsByGame.clear()
        autoFps = store.autoFps
        heatWarnC = store.heatWarnC
    }

    fun updateScaleDensity(v: Boolean) { scaleDensity = v; store.scaleDensity = v }
    fun updateAutoReset(v: Boolean) { autoReset = v; store.autoReset = v }
    fun updatePlayOptimize(v: Boolean) { playOptimize = v; store.playOptimize = v }
    fun updateFocusMode(v: Boolean) { focusMode = v; store.focusMode = v }
    fun updateBatterySaverOff(v: Boolean) { batterySaverOff = v; store.batterySaverOff = v }
    fun updateAutoBoost(v: Boolean) { autoBoost = v; store.autoBoost = v }
    fun updateAutoFps(v: Boolean) { autoFps = v; store.autoFps = v }

    /** 0 = peringatan mati. */
    fun updateHeatWarn(c: Int) {
        heatWarnC = c
        store.heatWarnC = c
        if (c > 0) store.lastHeatWarnC = c
    }
}
