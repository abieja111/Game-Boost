package com.gametuner.launcher

import android.content.Context
import android.hardware.display.DisplayManager
import android.view.Display
import kotlin.math.max
import kotlin.math.roundToInt

data class DisplayInfo(
    val physW: Int,
    val physH: Int,
    val physDpi: Int,
    val curW: Int,
    val curH: Int,
    val curDpi: Int,
) {
    val isOverridden: Boolean
        get() = curW != physW || curH != physH || curDpi != physDpi

    /** Skala resolusi saat ini terhadap resolusi asli layar, dalam persen. */
    val currentPercent: Int
        get() = if (physW == 0) 100 else (curW * 100f / physW).roundToInt()
}

data class Target(val w: Int, val h: Int, val dpi: Int)

/**
 * Mengubah resolusi layar (`wm size`, `wm density`) dan membatasi refresh rate
 * (`settings put system min/peak_refresh_rate`). Semua fungsi yang memanggil
 * shell bersifat blocking: panggil dari thread background.
 */
object DisplayController {

    /** Skala resolusi dalam persen; 100 = asli. Ditampilkan sebagai pengali (0.8x dst). */
    val PRESETS = listOf(100, 90, 80, 60, 50, 40, 30)

    /** Label tombol: "Asli" untuk 100, selain itu pengali seperti "0.8x". */
    fun scaleLabel(percent: Int): String =
        if (percent >= 100) "Asli" else String.format(java.util.Locale.US, "%.1fx", percent / 100f)

    private const val MIN_DPI = 120

    // ------------------------------------------------------------ resolusi

    fun read(): DisplayInfo? {
        val r = ShellRunner.exec("wm size; wm density")
        val size = Regex("""Physical size:\s*(\d+)x(\d+)""").find(r.out) ?: return null
        val dpi = Regex("""Physical density:\s*(\d+)""").find(r.out) ?: return null
        val sizeOverride = Regex("""Override size:\s*(\d+)x(\d+)""").find(r.out)
        val dpiOverride = Regex("""Override density:\s*(\d+)""").find(r.out)

        val pw = size.groupValues[1].toInt()
        val ph = size.groupValues[2].toInt()
        val pd = dpi.groupValues[1].toInt()
        return DisplayInfo(
            physW = pw,
            physH = ph,
            physDpi = pd,
            curW = sizeOverride?.groupValues?.get(1)?.toInt() ?: pw,
            curH = sizeOverride?.groupValues?.get(2)?.toInt() ?: ph,
            curDpi = dpiOverride?.groupValues?.get(1)?.toInt() ?: pd,
        )
    }

    fun target(info: DisplayInfo, percent: Int, scaleDensity: Boolean): Target {
        if (percent >= 100) return Target(info.physW, info.physH, info.physDpi)
        val f = percent / 100.0
        val dpi = if (scaleDensity) max(MIN_DPI, (info.physDpi * f).roundToInt()) else info.physDpi
        return Target(evenRound(info.physW * f), evenRound(info.physH * f), dpi)
    }

    fun setScale(percent: Int, scaleDensity: Boolean, info: DisplayInfo): CmdResult {
        if (percent >= 100) return reset()
        val t = target(info, percent, scaleDensity)
        val densityCmd = if (scaleDensity) "wm density ${t.dpi}" else "wm density reset"
        return ShellRunner.exec("wm size ${t.w}x${t.h} && $densityCmd")
    }

    /** Kembalikan resolusi dan density ke bawaan layar. */
    fun reset(): CmdResult = ShellRunner.exec("wm size reset && wm density reset")

    // -------------------------------------------------------- refresh rate

    /** Refresh rate layar saat ini (Hz); 0 bila tidak terbaca. Tidak butuh akses sistem. */
    fun currentRefreshHz(context: Context): Int = try {
        val dm = context.getSystemService(DisplayManager::class.java)
        dm.getDisplay(Display.DEFAULT_DISPLAY).refreshRate.roundToInt()
    } catch (_: Throwable) {
        0
    }

    /** Refresh rate (Hz) yang didukung panel layar, tanpa duplikat, urut naik. */
    fun supportedRates(context: Context): List<Int> = try {
        val dm = context.getSystemService(DisplayManager::class.java)
        dm.getDisplay(Display.DEFAULT_DISPLAY).supportedModes
            .map { it.refreshRate.roundToInt() }
            .filter { it >= 30 }
            .distinct()
            .sorted()
    } catch (_: Throwable) {
        emptyList()
    }

    /** Nilai mentah "min_refresh_rate" dan "peak_refresh_rate" ("null" bila belum diatur). */
    private fun rawRefreshSettings(): Pair<String, String>? {
        val r = ShellRunner.exec(
            "settings get system min_refresh_rate; settings get system peak_refresh_rate"
        )
        val lines = r.out.lines().map { it.trim() }
        if (lines.size < 2) return null
        return lines[0] to lines[1]
    }

    /** Refresh rate yang sedang dikunci (Hz), atau 0 bila otomatis / tidak dikunci. */
    fun readRefreshRate(): Int {
        val (min, peak) = rawRefreshSettings() ?: return 0
        val mn = min.toFloatOrNull() ?: return 0
        val pk = peak.toFloatOrNull() ?: return 0
        return if (mn > 0f && mn.roundToInt() == pk.roundToInt()) pk.roundToInt() else 0
    }

    /**
     * Kunci refresh rate layar ke [hz]. Nilai asli disimpan dulu (sekali) supaya
     * pengaturan pengguna bisa dipulihkan persis oleh [resetRefreshRate].
     */
    fun setRefreshRate(hz: Int, store: GameStore): CmdResult {
        if (store.savedRefresh == null) {
            rawRefreshSettings()?.let { store.savedRefresh = "${it.first}|${it.second}" }
        }
        return ShellRunner.exec(
            "settings put system min_refresh_rate $hz && settings put system peak_refresh_rate $hz"
        )
    }

    /** Pulihkan refresh rate ke nilai sebelum kita ubah. Tidak melakukan apa-apa bila belum pernah diubah. */
    fun resetRefreshRate(store: GameStore): CmdResult {
        val saved = store.savedRefresh ?: return CmdResult(true, "", "")
        val parts = saved.split("|")
        fun restore(key: String, value: String) =
            if (value.isBlank() || value == "null") "settings delete system $key"
            else "settings put system $key $value"

        val cmd = restore("min_refresh_rate", parts.getOrElse(0) { "null" }) + "; " +
            restore("peak_refresh_rate", parts.getOrElse(1) { "null" })
        val r = ShellRunner.exec(cmd)
        if (r.ok) store.savedRefresh = null
        return r
    }

    // ------------------------------------------------------------- gabungan

    /** Terapkan profil game: skala resolusi + batas refresh rate (0 = otomatis). */
    fun applyProfile(percent: Int, fps: Int, scaleDensity: Boolean, store: GameStore): CmdResult {
        val a = if (percent >= 100) {
            reset()
        } else {
            val info = read()
            if (info == null) {
                CmdResult(false, "", "Tidak ada akses sistem (Shizuku/root).")
            } else {
                setScale(percent, scaleDensity, info)
            }
        }
        val b = if (fps > 0) setRefreshRate(fps, store) else resetRefreshRate(store)
        return combine(a, b)
    }

    /** Kembalikan semuanya: resolusi, density, dan refresh rate. */
    fun resetAll(store: GameStore): CmdResult = combine(reset(), resetRefreshRate(store))

    private fun combine(a: CmdResult, b: CmdResult) = CmdResult(
        ok = a.ok && b.ok,
        out = listOf(a.out, b.out).filter { it.isNotBlank() }.joinToString("\n"),
        err = listOf(a.err, b.err).filter { it.isNotBlank() }.joinToString("\n"),
    )

    private fun evenRound(v: Double): Int = (v / 2.0).roundToInt() * 2
}
