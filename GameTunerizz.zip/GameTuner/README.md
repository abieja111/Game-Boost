# Nexus Game Boost

Launcher game untuk Android: **downscale resolusi**, **batas FPS**, **boost RAM**, **monitor perangkat**, dan **mode main**, semuanya bisa diatur langsung dari bubble pop-up saat game berjalan.

Tampilan aplikasi (menu dan panel pop-up) dan ikon NX mengikuti desain buatan pemilik aplikasi.

## Fitur

**Menu aplikasi** (bergaya launcher game, selalu **mendatar/landscape**; layar otomatis diputar ke samping)
- **Game Lobby (menu utama):** kiri = daftar game (ikon, nama, profil resolusi/FPS yang tersimpan, dan ukuran berkas aplikasi), tengah = portal bercahaya dengan ikon game terpilih melayang di atasnya, kanan = nama game besar, tombol **Start Game** dan tombol segi enam **❯** untuk mengatur resolusi (Asli, 0.9x, 0.8x, 0.6x, 0.5x, 0.4x, 0.3x) dan batas FPS. Pengaturan diterapkan dulu, baru game dibuka. Game yang paling baru dibuka dari Lobby naik ke atas daftar. Tombol **+** di daftar membuka daftar semua aplikasi untuk menambah atau menyembunyikan game; ada kolom **Cari aplikasi** di sana dan di halaman Semua Aplikasi. Yang tampil otomatis adalah aplikasi yang ditandai sebagai game oleh Android; aplikasi lain bisa ditambah dengan **+**. Angka "waktu main" tidak ada (butuh izin akses penggunaan); sebagai gantinya ditampilkan profil dan ukuran APK (tanpa data game).
- **Pojok kiri atas:** logo NX, jam, dan baterai. **Pojok kanan atas:** tombol segi enam **Statistik**, **Pengaturan**, **Tentang**.
- **Gerak dan getar di Game Lobby:** tombol dan baris game mengecil sedikit dan bergetar singkat saat diketuk, ikon game terpilih muncul dengan efek membal tiap ganti pilihan, nama dan profil game menggeser masuk dari kanan, cahaya tombol **Start Game** berdenyut pelan, titik kuning di kapsul petunjuk berkedip selama akses atau izin belum beres, dan pindah antara Game Lobby dan Super Base memudar halus.
- **Bilah bawah:** tab **Game Lobby** dan **Super Base**, kapsul petunjuk status (hijau = siap, kuning = akses sistem atau izin overlay belum aktif; ketuk untuk ke Super Base), lalu tiga tombol segi enam: **Semua Aplikasi** (daftar lengkap, ketuk aplikasi untuk atur dan luncurkan), **HUD Mini** (tampilkan), dan **Boost** (bersihkan RAM).
- **Super Base:** kartu status (Hz layar, suhu, baterai) dan empat bagian pengaturan
  - *Akses & Izin:* akses Shizuku/root, izin overlay, layar, density, reset otomatis
  - *Mode Game:* **Mode Main** (terapkan resolusi/FPS saat game dibuka) dan **Mode Fokus** (Jangan Ganggu)
  - *Penghemat & Peringatan:* matikan Penghemat Baterai selama main, **Peringatan Panas** (Mati, 40, 42, 44, 46, 48 °C)
  - *Suhu & RAM:* **Boost Otomatis** dan tombol **Boost Sekarang**
- **Statistik:** suhu, baterai, refresh rate, resolusi, RAM, dan Boost RAM
- **Pengaturan:** status sambungan Shizuku langkah demi langkah, **Auto FPS**, density, izin overlay, **Resolusi per Game**, **FPS per Game**, **DPI Normal**, reset layar, kartu **Crosshair** (bentuk, warna, ukuran, ketebalan, kecerahan, posisi, otomatis saat game dibuka), kartu **Macro (Rekam & Putar)**, kartu **Pintasan di Pop-up**, kartu **HUD Mini**, **Tes Kompatibilitas**
- **Tentang**
- Tombol kembali HP (atau tombol segi enam **❮**) dari Statistik, Pengaturan, Tentang, Semua Aplikasi, dan Super Base kembali ke Game Lobby.

**Pop-up in-game.** Ada dua cara membukanya, dipilih di Pengaturan, kartu **Buka Pop-up** (berlaku saat game dibuka berikutnya dari Game Lobby):
- **Geser dari tepi (bawaan):** selama game jalan ada garis ungu tipis di tengah pinggir layar (kiri atau kanan, pilih sendiri). Geser ke dalam dari garis itu untuk membuka pop-up; mengetuk garisnya juga membuka. Garis berubah merah saat HP panas. Ada juga tombol **Buka pop-up** di notifikasi Nexus sebagai cadangan. Di HP dengan navigasi gestur, geseran dari tepi bisa bentrok dengan gestur Kembali; aplikasi meminta Android mengecualikan area garis itu (Android 10 ke atas), tapi tidak semua HP menurutinya. Kalau bentrok, pakai tombol di notifikasi atau pilih mode Bubble.
- **Bubble (logo NX):** lingkaran melayang di atas game. Ketuk untuk membuka panel; geser untuk memindahkan.

Tampilan panel mengikuti arah layar:

**Layar landscape (game biasa): dua panel miring, tengah transparan.** Tampilannya memakai gambar desain (artwork) yang kamu berikan, satu gambar untuk panel kiri dan satu untuk panel kanan; tombol, angka, dan teks hidup diletakkan tepat di atas slot kosong pada gambar. Bagian tengah dibiarkan bening supaya game tetap kelihatan jelas (seperti Game Space); ketuk bagian tengah itu untuk mengecilkan panel kembali ke bubble.
- **Panel kiri:** empat tombol segi enam di atas: **Beranda** (rumah, buka Nexus), **Crosshair** (pena, nyala/mati), **Macro** (stik game, nyala/mati), dan **HUD Mini** (kubus, nyala/mati); tombol yang sedang menyala diberi cincin hijau. Di bawahnya daftar **Render Resolution** dan **FPS Limit** (ketuk baris untuk memilih nilai di kotak di tengah layar), lalu **FPS Sekarang**, **Suhu HP**, dan **Baterai**. Di sebelahnya pengukur **CPU** (angka besar = frekuensi tertinggi CPU dalam GHz bila HP membuka datanya, kalau tidak, beban dalam %; angkanya berubah kuning/merah bila beban tinggi), tombol **Panas** (ketuk untuk ganti batas 40, 42, 44, 46 °C atau mati), garis-garis beban (yang menyala naik sesuai beban), dan ikon kipas untuk Boost
- **Panel kanan:** logo NX (ketuk untuk mengecilkan panel), pengukur **GPU** (angka besar = frekuensi GPU dalam MHz bila terbaca, kalau tidak, beban dalam %; bila HP tidak membuka data beban GPU, otomatis berganti jadi **RAM** terpakai dalam GB), tombol **Fokus** (Jangan Ganggu, ketuk untuk nyala/mati), garis-garis beban, dan ikon kipas untuk Reset (kembalikan resolusi dan FPS ke normal). Di sisi kanan ada tujuh tombol kecil: **WiFi** (nyala/mati, butuh Shizuku atau root), **Mode Main**, **Hemat Daya**, **Auto FPS**, **Kunci Rotasi** (mengunci ke arah layar saat ini, butuh Shizuku atau root), **Boost RAM**, dan **Selesai** (mengembalikan semuanya dan menutup bubble), lalu kotak besar **+** (**Buka Nexus**) yang membuka aplikasi. Resolusi Asli dan FPS Auto tetap ada lewat daftar Render Resolution dan FPS Limit di panel kiri
- **Baris pintasan di atas** (di antara kedua panel): sampai empat ikon aplikasi, bawaannya Chrome, Discord, dan Facebook bila terpasang; ganti di Pengaturan, kartu **Pintasan di Pop-up**. Ketuk ikon untuk membuka aplikasinya (panel mengecil dan game pindah ke latar belakang, jadi kembali ke game dalam sekitar 12 detik atau Reset otomatis jalan). Tombol panah bawah di ujung kanan baris = kecilkan panel. Aplikasi terbuka layar penuh; jendela melayang seperti di HP gaming tidak tersedia
- **Kapsul di tengah bawah:** status resolusi/FPS saat ini, RAM bebas, dan lama main
- Dua sisi miring di tengah pop-up (jalur bersegmen berbentuk tanda >) adalah indikator hidup: **kiri = suhu** (naik dari bawah, hijau lalu kuning lalu merah; kosong di 30 derajat, penuh di 48) dan **kanan = baterai** (hijau, kuning di bawah 30 persen, merah di bawah 15 persen, biru muda saat mengisi daya). Titik terang menandai tingkat saat ini, dan cahayanya berdenyut saat HP panas (44 derajat ke atas) atau sedang mengisi daya.
- Pop-up lebar dipakai di semua orientasi. Di game portrait pop-up diputar 90 derajat (ukuran dan tampilannya sama dengan landscape, HP dimiringkan untuk membacanya). Latar pop-up agak tembus pandang; atur di Pengaturan, kartu **Tampilan Pop-up**, slider **Kepekatan latar** (40 sampai 100 persen, bawaan 85).
- Pop-up lebar punya animasi buka (papan kiri dan kanan menggeser masuk), tombol mengecil sedikit dan bergetar singkat saat diketuk, dan garis beban naik-turun dengan halus
- Saat Crosshair, Macro, atau HUD dinyalakan dari panel, panel otomatis dikecilkan supaya game dan lapisannya terlihat
- Ukuran panel menyesuaikan tinggi layar; di layar yang lebih pendek dari 20:9, panel diperkecil dan diletakkan di tengah secara vertikal

**Layar portrait: kartu bertumpuk selebar layar** (isinya sama): cincin GPU/CPU, FPS/Suhu/Baterai, Render Resolution dan FPS Limit (dengan saklar Auto FPS), lalu kartu Mode Main, Mode Fokus, Hemat Baterai, Peringatan Panas, Crosshair, Macro, HUD Mini, Boost, dan About. Tombol garis bawah mengecilkan panel dan **X** = Selesai. Ukuran semua elemen mengikuti ukuran layar.

Keterangan angka:
- **Frekuensi CPU/GPU** (GHz/MHz) dibaca dari `scaling_cur_freq` tiap inti (diambil yang tertinggi) dan jalur frekuensi GPU Adreno, Mali, atau MediaTek lewat Shizuku/root. Tidak semua HP membukanya; kalau tidak terbaca, pengukur menampilkan beban dalam %
- **CPU** dibaca dari `/proc/stat`; **GPU** dibaca dari jalur sistem milik Adreno, Mali, atau MediaTek. Tidak semua HP membuka data GPU (umum di HP MediaTek dan Unisoc): kalau tidak terbaca, pengukur GPU berganti jadi RAM, bukan angka karangan
- **FPS, Suhu HP, Baterai** diperbarui tiap 3 detik selama panel terbuka
- **Render Resolution:** pilihan **Asli** mengembalikan resolusi. **FPS Limit:** Auto atau batas FPS yang didukung. **Auto FPS** menurunkan ke 60 Hz saat HP panas dan menaikkannya lagi setelah suhu turun 3 °C
- **Mode Main:** profil resolusi/FPS otomatis saat game diluncurkan dari aplikasi. **Mode Fokus:** Jangan Ganggu (mode prioritas). **Hemat Baterai:** Penghemat Baterai
- **Peringatan Panas:** pesan muncul saat suhu melewati batas dan cincin bubble berubah merah
- **Crosshair** dan **Macro:** lihat bagian masing-masing di bawah. **HUD Mini:** kotak kecil melayang berisi angka pilihanmu (lihat bagian HUD Mini di bawah)
- Pilihan terakhir di bubble tersimpan sebagai profil game tersebut
- **Reset otomatis:** setelah kamu keluar dari game sekitar 12 detik, semuanya dikembalikan dan bubble ditutup (bisa dimatikan di Super Base)

## Cara kerja dan batasannya

Pengaturan sistem diubah lewat perintah shell (`wm size`, `wm density`, `settings put ...`, `cmd notification`, `am kill-all`). Perintah ini hanya bisa dijalankan akses **shell** atau **root**, bukan aplikasi biasa. Jadi aplikasi ini memakai **Shizuku** (tanpa root, disarankan) atau **root**.

- **Resolusi (0.9x, 0.8x, dst):** angka ini adalah **resolusi render game**, bukan ukuran layar. Di **Android 14 ke atas** aplikasi memakai Game Mode bawaan Android (`cmd game set --downscale 0.8 <paket>`), jadi hanya game itu yang turun resolusinya. Layar, ikon, dan aplikasi lain tidak berubah. Batasannya:
  - Game **harus dibuka ulang** supaya berlaku. Karena itu aplikasi menerapkannya sebelum game dibuka, dan perubahan dari bubble baru terasa setelah game dibuka lagi.
  - Game boleh menolak lewat pengaturannya sendiri, dan pabrikan HP (termasuk HiOS) boleh membatasinya. Kalau HP menolak, aplikasi menampilkan pesan errornya.
  - Android menyarankan tidak di bawah 0.7x karena sebagian game jadi kabur atau error.
  - Mode game bawaan game itu bisa kembali ke "standar" setelah Reset, karena Android tidak memberi tahu mode sebelumnya.
- **Resolusi seluruh layar (cadangan):** di Android 13 ke bawah, atau kalau saklar **Resolusi per Game** dimatikan di Pengaturan, dipakai `wm size` yang menurunkan resolusi **seluruh layar**. Cara ini langsung terasa, tapi semua aplikasi ikut mengecil. Tekan **Selesai** atau **Reset** setelah main.
- **DPI Normal (default 490):** DPI yang dipakai sehari-hari. Setelah main, density dikembalikan ke angka ini (bukan ke bawaan pabrik), dan pada cara seluruh layar density dihitung dari angka ini. Bisa diubah atau diset Otomatis di Pengaturan, bagian Layar. Reset otomatis tidak menyentuh DPI kalau bukan aplikasi ini yang mengubah layar. Tombol **Reset Layar Sekarang** selalu mengembalikan ke DPI Normal.
- **Atur FPS:** di **Android 14 ke atas** batas FPS dipasang khusus untuk game itu lewat Game Mode (`cmd game set --fps 60 <paket>`; nilai yang dikenal: 30, 45, 60, 90, 120) dan refresh rate layar tidak diubah. Game harus dibuka ulang supaya berlaku, dan HP boleh membatasinya. Nilai yang tidak dikenal Game Mode, atau kalau HP menolak, otomatis memakai cara lama: mengunci **refresh rate layar** (misalnya 60 atau 90 Hz). Saklar **FPS per Game** di Pengaturan mematikan cara Game Mode. Game yang punya pilihan FPS sendiri di dalam game tetap perlu diatur di sana, dan beberapa merek HP memakai pengaturan refresh rate sendiri sehingga kunci refresh rate bisa tidak berpengaruh.
- **Crosshair:** titik bidik kecil di tengah layar yang tidak menangkap sentuhan (ketukanmu tetap sampai ke game). Atur di Pengaturan, kartu **Crosshair**: **bentuk** (Plus, Titik, Lingkaran, Silang, Huruf T, Cincin Plus, Siku), **warna** (8 pilihan: merah, oranye, kuning, hijau, cyan, biru, ungu, putih), **ukuran** (8 sampai 120 dp), **ketebalan**, **kecerahan**, dan **geser kiri/kanan dan atas/bawah** dari titik tengah. Ada pratinjau langsung, dan perubahan juga terlihat di game dalam sekitar 1 detik. Nyalakan lewat tombol **Tampilkan / Sembunyikan**, tombol pena di pop-up lebar, atau saklar Crosshair di panel portrait. Saklar **Otomatis saat game dibuka** memunculkannya begitu game dibuka dari Game Lobby. Garis tepi gelap tipis membuatnya tetap terbaca di latar terang. Karena aturan sentuhan Android 12 ke atas (overlay yang dilewati sentuhan tidak boleh lebih pekat dari 80%), crosshair paling terang tampil sekitar 80%. Sebagian game melarang overlay bidik, jadi pakai dengan bijak.
- **Macro (rekam dan putar ketukan):** menggantikan Trigger. Ketuk **Tampilkan Macro** di Pengaturan (atau nyalakan saklar Macro di panel, atau tombol stik di pop-up lebar). Muncul kapsul kecil yang bisa digeser: **M1·12** (slot dan jumlah langkah, ketuk untuk ganti slot M1 sampai M3), **●** rekam, **▶** putar, **×1** (jumlah ulangan: 1, 3, 5, 10, atau ∞), **100%** (kecepatan putar ulang: 50 sampai 300%, hanya jeda antar langkah yang diubah), tong sampah (hapus slot), dan silang (tutup). Cara pakai: tekan **●**, lalu ketuk atau geser layar seperti biasa (maksimal 200 langkah), tekan **■** untuk menyimpan ke slot, lalu **▶** untuk memutar; ketuk **■** saat diputar untuk berhenti. Selama merekam, sebuah lapisan menangkap sentuhan sehingga game tidak menerima sentuhanmu; yang tercatat adalah posisi, jeda, dan lama tahan tiap sentuhan. Batasan: hanya satu jari yang direkam (gerak multi-jari belum didukung), geseran diputar sebagai garis lurus dari titik awal ke titik akhir, dan koordinatnya tetap sehingga rekaman dari orientasi layar lain tidak cocok. Rekaman tersimpan di HP dan tidak hilang saat aplikasi ditutup. Putaran berhenti sendiri saat layar mati atau setelah jumlah ulangan tercapai; sambil Macro tampil, reset otomatis dijeda, jadi tutup Macro dengan tombol silang. Ada dua cara memutar: **Layanan Aksesibilitas** (cepat; nyalakan lewat tombol Buka atau Nyalakan Otomatis lewat Shizuku) dan, bila layanan itu belum aktif, `input tap` / `input swipe` lewat Shizuku atau root (lebih lambat, jeda sekitar 0,2 sampai 0,5 detik per langkah). Layanan Aksesibilitas ini hanya mengirim ketukan dan geseran dan tidak meminta izin membaca isi layar. Di Android 13 ke atas, aplikasi yang dipasang dari luar Play Store mungkin menolak dinyalakan lewat pengaturan sampai kamu memilih Info aplikasi, titik tiga, **Izinkan setelan terbatas**. Sebagian game melarang ketukan otomatis, jadi pakai dengan bijak.
- **Tes Kompatibilitas:** di Pengaturan. Mengecek akses sistem, perintah Game Mode (resolusi dan FPS, diuji pada aplikasi ini sendiri lalu dibersihkan), layar dan DPI, refresh rate, pengukur FPS, dan deteksi aplikasi di depan. Hasilnya bisa disalin untuk dikirim.
- **HUD Mini (FPS dll):** pil kecil yang melayang di atas layar: logo NX, angka FPS besar, chip kualitas (**Smooth** 55 FPS ke atas, **Normal** 30 sampai 54, **Laggy** di bawah 30; ini hanya label dari angka FPS) dan tombol X. Hanya menampilkan angka yang kamu pilih: **FPS saja** (bawaan), atau tambah suhu, baterai, CPU, GPU, dan RAM (tombol **Lengkap** memilih semuanya kecuali GPU). Pilih angkanya di Pengaturan, kartu HUD Mini, lalu ketuk **Tampilkan HUD** (atau nyalakan saklar HUD Mini di panel bubble). Geser untuk memindahkan, ketuk X (atau tekan lama sekitar 1 detik) untuk menutup. Diperbarui tiap 2 detik. FPS diukur pada aplikasi yang sedang di depan, jadi HUD juga bisa dipakai di luar game dari Nexus; syaratnya sama dengan angka FPS di panel (lihat di bawah). Angka yang tidak bisa dibaca HP-mu tampil "—", dan GPU memang tidak terbaca di banyak HP MediaTek/Unisoc. HUD menangkap sentuhan di area kecilnya sendiri, jadi geser ke tempat yang tidak menutupi tombol game. HUD ikut hilang saat bubble ditutup (Selesai atau reset otomatis).
- **Angka FPS di panel:** diperkirakan dari data frame SurfaceFlinger (`dumpsys SurfaceFlinger --latency`). Tidak semua HP atau versi Android mengisi data itu. Kalau gagal, panel menampilkan "—", bukan angka karangan. Angka "Hz Layar" di Beranda adalah refresh rate panel, bukan FPS game.
- **Refresh rate asli dipulihkan:** nilai pengaturan sebelum diubah disimpan, lalu dikembalikan persis saat Reset atau Selesai.
- **Mode main hanya memulihkan yang dia ubah:** kalau Jangan Ganggu sudah menyala, atau Penghemat Baterai sudah mati sebelum main, keduanya tidak disentuh sama sekali. Mode Fokus memakai mode "prioritas", jadi telepon dari kontak prioritas dan alarm tetap bunyi sesuai pengaturan HP-mu. Saklar Hemat Baterai di panel adalah kendali manual: apa pun yang kamu pilih di sana tidak dibalik otomatis.
- **Boost:** menjalankan `am kill-all`, yang mematikan proses latar yang aman dimatikan. Android sering memulai ulang sebagian aplikasi itu, jadi efeknya bisa sementara dan kadang kecil. Aplikasi menampilkan selisih RAM bebas sesudahnya. **Boost Otomatis** hanya jalan saat RAM bebas di bawah sekitar 12% (atau 700 MB), dengan jeda minimal 90 detik.
- **Peringatan panas / Auto FPS:** memakai suhu baterai, bukan suhu chip. Angkanya hanya perkiraan kasar kondisi HP. Peringatan muncul sekali, lalu baru muncul lagi setelah suhu turun 2 °C. Auto FPS memakai batas suhu yang sama (44 °C bila peringatan dimatikan) dan baru bekerja setelah game dibuka dari aplikasi ini sehingga bubble aktif.
- **Reset otomatis:** aplikasi memeriksa aplikasi yang sedang di depan tiap 4 detik (lewat `dumpsys`). Kalau kamu keluar dari game lebih dari ±12 detik, semuanya dikembalikan dan bubble ditutup. Membuka Nexus Game Boost sendiri tidak dihitung keluar dari game. Membuka aplikasi lain lebih dari 12 detik (misalnya login lewat browser) juga dianggap keluar. Kalau aplikasi tidak bisa memastikan mana yang di depan (format `dumpsys` berbeda antar HP), tidak ada yang direset otomatis, jadi tetap tekan **Selesai** untuk jaga-jaga.
- Layar akan berkedip sebentar saat resolusi berubah. Ini normal.
- Sebagian game membaca resolusi hanya saat dibuka, jadi perubahan dari bubble mungkin baru terasa setelah game dibuka ulang.

## Cara mendapatkan APK

Build dilakukan di server GitHub (gratis), hasilnya APK yang muncul di bagian **Releases** repo kamu. Tinggal tap file `GameTuner-debug.apk` untuk mengunduh.

**Opsi A: dari PC atau laptop**
1. Ekstrak zip ini.
2. Buat repo baru di GitHub (pilih Private), lalu unggah **isi** folder `GameTuner` lewat link "uploading an existing file". Pastikan folder `.github` ikut.
3. Build jalan otomatis. Setelah hijau, buka **Releases** di halaman utama repo dan unduh APK-nya.

**Opsi B: dari HP saja**
Upload web di HP tidak bisa memilih folder, jadi zip diunggah apa adanya dan GitHub yang mengekstraknya.
1. Buat repo baru (Private), centang **Add a README file**.
2. **Add file → Upload files**, pilih zip ini, lalu **Commit changes**.
3. **Add file → Create new file**, ketik nama `.github/workflows/build.yml`, lalu tempel isi file `build-dari-zip.yml` (ada di dalam zip ini) dan **Commit changes**.
4. Tunggu sekitar 5–10 menit sampai build hijau, lalu unduh APK dari **Releases**.

## Memperbarui ke versi baru

1. Unggah zip yang baru ke repo yang sama (**Add file → Upload files**). Workflow otomatis memakai zip yang paling baru, jadi zip lama tidak perlu dihapus.
2. Tunggu build hijau, lalu unduh APK dari **Releases** (pilih build dengan nomor paling besar).
3. Pasang APK-nya. Aplikasi ini memakai kunci tanda tangan tetap (`app/debug.keystore`), jadi APK baru langsung menimpa versi lama. Tidak perlu menghapus aplikasi, dan profil game serta pengaturanmu tetap ada.

**Perhatian, sekali saja:** APK dari zip lama (sebelum ada `app/debug.keystore`) ditandatangani kunci acak yang berbeda di setiap build. Kalau di HP-mu sudah terpasang APK seperti itu, **uninstall dulu** Game Tuner yang lama sebelum memasang yang ini. Kalau tidak, Android menolak dengan pesan "App not installed". Setelah itu izin Shizuku dan pengaturan perlu diatur ulang. Untuk versi-versi berikutnya hal ini tidak perlu diulang.

`app/debug.keystore` adalah kunci debug yang tidak rahasia dan hanya cukup untuk memasang update di HP sendiri. Jangan dipakai untuk merilis ke Play Store.

## Cara pakai pertama kali

1. Pasang **Shizuku** dari Play Store atau shizuku.rikka.app, lalu jalankan lewat *Wireless debugging* (ikuti petunjuk di aplikasi Shizuku). Perlu diulang setelah HP restart.
2. Buka Nexus Game Boost. Buka tab **Super Base**, bagian *Akses & Izin*, nyalakan saklar **Akses Sistem Root / Shizuku** dan setujui permintaan Shizuku.
3. Nyalakan saklar **Izin Pop Up Overlay** dan aktifkan izin tampil di atas aplikasi lain.
4. Di **Game Lobby** pilih game di daftar kiri, ketuk **❯** untuk atur resolusi dan FPS (atau langsung **Start Game**).

## Kalau tidak bisa tersambung ke Shizuku

Buka tab **Pengaturan**. Bagian *Sambungan Shizuku* menampilkan tiga langkah dengan tanda centang, dan satu tombol untuk langkah berikutnya:

| Yang terlihat | Artinya | Yang dilakukan |
|---|---|---|
| "Aplikasi Shizuku terpasang" belum centang | Shizuku belum dipasang | Ketuk **Unduh Shizuku**, pasang, lalu **Cek Ulang** |
| "Layanan Shizuku berjalan" belum centang | Shizuku terpasang tapi belum dinyalakan (hilang tiap HP restart) | Ketuk **Buka Shizuku**, lalu **Mulai** |
| "Izin untuk Nexus Game Boost" belum centang | Layanan jalan, izin belum diberikan | Ketuk **Beri Izin**, pilih **Izinkan** |
| Izin pernah ditolak | Shizuku tidak menampilkan dialog lagi | Buka Shizuku, **Aplikasi terotorisasi**, aktifkan Nexus Game Boost |

Pesan error terakhir dari perintah shell ikut ditampilkan di bagian itu, supaya penyebabnya kelihatan kalau kirim tangkapan layar.

Penyebab teknis yang sudah diperbaiki di versi ini: aplikasi sekarang mendeklarasikan izin `moe.shizuku.manager.permission.API_V23` dan mengizinkan pengecekan paket Shizuku di Android 11 ke atas. Tanpa itu aplikasi tidak terdaftar di Shizuku dan tombol izin bisa tidak berbuat apa-apa.

## Kalau layar atau pengaturan tersangkut

Dari Nexus Game Boost buka **Pengaturan** lalu tekan **Reset Layar Sekarang**; ini mengembalikan layar dan Mode main. Kalau aplikasi tidak bisa dibuka, jalankan dari PC lewat ADB:

```
adb shell wm size reset
adb shell wm density 490
adb shell cmd game reset <nama.paket.game>
adb shell settings delete system min_refresh_rate
adb shell settings delete system peak_refresh_rate
adb shell cmd notification set_dnd off
adb shell settings put global low_power 1
```

`wm density 490` mengembalikan ke DPI-mu (ganti angkanya kalau DPI-mu lain; `wm density reset` kembali ke bawaan pabrik). Baris `cmd game reset` hanya perlu kalau tadi resolusi per game dipakai; ganti `<nama.paket.game>` dengan paket game-nya. Dua perintah terakhir hanya perlu kalau tadi Mode Fokus atau Penghemat Baterai ikut diubah. Perintah refresh rate menghapus pengaturan refresh rate; kalau sebelumnya kamu pernah mengaturnya sendiri di Pengaturan HP, atur ulang di sana. `low_power 1` menyalakan Penghemat Baterai, jadi lewati baris itu kalau sebelumnya memang tidak kamu pakai.

## Aset dan lisensi

- Logo NX, ikon aplikasi, dan desain tampilan: buatan pemilik aplikasi.
- Ikon antarmuka di `app/src/main/res/drawable/ic_*.xml`: digambar sendiri sebagai VectorDrawable (Apache-2.0).
- [Shizuku](https://github.com/RikkaApps/Shizuku-API) oleh RikkaApps (Apache-2.0).

## Status

Versi sebelumnya sudah berhasil dibuild di GitHub Actions. Versi ini (menu utama Game Lobby, pop-up dua panel, HUD FPS baru, tampilan baru, ikon baru, perbaikan Shizuku, HUD Mini, panel bubble baru (cincin GPU/CPU, kartu Mode Main/Fokus/Hemat Baterai/Peringatan Panas), Auto FPS, Boost Otomatis, pengukur FPS, resolusi dan FPS per game lewat Game Mode, DPI Normal, pop-up berbasis artwork, Crosshair, Macro, buka pop-up dengan geser dari tepi, Tes Kompatibilitas) **belum dikompilasi** karena lingkungan penyusunnya tidak punya akses ke server Gradle/Maven, dan belum ada fitur yang diuji berjalan di HP. Kode sudah diperiksa manual (kurung, referensi resource, XML), tapi kesalahan kecil saat kompilasi masih mungkin. Kalau build menampilkan error, kirim pesan errornya agar bisa diperbaiki.

## Ide berikutnya

- Kunci kecerahan dan rotasi layar selama main
