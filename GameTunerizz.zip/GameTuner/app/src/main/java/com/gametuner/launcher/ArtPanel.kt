package com.gametuner.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.CornerPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Pop-up lebar berbasis gambar (artwork): dua papan, kiri dan kanan, tiap papan adalah satu gambar
 * dengan bagian tengah transparan. Semua tombol, angka, dan teks yang hidup diletakkan sebagai view
 * transparan di atas "slot" pada gambar. Koordinat slot ditulis dalam piksel gambar asli
 * (1870 x 841); [ArtBoard.place] mengubahnya sesuai skala layar.
 */
internal object Art {
    /** Lebar satu papan pada gambar asli. */
    const val BOARD_W = 735

    /** Tinggi gambar asli. */
    const val BOARD_H = 841

    /** Papan kanan dipotong dari gambar asli mulai kolom ini. */
    const val RIGHT_ORIGIN = 1135

    /** Skala piksel layar per piksel gambar, supaya kedua papan muat dan tinggi layar terisi. */
    fun scaleFor(widthPx: Int, heightPx: Int): Float =
        min(heightPx / BOARD_H.toFloat(), widthPx / (2f * BOARD_W + 120f))

    val TEXT = 0xFFFFFFFF.toInt()
    val MUTED = 0xFFC9BDF2.toInt()
    val GLOW = 0xFFB66DFF.toInt()
    val GREEN = 0xFF34D399.toInt()
    val AMBER = 0xFFFFA94D.toInt()
    val RED = 0xFFFF6B5A.toInt()
    val RING = 0xFFE9D5FF.toInt()
    val ACTIVE_FILL = 0x663B0F8F

    fun TextView.srcSize(v: Float, s: Float) {
        setTextSize(TypedValue.COMPLEX_UNIT_PX, v * s)
    }

    /** Efek tekan: tombol mengecil sedikit saat ditekan, lalu kembali. */
    fun pressScale(v: View, pressed: Boolean) {
        val to = if (pressed) 0.94f else 1f
        v.animate().cancel()
        v.animate().scaleX(to).scaleY(to).setDuration(if (pressed) 70L else 130L).start()
    }

    /** Getar singkat saat tombol diketuk (hanya bila "umpan balik sentuh" di HP aktif). */
    fun tick(v: View) {
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    /** Lapisan terang tipis saat ditekan; tanpa itu tombol di atas gambar tidak memberi umpan balik. */
    fun pressOverlay(radiusPx: Float): Drawable = StateListDrawable().apply {
        addState(
            intArrayOf(android.R.attr.state_pressed),
            GradientDrawable().apply {
                setColor(0x33FFFFFF)
                cornerRadius = radiusPx
            }
        )
        addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
    }
}

/** Pintasan aplikasi di bagian atas pop-up lebar. */
internal object Shortcuts {
    /** Jumlah pintasan paling banyak. */
    const val MAX = 4

    private val CANDIDATES = listOf(
        "com.android.chrome",
        "com.discord",
        "com.facebook.katana",
        "com.whatsapp",
        "com.google.android.youtube",
        "org.telegram.messenger",
        "com.instagram.android",
    )

    /**
     * Daftar paket yang dipakai: pilihan pengguna ([saved]) atau, bila null, tiga aplikasi populer
     * pertama yang terpasang. Aplikasi yang sudah tidak terpasang atau tidak bisa dibuka dibuang.
     */
    fun resolve(pm: PackageManager, saved: List<String>?): List<String> {
        val list = saved ?: CANDIDATES.filter { pm.getLaunchIntentForPackage(it) != null }.take(3)
        return list.filter { pm.getLaunchIntentForPackage(it) != null }.distinct().take(MAX)
    }
}

/** Satu papan: gambar latar sebesar [Art.BOARD_W] x [Art.BOARD_H] dikali [s], dan tempat meletakkan view di slotnya. */
internal class ArtBoard(
    context: Context,
    artRes: Int,
    private val s: Float,
    private val originX: Int,
    artAlpha: Float = 1f,
) : FrameLayout(context) {

    init {
        val bg = ImageView(context).apply {
            setImageResource(artRes)
            scaleType = ImageView.ScaleType.FIT_XY
            // Hanya latarnya yang dibuat agak tembus pandang; angka dan teks di atasnya tetap tegas.
            alpha = artAlpha.coerceIn(0.3f, 1f)
        }
        addView(bg, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        // Ketukan di papan tidak boleh sampai ke latar yang mengecilkan panel.
        isClickable = true
    }

    /** Letakkan [v] pada kotak ([x0],[y0])-([x1],[y1]) dalam koordinat gambar asli. */
    fun place(v: View, x0: Int, y0: Int, x1: Int, y1: Int) {
        val lp = LayoutParams(
            ((x1 - x0) * s).roundToInt(),
            ((y1 - y0) * s).roundToInt(),
            Gravity.TOP or Gravity.START
        ).apply {
            leftMargin = ((x0 - originX) * s).roundToInt()
            topMargin = (y0 * s).roundToInt()
        }
        addView(v, lp)
    }

    /** Pasang [v] menutupi seluruh papan (untuk lapisan yang menggambar langsung di atas gambar). */
    fun addOverlay(v: View) {
        addView(v, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    fun boardWidth(): Int = (Art.BOARD_W * s).roundToInt()
    fun boardHeight(): Int = (Art.BOARD_H * s).roundToInt()
}

/**
 * Indikator di sisi miring papan: jalur segmen bercahaya yang membentuk tanda ">" di pinggir tengah
 * (papan kanan adalah bayangan cerminnya). Bagian yang "terisi" menyala dengan warna indikator, mulai dari
 * ujung bawah naik ke puncak lalu ke atas, dan sisanya digelapkan. Titik terang menandai tingkat saat ini.
 * Koordinat jalur diukur dari gambar asli (papan kiri; papan kanan dicerminkan).
 */
internal class ArtEdge(
    context: Context,
    private val s: Float,
    private val mirrored: Boolean,
) : View(context) {

    /** Pecahan terisi yang sedang tampak (berubah halus saat animasi), 0 sampai 1. */
    private var shown = 0f
    private var accent = Art.GREEN
    private var anim: ValueAnimator? = null

    // Denyut cahaya (misalnya saat mengisi daya atau HP terlalu panas): 0 sampai 1 bolak-balik.
    private var wantPulse = false
    private var phase = 0f
    private var pulseAnim: ValueAnimator? = null

    private val dimPaint = strokePaint(0xA6000000.toInt())
    private val tintPaint = strokePaint(0)
    private val corePaint = strokePaint(0)
    private val headFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val headRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFFFFFFFF.toInt()
    }
    private val path = Path()

    private val lenBA = hypot(AX - BX, AY - BY)
    private val lenAT = hypot(TX - AX, TY - AY)

    // Ujung jalur diperpanjang sedikit keluar papan supaya goresan sampai ke tepi tanpa celah.
    private val bExtX = BX + (BX - AX) / lenBA * EXT
    private val bExtY = BY + (BY - AY) / lenBA * EXT
    private val tExtX = TX + (TX - AX) / lenAT * EXT
    private val tExtY = TY + (TY - AY) / lenAT * EXT

    private fun strokePaint(c: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = c
        strokeJoin = Paint.Join.ROUND
    }

    private fun px(x: Float): Float = (if (mirrored) Art.BOARD_W - x else x) * s
    private fun py(y: Float): Float = y * s

    /** [fraction] 0 sampai 1 = seberapa penuh indikator; [color] = warna cahayanya; [pulse] = cahaya berdenyut. */
    fun setLevel(fraction: Float, color: Int, pulse: Boolean = false) {
        accent = color
        wantPulse = pulse
        syncPulse()
        val target = fraction.coerceIn(0f, 1f)
        anim?.cancel()
        anim = null
        if (!isAttachedToWindow || kotlin.math.abs(target - shown) < 0.005f) {
            shown = target
            invalidate()
            return
        }
        anim = ValueAnimator.ofFloat(shown, target).apply {
            duration = 600L
            interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener {
                shown = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun syncPulse() {
        if (!wantPulse || !isAttachedToWindow) {
            pulseAnim?.cancel()
            pulseAnim = null
            phase = 0f
            invalidate()
            return
        }
        if (pulseAnim != null) return
        pulseAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700L
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        syncPulse()
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        pulseAnim?.cancel()
        pulseAnim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val band = BAND * s
        dimPaint.strokeWidth = band
        tintPaint.strokeWidth = band
        tintPaint.color = (accent and 0x00FFFFFF) or ((0x52 + (0x30 * phase).toInt()) shl 24)
        corePaint.strokeWidth = (5f * s).coerceAtLeast(2f)
        corePaint.color = (accent and 0x00FFFFFF) or 0xE6000000.toInt()
        headFill.color = accent
        headRing.strokeWidth = (3f * s).coerceAtLeast(1.5f)

        val d = shown.coerceIn(0f, 1f) * (lenBA + lenAT)
        val hx: Float
        val hy: Float
        if (d <= lenBA) {
            val t = d / lenBA
            hx = BX + (AX - BX) * t
            hy = BY + (AY - BY) * t
        } else {
            val t = (d - lenBA) / lenAT
            hx = AX + (TX - AX) * t
            hy = AY + (TY - AY) * t
        }

        // Bagian yang belum terisi: digelapkan.
        path.reset()
        path.moveTo(px(hx), py(hy))
        if (d < lenBA) path.lineTo(px(AX), py(AY))
        path.lineTo(px(tExtX), py(tExtY))
        canvas.drawPath(path, dimPaint)

        // Bagian yang terisi: diberi warna, ada garis terang di tengah, dan titik di ujungnya.
        if (d > 0f) {
            path.reset()
            path.moveTo(px(bExtX), py(bExtY))
            if (d > lenBA) path.lineTo(px(AX), py(AY))
            path.lineTo(px(hx), py(hy))
            canvas.drawPath(path, tintPaint)
            canvas.drawPath(path, corePaint)
            val r = 10f * s * (1f + 0.45f * phase)
            canvas.drawCircle(px(hx), py(hy), r, headFill)
            canvas.drawCircle(px(hx), py(hy), r, headRing)
        }
    }

    companion object {
        // Garis tengah jalur pada papan kiri, dalam koordinat gambar asli: ujung bawah, puncak, ujung atas.
        private const val BX = 369f
        private const val BY = 841f
        private const val AX = 701f
        private const val AY = 283f
        private const val TX = 518f
        private const val TY = 0f
        private const val BAND = 46f
        private const val EXT = 40f
    }
}

/**
 * Tombol transparan di atas gambar. [hex] = bentuk segi enam (tombol ikon di atas), selain itu
 * kotak bersudut. [active] menandai tombol yang sedang menyala dengan cincin dan isian hijau.
 * [caption] (opsional) digambar di bagian bawah.
 */
internal class ArtHit(
    context: Context,
    private val s: Float,
    private val hex: Boolean = false,
    private val caption: String? = null,
) : View(context) {

    var active: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        pathEffect = CornerPathEffect(4f * s)
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
        pathEffect = CornerPathEffect(4f * s)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Art.TEXT
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        textSize = 17f * s
    }
    private val path = Path()

    init {
        isClickable = true
    }

    override fun setPressed(pressed: Boolean) {
        val changed = pressed != isPressed
        super.setPressed(pressed)
        if (changed) Art.pressScale(this, pressed)
        invalidate()
    }

    override fun performClick(): Boolean {
        Art.tick(this)
        return super.performClick()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val inset = 3f * s
        path.reset()
        if (hex) {
            val cx = w / 2f
            val cy = h / 2f
            val r = min(w, h) / 2f - inset
            for (k in 0 until 6) {
                val a = Math.toRadians((-90 + 60 * k).toDouble())
                val x = cx + r * cos(a).toFloat()
                val y = cy + r * sin(a).toFloat()
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
        } else {
            val c = 10f * s
            path.moveTo(inset + c, inset)
            path.lineTo(w - inset - c, inset)
            path.lineTo(w - inset, inset + c)
            path.lineTo(w - inset, h - inset - c)
            path.lineTo(w - inset - c, h - inset)
            path.lineTo(inset + c, h - inset)
            path.lineTo(inset, h - inset - c)
            path.lineTo(inset, inset + c)
            path.close()
        }

        if (active) {
            fill.color = 0x4034D399
            canvas.drawPath(path, fill)
            line.color = 0x5534D399
            line.strokeWidth = 7f * s
            canvas.drawPath(path, line)
            line.color = Art.GREEN
            line.strokeWidth = 2.5f * s
            canvas.drawPath(path, line)
        }
        if (isPressed) {
            fill.color = 0x38FFFFFF
            canvas.drawPath(path, fill)
        }
        if (caption != null) {
            canvas.drawText(caption, w / 2f, h - 6f * s, text)
        }
    }
}

/**
 * Baris di daftar kiri (di atas kartu pada gambar): judul kecil, nilai tebal, dan titik tiga bila
 * [withMore]. Nilai diubah lewat [setValue] atau langsung lewat [valueView].
 */
internal class ArtRow(
    context: Context,
    private val s: Float,
    title: String,
    withMore: Boolean,
) : FrameLayout(context) {

    private val value = TextView(context)

    /** TextView nilai, dipakai langsung oleh kode pembaruan statistik. */
    val valueView: TextView get() = value

    init {
        foreground = Art.pressOverlay(12f * s)

        val col = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        col.addView(TextView(context).apply {
            text = title
            with(Art) { srcSize(17f, s) }
            setTextColor(Art.MUTED)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        value.apply {
            text = "—"
            with(Art) { srcSize(27f, s) }
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Art.TEXT)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        col.addView(value)
        addView(
            col,
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
                leftMargin = (22f * s).roundToInt()
                rightMargin = ((if (withMore) 40f else 14f) * s).roundToInt()
            }
        )
        if (withMore) {
            val more = ImageView(context).apply {
                setImageResource(R.drawable.ic_more_v)
                imageTintList = ColorStateList.valueOf(Art.MUTED)
            }
            addView(
                more,
                LayoutParams((26f * s).roundToInt(), (26f * s).roundToInt(), Gravity.END or Gravity.CENTER_VERTICAL)
                    .apply { rightMargin = (8f * s).roundToInt() }
            )
        }
    }

    override fun setPressed(pressed: Boolean) {
        val changed = pressed != isPressed
        super.setPressed(pressed)
        if (changed) Art.pressScale(this, pressed)
    }

    override fun performClick(): Boolean {
        Art.tick(this)
        return super.performClick()
    }

    fun setValue(text: String) {
        value.text = text
    }
}

/**
 * Pengukur di atas alas hologram pada gambar: angka besar, satuan, dan label (CPU/GPU/RAM) digambar
 * di tempat teks aslinya. Warna angka berubah ke kuning/merah bila [progress] melewati batas.
 * [progress] null = datanya tidak tersedia; angka tampil "—", bukan angka karangan.
 * Ukuran view = 240 x 225 piksel gambar asli, titik tengah angka di x = 120.
 */
internal class ArtGauge(context: Context, private val s: Float) : View(context) {
    var value: String = "—"
        set(v) {
            field = v
            invalidate()
        }
    var unitText: String = ""
        set(v) {
            field = v
            invalidate()
        }
    var label: String = ""
        set(v) {
            field = v
            invalidate()
        }
    var progress: Int? = null
        set(v) {
            field = v
            invalidate()
        }
    var warnFrom: Int = 70
    var alertFrom: Int = 90

    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        setShadowLayer(7f * s, 0f, 0f, Art.GLOW)
    }
    private val unitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        color = Art.TEXT
        textSize = 26f * s
    }
    private val tagPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        color = Art.TEXT
        textSize = 24f * s
    }

    fun setPercent(p: Int?, unitLabel: String = "%") {
        progress = p
        value = p?.toString() ?: "—"
        unitText = if (p != null) unitLabel else ""
    }

    /** Tampilkan [valueText] dan [unit] (misalnya 2.71 GHz), sedangkan warna angka tetap mengikuti beban [load]. */
    fun setReading(valueText: String, unit: String, load: Int?) {
        progress = load
        value = valueText
        unitText = unit
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val p = progress
        num.color = when {
            p == null -> Art.TEXT
            p >= alertFrom -> Art.RED
            p >= warnFrom -> Art.AMBER
            else -> Art.TEXT
        }

        // Angka: 58 px gambar, mengecil bila terlalu lebar untuk alas hologram.
        var size = 58f * s
        num.textSize = size
        val maxW = 170f * s
        val tw = num.measureText(value)
        if (tw > maxW) {
            size *= maxW / tw
            num.textSize = size
        }
        canvas.drawText(value, cx, 68f * s, num)
        if (unitText.isNotEmpty()) canvas.drawText(unitText, cx, 96f * s, unitPaint)

        // Label di tab bawah alas.
        if (label.isNotEmpty()) {
            val base = 203f * s - (tagPaint.ascent() + tagPaint.descent()) / 2f
            canvas.drawText(label, cx, base, tagPaint)
        }
    }
}

/**
 * Garis-garis beban pada gambar (16 garis, di gambar tampil menyala semua = 100%). Garis di atas
 * level [percent] digelapkan supaya terlihat padam. [percent] null = tidak ada data: semua padam.
 * Ukuran view = 175 x 223 piksel gambar asli; [onLeft] memilih bentuk miring kiri atau kanan.
 */
internal class ArtMeter(
    context: Context,
    private val s: Float,
    private val onLeft: Boolean,
) : View(context) {

    var percent: Int? = null
        set(v) {
            field = v
            animateTo(if (v == null) 0f else kotlin.math.ceil(v.coerceIn(0, 100) / 100f * BARS))
        }

    /** Jumlah garis yang sedang tampak menyala (pecahan selama animasi). */
    private var shownLit = 0f
    private var anim: ValueAnimator? = null

    private fun animateTo(target: Float) {
        anim?.cancel()
        anim = null
        if (!isAttachedToWindow || kotlin.math.abs(target - shownLit) < 0.01f) {
            shownLit = target
            invalidate()
            return
        }
        anim = ValueAnimator.ofFloat(shownLit, target).apply {
            duration = 380L
            interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener {
                shownLit = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        super.onDetachedFromWindow()
    }

    private val dim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xDD000006.toInt()
    }
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        // Batas antara garis padam (atas) dan menyala (bawah), dalam koordinat gambar asli.
        val boundary = FIRST_GAP + PITCH * (BARS - shownLit)
        val yb = (boundary - ORIGIN_Y) * s
        if (yb <= 0f) return

        // Poligon yang menutupi semua garis, dipotong di [yb]. Titik dalam koordinat gambar asli.
        val x0 = if (onLeft) LEFT_ORIGIN else RIGHT_ORIGIN
        path.reset()
        if (onLeft) {
            // Sisi kanan miring: x(y) = 511 - 0.655 (y - 505), diberi margin 4.
            val topX = 511f - SLOPE * (TOP_Y - 505f) + 4f
            val botX = 511f - SLOPE * (BOT_Y - 505f) + 4f
            path.moveTo((355f - x0) * s, (TOP_Y - ORIGIN_Y) * s)
            path.lineTo((topX - x0) * s, (TOP_Y - ORIGIN_Y) * s)
            path.lineTo((botX - x0) * s, (BOT_Y - ORIGIN_Y) * s)
            path.lineTo((355f - x0) * s, (BOT_Y - ORIGIN_Y) * s)
        } else {
            // Sisi kiri miring: x(y) = 1357 + 0.655 (y - 505), diberi margin 4.
            val topX = 1357f + SLOPE * (TOP_Y - 505f) - 4f
            val botX = 1357f + SLOPE * (BOT_Y - 505f) - 4f
            path.moveTo((topX - x0) * s, (TOP_Y - ORIGIN_Y) * s)
            path.lineTo((1515f - x0) * s, (TOP_Y - ORIGIN_Y) * s)
            path.lineTo((1515f - x0) * s, (BOT_Y - ORIGIN_Y) * s)
            path.lineTo((botX - x0) * s, (BOT_Y - ORIGIN_Y) * s)
        }
        path.close()

        canvas.save()
        canvas.clipRect(0f, 0f, width.toFloat(), yb.coerceAtMost(height.toFloat()))
        canvas.drawPath(path, dim)
        canvas.restore()
    }

    companion object {
        const val BARS = 16
        const val ORIGIN_Y = 495f
        const val FIRST_GAP = 499f
        const val PITCH = 13.4f
        const val TOP_Y = 498f
        const val BOT_Y = 716f
        const val SLOPE = 0.655f
        const val LEFT_ORIGIN = 350f
        const val RIGHT_ORIGIN = 1345f
    }
}

/** Tombol pilihan lebar di bawah alas (seperti "Rise"): teks tengah yang bisa diganti, ikon penunjuk sudah ada di gambar. */
internal class ArtSelector(
    context: Context,
    private val s: Float,
    text: String,
    padL: Int,
    padT: Int,
    padR: Int,
    padB: Int,
) : FrameLayout(context) {

    private val label = TextView(context)

    init {
        foreground = Art.pressOverlay(16f * s)
        label.apply {
            this.text = text
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Art.TEXT)
            gravity = Gravity.CENTER
            maxLines = 2
            setAutoSizeTextTypeUniformWithConfiguration(
                (12f * s).roundToInt().coerceAtLeast(6),
                (27f * s).roundToInt().coerceAtLeast(8),
                1,
                TypedValue.COMPLEX_UNIT_PX
            )
        }
        addView(
            label,
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT).apply {
                leftMargin = (padL * s).roundToInt()
                topMargin = (padT * s).roundToInt()
                rightMargin = (padR * s).roundToInt()
                bottomMargin = (padB * s).roundToInt()
            }
        )
    }

    override fun setPressed(pressed: Boolean) {
        val changed = pressed != isPressed
        super.setPressed(pressed)
        if (changed) Art.pressScale(this, pressed)
    }

    override fun performClick(): Boolean {
        Art.tick(this)
        return super.performClick()
    }

    fun setLabel(text: String) {
        label.text = text
    }
}

/** Kotak kecil di grid kanan (di atas kotak kosong pada gambar): ikon di atas, nama di bawah. [active] = menyala. */
internal class ArtTile(
    context: Context,
    private val s: Float,
    iconRes: Int,
    text: String,
) : LinearLayout(context) {

    private val icon = ImageView(context)
    private val caption = TextView(context)

    var active: Boolean = false
        set(value) {
            field = value
            applyStyle()
        }

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        val pad = (4f * s).roundToInt()
        setPadding(pad, pad, pad, pad)
        icon.setImageResource(iconRes)
        addView(icon, LayoutParams((34f * s).roundToInt(), (34f * s).roundToInt()))
        caption.apply {
            this.text = text
            gravity = Gravity.CENTER
            maxLines = 1
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Art.TEXT)
            setAutoSizeTextTypeUniformWithConfiguration(
                (10f * s).roundToInt().coerceAtLeast(6),
                (16f * s).roundToInt().coerceAtLeast(8),
                1,
                TypedValue.COMPLEX_UNIT_PX
            )
        }
        addView(
            caption,
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (20f * s).roundToInt())
                .apply { topMargin = (3f * s).roundToInt() }
        )
        foreground = Art.pressOverlay(12f * s)
        applyStyle()
    }

    override fun setPressed(pressed: Boolean) {
        val changed = pressed != isPressed
        super.setPressed(pressed)
        if (changed) Art.pressScale(this, pressed)
    }

    override fun performClick(): Boolean {
        Art.tick(this)
        return super.performClick()
    }

    fun setLabel(text: String) {
        caption.text = text
    }

    private fun applyStyle() {
        icon.imageTintList = ColorStateList.valueOf(if (active) Color.WHITE else Art.MUTED)
        background = if (active) {
            GradientDrawable().apply {
                cornerRadius = 12f * s
                setColor(Art.ACTIVE_FILL)
                setStroke(maxOf(1, (2f * s).roundToInt()), Art.RING)
            }
        } else {
            null
        }
    }
}
