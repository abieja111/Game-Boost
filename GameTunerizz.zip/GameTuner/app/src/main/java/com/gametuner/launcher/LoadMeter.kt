package com.gametuner.launcher

/**
 * Beban CPU dan GPU untuk cincin di panel bubble. Dibaca dari sistem lewat shell (Shizuku/root);
 * bila HP tidak menyediakan datanya hasilnya null dan panel menampilkan "—", bukan angka karangan.
 * Semua fungsi blocking (panggil dari thread background); panel dan HUD memakainya bersamaan, jadi dikunci.
 */
object LoadMeter {

    private var prevTotal = 0L
    private var prevIdle = 0L

    /** Jalur sysfs beban GPU yang umum, dicoba berurutan. Parser menerima keluaran `cat` jalur itu. */
    private class GpuSource(val path: String, val parse: (String) -> Int?)

    private fun firstInt(s: String): Int? = Regex("\\d+").find(s)?.value?.toIntOrNull()

    private val GPU_SOURCES = listOf(
        // Qualcomm Adreno
        GpuSource("/sys/class/kgsl/kgsl-3d0/gpu_busy_percentage") { firstInt(it) },
        GpuSource("/sys/class/kgsl/kgsl-3d0/gpubusy") { s ->
            val n = Regex("\\d+").findAll(s).mapNotNull { it.value.toLongOrNull() }.toList()
            if (n.size >= 2 && n[1] > 0) (n[0] * 100 / n[1]).toInt() else null
        },
        // MediaTek (GED)
        GpuSource("/sys/kernel/ged/hal/gpu_utilization") { firstInt(it) },
        // Mali
        GpuSource("/sys/devices/platform/*mali*/utilization") { firstInt(it) },
        GpuSource("/sys/class/misc/mali0/device/utilisation") { firstInt(it) },
        GpuSource("/proc/mali/utilization") { firstInt(it) },
    )

    /** Indeks sumber GPU yang berhasil; -1 = belum dicari, -2 = tidak ada yang bisa dibaca. */
    private var gpuIndex = -1

    /** True bila sudah dicoba dan HP ini memang tidak membuka data beban GPU. */
    val gpuUnavailable: Boolean
        get() = gpuIndex == -2

    /** 0 = belum dicoba, 1 = terbaca, -1 = HP ini tidak membukanya. */
    private var cpuFreqState = 0

    /** Jalur sysfs frekuensi GPU yang umum, dicoba berurutan. Hasilnya bisa dalam Hz, kHz, atau MHz. */
    private val GPU_FREQ_PATHS = listOf(
        "/sys/class/kgsl/kgsl-3d0/gpuclk",
        "/sys/class/kgsl/kgsl-3d0/devfreq/cur_freq",
        "/sys/class/devfreq/*gpu*/cur_freq",
        "/sys/class/devfreq/*mali*/cur_freq",
        "/sys/devices/platform/*mali*/devfreq/*/cur_freq",
        "/sys/devices/platform/*mali*/cur_freq",
        "/sys/kernel/gpu/gpu_clock",
    )

    /** Indeks jalur frekuensi GPU yang berhasil; -1 = belum dicari, -2 = tidak ada yang bisa dibaca. */
    private var gpuFreqIndex = -1

    /** Ubah angka mentah (Hz, kHz, atau MHz) ke MHz dengan tebakan dari besarnya. */
    private fun toMhz(raw: Long): Int = when {
        raw >= 100_000_000L -> (raw / 1_000_000L).toInt()
        raw >= 10_000L -> (raw / 1_000L).toInt()
        else -> raw.toInt()
    }

    private fun parseFreq(out: String): Int? {
        val v = Regex("\\d+").findAll(out).mapNotNull { it.value.toLongOrNull() }.firstOrNull { it > 0L }
        return v?.let { toMhz(it) }?.takeIf { it > 0 }
    }

    /** Frekuensi tertinggi di antara semua inti CPU saat ini, dalam MHz, atau null bila tidak terbaca. */
    @Synchronized
    fun cpuFreqMhz(): Int? {
        if (cpuFreqState == -1) return null
        val r = ShellRunner.exec("cat /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq 2>/dev/null; true")
        val khz = Regex("\\d+").findAll(r.out).mapNotNull { it.value.toLongOrNull() }.maxOrNull()
        if (khz == null || khz <= 0L) {
            // Perintah jalan tapi tidak ada isinya: HP ini memang tidak membukanya.
            if (r.ok && cpuFreqState == 0) cpuFreqState = -1
            return null
        }
        cpuFreqState = 1
        return toMhz(khz)
    }

    /** Frekuensi GPU saat ini dalam MHz, atau null bila HP ini tidak membukanya. */
    @Synchronized
    fun gpuFreqMhz(): Int? {
        if (gpuFreqIndex == -2) return null
        if (gpuFreqIndex >= 0) {
            val r = ShellRunner.exec("cat ${GPU_FREQ_PATHS[gpuFreqIndex]} 2>/dev/null; true")
            return parseFreq(r.out)
        }
        var shellOk = false
        for ((i, path) in GPU_FREQ_PATHS.withIndex()) {
            val r = ShellRunner.exec("cat $path 2>/dev/null; true")
            if (r.ok) shellOk = true
            val mhz = parseFreq(r.out) ?: continue
            gpuFreqIndex = i
            return mhz
        }
        // Perintah jalan tapi tidak ada jalur yang terbaca: jangan dicoba lagi tiap 3 detik.
        if (shellOk) gpuFreqIndex = -2
        return null
    }

    private fun readCpuSample(): Pair<Long, Long>? {
        val r = ShellRunner.exec("head -n 1 /proc/stat")
        if (!r.ok) return null
        val parts = r.out.trim().split(Regex("\\s+"))
        if (parts.size < 8 || parts[0] != "cpu") return null
        val n = parts.drop(1).mapNotNull { it.toLongOrNull() }
        if (n.size < 7) return null
        val idle = n[3] + n[4]
        val total = n.take(8).sum()
        return total to idle
    }

    /** Beban CPU 0 sampai 100, atau null bila tidak terbaca. */
    @Synchronized
    fun cpuPercent(): Int? {
        if (prevTotal == 0L) {
            // Pembacaan pertama butuh pembanding: ambil dua contoh berjarak singkat.
            val first = readCpuSample() ?: return null
            prevTotal = first.first
            prevIdle = first.second
            Thread.sleep(400)
        }
        val now = readCpuSample() ?: return null
        val dTotal = now.first - prevTotal
        val dIdle = now.second - prevIdle
        prevTotal = now.first
        prevIdle = now.second
        if (dTotal <= 0) return null
        return ((dTotal - dIdle) * 100 / dTotal).toInt().coerceIn(0, 100)
    }

    /** Beban GPU 0 sampai 100, atau null bila HP ini tidak membuka datanya. */
    @Synchronized
    fun gpuPercent(): Int? {
        if (gpuIndex == -2) return null
        if (gpuIndex >= 0) {
            val src = GPU_SOURCES[gpuIndex]
            val r = ShellRunner.exec("cat ${src.path}")
            return if (r.ok) src.parse(r.out)?.coerceIn(0, 100) else null
        }
        for ((i, src) in GPU_SOURCES.withIndex()) {
            val r = ShellRunner.exec("cat ${src.path}")
            if (!r.ok) continue
            val v = src.parse(r.out) ?: continue
            gpuIndex = i
            return v.coerceIn(0, 100)
        }
        // Tidak ada sumber yang terbaca: jangan dicoba lagi tiap 3 detik.
        gpuIndex = -2
        return null
    }
}
