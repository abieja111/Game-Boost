package com.gametuner.launcher

import androidx.annotation.DrawableRes
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.sin

/*
 * Menu utama bergaya launcher game (landscape): daftar game di kiri, portal bercahaya di tengah,
 * judul game + tombol Start Game di kanan, tombol segi enam di pojok, dan tab Game Lobby / Super Base.
 * Semuanya Compose biasa tanpa gambar bitmap kecuali logo NX dan ikon aplikasi.
 */

private val Line = Color(0xFFB66DFF)
private val LineBright = Color(0xFFE9D5FF)
private val Magenta = Color(0xFFE879F9)
private val PanelTop = Color(0xF0200F56)
private val PanelBottom = Color(0xF00A0524)
private val ActiveTop = Color(0xFF6D28D9)
private val ActiveBottom = Color(0xFF3B0F8F)

/** Judul bergaya olahraga: tebal dan miring. */
private fun sportStyle(glow: Color? = null) = TextStyle(
    fontWeight = FontWeight.Black,
    fontStyle = FontStyle.Italic,
    shadow = glow?.let { Shadow(it, Offset.Zero, 18f) },
)

// ------------------------------------------------------------------ bentuk

/** Persegi panjang dengan sudut dipotong miring (pilih sudut mana saja). */
private class ChamferShape(
    private val cut: Dp,
    private val tl: Boolean = true,
    private val tr: Boolean = false,
    private val br: Boolean = true,
    private val bl: Boolean = false,
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val c = with(density) { cut.toPx() }.coerceAtMost(minOf(size.width, size.height) / 2f)
        val p = Path()
        p.moveTo(if (tl) c else 0f, 0f)
        p.lineTo(if (tr) size.width - c else size.width, 0f)
        if (tr) p.lineTo(size.width, c)
        p.lineTo(size.width, if (br) size.height - c else size.height)
        if (br) p.lineTo(size.width - c, size.height)
        p.lineTo(if (bl) c else 0f, size.height)
        if (bl) p.lineTo(0f, size.height - c)
        p.lineTo(0f, if (tl) c else 0f)
        p.close()
        return Outline.Generic(p)
    }
}

/** Segi enam dengan sudut kiri dan kanan runcing. */
private class HexShapeImpl : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val w = size.width
        val h = size.height
        val p = Path()
        p.moveTo(w * 0.26f, 0f)
        p.lineTo(w * 0.74f, 0f)
        p.lineTo(w, h / 2f)
        p.lineTo(w * 0.74f, h)
        p.lineTo(w * 0.26f, h)
        p.lineTo(0f, h / 2f)
        p.close()
        return Outline.Generic(p)
    }
}

private val HexOutline: Shape = HexShapeImpl()

/** Jajar genjang untuk tab bawah. */
private class SlantShape : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val s = size.height * 0.45f
        val p = Path()
        p.moveTo(s, 0f)
        p.lineTo(size.width, 0f)
        p.lineTo(size.width - s, size.height)
        p.lineTo(0f, size.height)
        p.close()
        return Outline.Generic(p)
    }
}

private val SlantOutline: Shape = SlantShape()

// ---------------------------------------------------------------- modifier

/** Cahaya neon di sekeliling bentuk: tiga goresan tebal bertransparansi (tanpa blur, murah digambar). */
private fun Modifier.neonGlow(shape: Shape, color: Color, spread: Dp = 8.dp, strength: Float = 1f): Modifier =
    drawBehind {
        val outline = shape.createOutline(size, layoutDirection, this)
        val path = (outline as? Outline.Generic)?.path ?: return@drawBehind
        val s = spread.toPx()
        for (i in 3 downTo 1) {
            drawPath(
                path = path,
                color = color.copy(alpha = (0.10f * strength).coerceIn(0f, 1f)),
                style = Stroke(width = s * i / 3f * 2f),
            )
        }
    }

/** Isi gradien gelap dan garis tepi neon, untuk panel dan tombol. */
private fun Modifier.neonSurface(shape: Shape, selected: Boolean = false): Modifier =
    this
        .background(
            Brush.verticalGradient(if (selected) listOf(ActiveTop, ActiveBottom) else listOf(PanelTop, PanelBottom)),
            shape,
        )
        .border(if (selected) 1.5.dp else 1.dp, if (selected) LineBright else Line, shape)

/** Baris daftar: lebih transparan dari panel supaya tidak terlalu berat. */
private fun Modifier.neonRow(shape: Shape, selected: Boolean): Modifier =
    if (selected) {
        neonSurface(shape, true)
    } else {
        this
            .background(Brush.verticalGradient(listOf(Color(0x66341A8A), Color(0x66180B40))), shape)
            .border(1.dp, Line.copy(alpha = 0.35f), shape)
    }

/** Keadaan tekan sebuah tombol: dipakai untuk efek mengecil dan getar singkat. */
private class Press(val source: MutableInteractionSource, val scale: State<Float>)

@Composable
private fun rememberPress(enabled: Boolean = true): Press {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale = animateFloatAsState(
        targetValue = if (pressed && enabled) 0.94f else 1f,
        animationSpec = tween(90),
        label = "press",
    )
    return Press(source, scale)
}

/** Taruh paling awal di rantai modifier supaya seluruh tombol (termasuk cahayanya) ikut mengecil. */
private fun Modifier.pressScale(p: Press): Modifier = graphicsLayer {
    scaleX = p.scale.value
    scaleY = p.scale.value
}

/** Klik dengan getar singkat; memakai keadaan tekan yang sama dengan [pressScale]. */
@Composable
private fun Modifier.pressClick(p: Press, enabled: Boolean = true, onClick: () -> Unit): Modifier {
    val haptic = LocalHapticFeedback.current
    return clickable(
        interactionSource = p.source,
        indication = LocalIndication.current,
        enabled = enabled,
        onClick = {
            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            onClick()
        },
    )
}

/** Seperti [neonGlow], tetapi kekuatannya dibaca saat menggambar sehingga bisa berdenyut tanpa recompose. */
private fun Modifier.neonGlowPulse(
    shape: Shape,
    color: Color,
    spread: Dp,
    strength: State<Float>,
    on: Boolean,
): Modifier = drawBehind {
    if (!on) return@drawBehind
    val outline = shape.createOutline(size, layoutDirection, this)
    val path = (outline as? Outline.Generic)?.path ?: return@drawBehind
    val s = spread.toPx()
    val a = (0.10f * strength.value).coerceIn(0f, 1f)
    for (i in 3 downTo 1) {
        drawPath(
            path = path,
            color = color.copy(alpha = a),
            style = Stroke(width = s * i / 3f * 2f),
        )
    }
}

/** Latar seluruh aplikasi: gradien ungu gelap, cahaya di tengah, dan garis neon miring. */
internal fun Modifier.appBackdrop(): Modifier = drawBehind {
    drawRect(Brush.verticalGradient(listOf(Color(0xFF160A40), Nx.Bg)))
    val c = Offset(size.width * 0.5f, size.height * 0.60f)
    val r = size.width * 0.55f
    drawCircle(
        brush = Brush.radialGradient(listOf(Color(0x556D28D9), Color.Transparent), center = c, radius = r),
        radius = r,
        center = c,
    )
    val streak = Color(0x226D3CF5)
    for (i in 0..4) {
        val x = size.width * (0.05f + 0.22f * i)
        drawLine(
            color = streak,
            start = Offset(x, size.height),
            end = Offset(x + size.height * 0.7f, 0f),
            strokeWidth = 3f + i * 3f,
        )
    }
}

// ----------------------------------------------------------------- tombol

/** Tombol segi enam dengan ikon di tengah. */
@Composable
private fun LobbyHex(
    @DrawableRes icon: Int,
    modifier: Modifier = Modifier,
    boxSize: Dp = 40.dp,
    tint: Color = Color.White,
    selected: Boolean = false,
    enabled: Boolean = true,
    rotation: Float = 0f,
    onClick: () -> Unit,
) {
    val press = rememberPress(enabled)
    Box(
        modifier
            .pressScale(press)
            .size(boxSize)
            .neonGlow(HexOutline, Line, 6.dp, if (selected) 1.4f else 0.7f)
            .clip(HexOutline)
            .neonSurface(HexOutline, selected)
            .pressClick(press, enabled, onClick),
        contentAlignment = Alignment.Center,
    ) {
        NxIcon(icon, modifier = Modifier.rotate(rotation), tint = tint, size = boxSize * 0.5f)
    }
}

/** Tab bawah ("Game Lobby" / "Super Base"). */
@Composable
private fun LobbyTab(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val press = rememberPress()
    Box(
        modifier
            .pressScale(press)
            .height(36.dp)
            .neonGlow(SlantOutline, Magenta, 8.dp, if (selected) 1.2f else 0f)
            .clip(SlantOutline)
            .neonSurface(SlantOutline, selected)
            .pressClick(press, true, onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text.uppercase(),
            color = if (selected) Color.White else Nx.Muted,
            fontSize = 12.sp,
            maxLines = 1,
            style = sportStyle(),
            modifier = Modifier.padding(horizontal = 22.dp),
        )
    }
}

/** Tombol utama "Start Game". */
@Composable
private fun StartButton(enabled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = ChamferShape(12.dp, tl = true, tr = false, br = true, bl = false)
    val press = rememberPress(enabled)
    // Cahaya berdenyut pelan supaya tombol utama paling menarik perhatian.
    val pulse = rememberInfiniteTransition(label = "start").animateFloat(
        initialValue = 1.0f,
        targetValue = 1.8f,
        animationSpec = infiniteRepeatable(tween(1300, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    Row(
        modifier
            .pressScale(press)
            .neonGlowPulse(shape, Magenta, 10.dp, pulse, enabled)
            .clip(shape)
            .background(
                Brush.horizontalGradient(
                    if (enabled) listOf(Color(0xFF7C3AED), Color(0xFFC026D3)) else listOf(Nx.Chip, Nx.Chip)
                ),
                shape,
            )
            .border(1.5.dp, if (enabled) LineBright else Nx.BorderSoft, shape)
            .pressClick(press, enabled, onClick)
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        NxIcon(R.drawable.ic_play, tint = if (enabled) Color.White else Nx.Muted, size = 20.dp)
        Spacer(Modifier.width(8.dp))
        Text(
            "START GAME",
            color = if (enabled) Color.White else Nx.Muted,
            fontSize = 16.sp,
            maxLines = 1,
            style = sportStyle(),
        )
    }
}

// ---------------------------------------------------------- portal tengah

private const val BASE_FRAC = 0.74f

private class Spark(val dx: Float, val phase: Float, val speed: Int, val radius: Float, val alpha: Float)

private val SparkSeeds: List<Spark> = run {
    val rnd = kotlin.random.Random(11)
    List(18) {
        Spark(
            dx = rnd.nextFloat() * 2f - 1f,
            phase = rnd.nextFloat(),
            speed = 1 + rnd.nextInt(2),
            radius = 1f + rnd.nextFloat() * 1.6f,
            alpha = 0.55f + rnd.nextFloat() * 0.45f,
        )
    }
}

/** Portal: sinar vertikal, cincin elips bercahaya di lantai, cincin putus-putus berputar, dan percikan naik. */
@Composable
private fun PortalBackdrop(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "portal")
    val spin = infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart),
        label = "spin",
    )
    Canvas(modifier) {
        val t = spin.value
        val w = size.width
        val h = size.height
        val cx = w * 0.5f
        val baseY = h * BASE_FRAC
        val rMax = minOf(w * 0.27f, h * 0.80f)
        val squash = 0.30f
        val top = h * 0.04f

        // Sinar yang naik dari portal.
        val beam = Path().apply {
            moveTo(cx - rMax * 0.20f, top)
            lineTo(cx + rMax * 0.20f, top)
            lineTo(cx + rMax * 0.62f, baseY)
            lineTo(cx - rMax * 0.62f, baseY)
            close()
        }
        drawPath(
            beam,
            Brush.verticalGradient(
                listOf(Color.Transparent, Magenta.copy(alpha = 0.10f), Line.copy(alpha = 0.34f)),
                startY = top,
                endY = baseY,
            ),
        )

        // Cahaya di lantai: lingkaran gradien yang dipipihkan jadi elips.
        val floor = Offset(cx, baseY)
        withTransform({ scale(1f, squash, pivot = floor) }) {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Line.copy(alpha = 0.55f), ActiveTop.copy(alpha = 0.22f), Color.Transparent),
                    center = floor,
                    radius = rMax * 1.08f,
                ),
                radius = rMax * 1.08f,
                center = floor,
            )
        }

        // Cincin elips: makin ke dalam makin terang.
        val ratios = floatArrayOf(1.00f, 0.80f, 0.60f, 0.40f)
        ratios.forEachIndexed { i, k ->
            val rx = rMax * k
            val ry = rx * squash
            val topLeft = Offset(cx - rx, baseY - ry)
            val sz = Size(rx * 2f, ry * 2f)
            val a = 0.95f - i * 0.15f
            drawOval(Line.copy(alpha = 0.16f * a), topLeft, sz, style = Stroke(width = 7.dp.toPx()))
            drawOval(
                LineBright.copy(alpha = a),
                topLeft,
                sz,
                style = Stroke(width = (if (i == 0) 1.6f else 1f).dp.toPx()),
            )
        }

        // Cincin putus-putus yang berputar (fase kelipatan bulat dari periode supaya putarannya mulus).
        val dash = 10.dp.toPx()
        val gap = 16.dp.toPx()
        val dRx = rMax * 0.90f
        val dRy = dRx * squash
        drawOval(
            Magenta.copy(alpha = 0.75f),
            Offset(cx - dRx, baseY - dRy),
            Size(dRx * 2f, dRy * 2f),
            style = Stroke(
                width = 2.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(dash, gap), -t * (dash + gap) * 6f),
            ),
        )

        // Percikan yang naik dari portal.
        SparkSeeds.forEach { s ->
            val p = (t * s.speed + s.phase) % 1f
            val x = cx + s.dx * rMax * 0.9f * (1f - 0.7f * p)
            val y = baseY - p * (baseY - top)
            val a = (sin(PI.toFloat() * p) * s.alpha).coerceIn(0f, 1f)
            drawCircle(LineBright.copy(alpha = a), radius = s.radius.dp.toPx(), center = Offset(x, y))
        }
    }
}

/** Ikon game yang melayang pelan di atas portal. */
@Composable
private fun FloatingIcon(app: GameApp, modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "bob")
    val bob = infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3200, easing = LinearEasing), RepeatMode.Restart),
        label = "bob",
    )
    val shape = RoundedCornerShape(20.dp)
    // Saat game lain dipilih, ikonnya muncul dengan efek membal.
    val pop = remember { Animatable(0f) }
    LaunchedEffect(app.pkg) {
        pop.snapTo(0f)
        pop.animateTo(1f, spring(dampingRatio = 0.5f, stiffness = 260f))
    }
    Box(
        modifier
            .size(76.dp)
            .graphicsLayer {
                translationY = sin(bob.value * 2f * PI.toFloat()) * 5.dp.toPx()
                val k = 0.55f + 0.45f * pop.value
                scaleX = k
                scaleY = k
                alpha = pop.value.coerceIn(0f, 1f)
            }
            .drawBehind {
                val r = size.minDimension * 0.95f
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Magenta.copy(alpha = 0.45f), Color.Transparent),
                        center = center,
                        radius = r,
                    ),
                    radius = r,
                    center = center,
                )
            }
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier
                .fillMaxSize()
                .clip(shape)
                .border(1.5.dp, LineBright, shape),
        )
    }
}

// ----------------------------------------------------------- daftar game

private fun profileText(scale: Int, fps: Int): String {
    val parts = buildList {
        if (scale < 100) add(DisplayController.scaleLabel(scale))
        if (fps > 0) add("${fps}Hz")
    }
    return if (parts.isEmpty()) "Asli" else parts.joinToString(" · ")
}

private fun formatSize(bytes: Long): String = when {
    bytes <= 0L -> "—"
    bytes >= 1_073_741_824L -> String.format(Locale.US, "%.1f GB", bytes / 1_073_741_824.0)
    else -> "${bytes / 1_048_576L} MB"
}

@Composable
private fun LobbyRow(app: GameApp, selected: Boolean, scale: Int, fps: Int, onClick: () -> Unit) {
    val shape = ChamferShape(8.dp, tl = true, tr = false, br = true, bl = false)
    val press = rememberPress()
    Row(
        Modifier
            .pressScale(press)
            .fillMaxWidth()
            .then(if (selected) Modifier.neonGlow(shape, Magenta, 7.dp) else Modifier)
            .clip(shape)
            .neonRow(shape, selected)
            .pressClick(press, true, onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = null,
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(10.dp)),
        )
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                app.label,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                NxIcon(R.drawable.ic_speed, tint = Nx.PurpleLight, size = 10.dp)
                Spacer(Modifier.width(3.dp))
                Text(
                    profileText(scale, fps),
                    color = Nx.PurpleLight,
                    fontSize = 10.sp,
                    maxLines = 1,
                    modifier = Modifier.weight(1f, fill = false),
                )
                Spacer(Modifier.weight(1f))
                Text(formatSize(app.sizeBytes), color = Nx.Muted, fontSize = 10.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun GameListPanel(
    ui: UiState,
    lobby: List<GameApp>,
    sel: GameApp?,
    modifier: Modifier = Modifier,
    onAdd: () -> Unit,
) {
    val shape = ChamferShape(14.dp, tl = true, tr = false, br = true, bl = false)
    Column(
        modifier
            .neonGlow(shape, Line, 8.dp, 0.6f)
            .clip(shape)
            .neonSurface(shape)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "GAME",
                color = Color.White,
                fontSize = 15.sp,
                style = sportStyle(Magenta.copy(alpha = 0.6f)),
            )
            Spacer(Modifier.width(6.dp))
            Text("${lobby.size}", color = Nx.Muted, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            LobbyHex(R.drawable.ic_plus, boxSize = 30.dp, onClick = onAdd)
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Brush.horizontalGradient(listOf(Color.Transparent, Line, Color.Transparent)))
        )
        if (lobby.isEmpty()) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(14.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (ui.apps.isEmpty()) "Memuat daftar aplikasi…" else "Belum ada game.\nKetuk + untuk menambah.",
                    color = Nx.Muted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(
                Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(lobby, key = { it.pkg }) { app ->
                    LobbyRow(
                        app = app,
                        selected = app.pkg == sel?.pkg,
                        scale = ui.scaleOf(app.pkg),
                        fps = ui.fpsOf(app.pkg),
                    ) { ui.selectLobby(app.pkg) }
                }
            }
        }
    }
}

// ---------------------------------------------------------- panel kanan

@Composable
private fun InfoColumn(
    app: GameApp?,
    ui: UiState,
    compact: Boolean,
    modifier: Modifier = Modifier,
    onStart: () -> Unit,
    onTune: () -> Unit,
) {
    Column(modifier) {
        if (app != null) {
            // Nama dan profil game menggeser masuk dari kanan tiap ganti pilihan.
            val enter = remember { Animatable(0f) }
            LaunchedEffect(app.pkg) {
                enter.snapTo(0f)
                enter.animateTo(1f, tween(340, easing = FastOutSlowInEasing))
            }
            Column(
                Modifier.graphicsLayer {
                    alpha = enter.value
                    translationX = (1f - enter.value) * 28.dp.toPx()
                }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NxIcon(R.drawable.ic_speed, tint = Nx.PurpleLight, size = 13.dp)
                    Spacer(Modifier.width(4.dp))
                    Text(
                        "Profil: ${profileText(ui.scaleOf(app.pkg), ui.fpsOf(app.pkg))}",
                        color = Nx.PurpleLight,
                        fontSize = 11.sp,
                        maxLines = 1,
                    )
                }
                val name = app.label.uppercase()
                val titleSize = when {
                    name.length > 22 -> if (compact) 15.sp else 18.sp
                    name.length > 13 -> if (compact) 19.sp else 24.sp
                    else -> if (compact) 24.sp else 30.sp
                }
                Text(
                    name,
                    color = Color.White,
                    fontSize = titleSize,
                    lineHeight = titleSize * 1.05f,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    style = sportStyle(Magenta.copy(alpha = 0.75f)),
                )
            }
        } else {
            Text(
                "PILIH GAME",
                color = Nx.Muted,
                fontSize = 22.sp,
                style = sportStyle(),
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            StartButton(
                enabled = app != null,
                modifier = Modifier
                    .weight(1f)
                    .height(44.dp),
                onClick = onStart,
            )
            Spacer(Modifier.width(8.dp))
            LobbyHex(R.drawable.ic_chevron_right, boxSize = 44.dp, enabled = app != null, onClick = onTune)
        }
    }
}

// --------------------------------------------------------------- panggung

@Composable
private fun LobbyStage(
    ui: UiState,
    lobby: List<GameApp>,
    sel: GameApp?,
    onStart: () -> Unit,
    onTune: () -> Unit,
    onAdd: () -> Unit,
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val compact = maxWidth < 700.dp
        val listW = if (compact) 190.dp else 230.dp
        val infoW = if (compact) 210.dp else 262.dp

        PortalBackdrop(Modifier.fillMaxSize())

        if (sel != null) {
            // Ikon berdiri di atas pusat portal (pusat portal ada di BASE_FRAC tinggi area ini).
            FloatingIcon(
                sel,
                Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = maxHeight * BASE_FRAC - 108.dp),
            )
        }

        GameListPanel(
            ui = ui,
            lobby = lobby,
            sel = sel,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .width(listW)
                .fillMaxHeight(),
            onAdd = onAdd,
        )

        InfoColumn(
            app = sel,
            ui = ui,
            compact = compact,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .width(infoW)
                .padding(bottom = 4.dp),
            onStart = onStart,
            onTune = onTune,
        )
    }
}

// ----------------------------------------------------------- bilah atas/bawah

@Composable
private fun rememberClock(): String {
    val context = LocalContext.current
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(15_000)
        }
    }
    return android.text.format.DateFormat.getTimeFormat(context).format(Date(now))
}

@Composable
private fun LobbyTopBar(ui: UiState, live: Live) {
    val clock = rememberClock()
    val pct = live.stats.batteryPct
    Row(
        Modifier
            .fillMaxWidth()
            .height(44.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painter = painterResource(R.drawable.logo_nx),
            contentDescription = "Nexus Game Boost",
            modifier = Modifier.size(34.dp),
        )
        Spacer(Modifier.width(10.dp))
        Text(clock, color = Color.White, fontSize = 17.sp, maxLines = 1, style = sportStyle())
        Spacer(Modifier.width(12.dp))
        NxIcon(R.drawable.ic_battery, tint = batteryColor(pct), size = 16.dp)
        Spacer(Modifier.width(3.dp))
        Text("$pct%", color = batteryColor(pct), fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        if (live.stats.charging) {
            Spacer(Modifier.width(3.dp))
            NxIcon(R.drawable.ic_bolt, tint = Nx.Green, size = 13.dp)
        }
        Spacer(Modifier.weight(1f))
        LobbyHex(R.drawable.ic_chart) { ui.tab = Tab.STATS }
        Spacer(Modifier.width(6.dp))
        LobbyHex(R.drawable.ic_settings) { ui.tab = Tab.SETTINGS }
        Spacer(Modifier.width(6.dp))
        LobbyHex(R.drawable.ic_info) { ui.tab = Tab.ABOUT }
    }
}

@Composable
private fun HintPill(text: String, ready: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val color = if (ready) Nx.Green else Nx.Amber
    val pill = RoundedCornerShape(50)
    // Titik kuning berkedip pelan supaya petunjuk yang belum beres terlihat; titik hijau diam.
    val blink = rememberInfiniteTransition(label = "hint").animateFloat(
        initialValue = 1f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "blink",
    )
    Row(
        modifier
            .height(30.dp)
            .clip(pill)
            .background(Color(0x66200F56), pill)
            .border(1.dp, color.copy(alpha = 0.6f), pill)
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .padding(start = 12.dp)
                .size(7.dp)
                .graphicsLayer { alpha = if (ready) 1f else blink.value }
                .background(color, CircleShape)
        )
        Text(
            text,
            color = Nx.Text,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
    }
}

@Composable
private fun LobbyBottomBar(ui: UiState, act: AppActions) {
    val st = ui.status
    val ready = st.hasAccess && ui.overlayGranted
    val hint = when {
        !st.hasAccess -> "Akses sistem belum aktif · ketuk untuk memperbaiki"
        !ui.overlayGranted -> "Izin overlay belum aktif · ketuk untuk membuka"
        else -> "Siap · ketuk ❯ di samping Start Game untuk atur resolusi & FPS"
    }
    Row(
        Modifier
            .fillMaxWidth()
            .height(50.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LobbyTab("Game Lobby", ui.tab == Tab.HOME) { ui.tab = Tab.HOME }
        Spacer(Modifier.width(2.dp))
        LobbyTab("Super Base", ui.tab == Tab.BASE) { ui.tab = Tab.BASE }
        Spacer(Modifier.width(12.dp))
        HintPill(hint, ready, Modifier.weight(1f)) {
            if (!ready) ui.tab = Tab.BASE
        }
        Spacer(Modifier.width(12.dp))
        LobbyHex(R.drawable.ic_grid) { ui.tab = Tab.GAMES }
        Spacer(Modifier.width(6.dp))
        LobbyHex(R.drawable.ic_monitor) { act.showHud() }
        Spacer(Modifier.width(6.dp))
        LobbyHex(
            R.drawable.ic_rocket,
            tint = if (ui.boosting) Nx.Muted else Color.White,
            enabled = !ui.boosting,
        ) { act.boost() }
    }
}

// ---------------------------------------------------------------- dialog

@Composable
private fun LobbyPicker(ui: UiState, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val shown = if (query.isBlank()) ui.apps else ui.apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    NxDialog(title = "Daftar Game", onDismiss = onDismiss) {
        Text("Ketuk aplikasi untuk menampilkan atau menyembunyikannya di Game Lobby.", fontSize = 12.sp)
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            label = { Text("Cari aplikasi") },
            modifier = Modifier.fillMaxWidth(),
        )
        if (ui.apps.isEmpty()) Text("Memuat daftar aplikasi…")
        if (ui.apps.isNotEmpty() && shown.isEmpty()) Text("Tidak ada aplikasi yang cocok.", fontSize = 12.sp)
        shown.forEach { app ->
            val on = ui.inLobby(app)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { ui.toggleLobby(app) }
                    .padding(vertical = 6.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Image(
                    bitmap = app.icon,
                    contentDescription = null,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(9.dp)),
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    app.label,
                    color = Nx.Text,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f),
                )
                NxIcon(
                    if (on) R.drawable.ic_check_circle else R.drawable.ic_plus,
                    tint = if (on) Nx.Green else Nx.Muted,
                    size = 22.dp,
                )
            }
        }
    }
}

// ----------------------------------------------------------------- kerangka

/** Kerangka launcher: bilah atas, panggung (Game Lobby) atau Super Base, dan bilah bawah. */
@Composable
fun LobbyFrame(ui: UiState, act: AppActions, rates: List<Int>) {
    val live = rememberLive()
    var picker by remember { mutableStateOf(false) }
    var tuning by remember { mutableStateOf<GameApp?>(null) }

    // Game yang paling baru dimainkan ada di atas; yang belum pernah dimainkan tetap berurutan seperti semula.
    val lobby = ui.apps.filter { ui.inLobby(it) }.sortedByDescending { ui.lastPlayed(it.pkg) }
    val sel = lobby.firstOrNull { it.pkg == ui.lobbyPkg } ?: lobby.firstOrNull()

    Column(
        Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        LobbyTopBar(ui, live)
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            // Pindah antara Game Lobby dan Super Base dengan memudar, bukan berganti mendadak.
            Crossfade(targetState = ui.tab == Tab.BASE, animationSpec = tween(220), label = "lobbyTab") { base ->
                if (base) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                        Column(
                            Modifier
                                .widthIn(max = 680.dp)
                                .fillMaxHeight()
                                .verticalScroll(rememberScrollState())
                                .padding(vertical = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            HomeScreen(ui, act)
                        }
                    }
                } else {
                    LobbyStage(
                        ui = ui,
                        lobby = lobby,
                        sel = sel,
                        onStart = {
                            sel?.let {
                                ui.selectLobby(it.pkg)
                                act.launchGame(it, ui.scaleOf(it.pkg), ui.fpsOf(it.pkg))
                            }
                        },
                        onTune = { tuning = sel },
                        onAdd = { picker = true },
                    )
                }
            }
        }
        LobbyBottomBar(ui, act)
    }

    if (picker) LobbyPicker(ui) { picker = false }

    tuning?.let { app ->
        ScaleDialog(
            app = app,
            ui = ui,
            rates = rates,
            onDismiss = { tuning = null },
            onLaunch = { percent, fps ->
                tuning = null
                act.launchGame(app, percent, fps)
            },
        )
    }
}

/** Halaman penuh (Statistik, Pengaturan, Tentang, Semua Aplikasi) dengan tombol kembali. */
@Composable
fun SubPage(title: String, onBack: () -> Unit, content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(44.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            LobbyHex(R.drawable.ic_chevron_right, rotation = 180f, onClick = onBack)
            Spacer(Modifier.width(12.dp))
            Text(
                title.uppercase(),
                color = Color.White,
                fontSize = 20.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = sportStyle(Magenta.copy(alpha = 0.6f)),
            )
        }
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(Brush.horizontalGradient(listOf(Line, Color.Transparent)))
        )
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.TopCenter,
        ) {
            Box(
                Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxHeight()
            ) { content() }
        }
    }
}
