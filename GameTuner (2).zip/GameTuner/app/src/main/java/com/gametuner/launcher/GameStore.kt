package com.gametuner.launcher

import android.content.Context

/** Penyimpanan sederhana: profil per game + pengaturan global. */
class GameStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("gametuner", Context.MODE_PRIVATE)

    fun getScale(pkg: String): Int = prefs.getInt("scale_$pkg", 100)

    fun setScale(pkg: String, percent: Int) {
        prefs.edit().putInt("scale_$pkg", percent).apply()
    }

    /** Batas refresh rate (Hz) per game. 0 = otomatis / tidak dibatasi. */
    fun getFps(pkg: String): Int = prefs.getInt("fps_$pkg", 0)

    fun setFps(pkg: String, hz: Int) {
        prefs.edit().putInt("fps_$pkg", hz).apply()
    }

    /** Ikut skala density supaya ukuran UI/teks tetap normal saat resolusi diturunkan. */
    var scaleDensity: Boolean
        get() = prefs.getBoolean("scale_density", true)
        set(value) { prefs.edit().putBoolean("scale_density", value).apply() }

    /** Game yang terakhir diluncurkan; perubahan dari overlay disimpan ke game ini. */
    var currentGame: String?
        get() = prefs.getString("current_game", null)
        set(value) { prefs.edit().putString("current_game", value).apply() }

    /** Kembalikan layar otomatis setelah game ditinggalkan beberapa detik. Default: aktif. */
    var autoReset: Boolean
        get() = prefs.getBoolean("auto_reset", true)
        set(value) { prefs.edit().putBoolean("auto_reset", value).apply() }

    /**
     * Nilai asli pengaturan refresh rate sistem sebelum kita ubah, format "min|peak".
     * Dipakai untuk memulihkan pengaturan pengguna saat reset. Null = belum kita ubah.
     */
    var savedRefresh: String?
        get() = prefs.getString("saved_refresh", null)
        set(value) { prefs.edit().putString("saved_refresh", value).apply() }
}
