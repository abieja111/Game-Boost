@file:OptIn(ExperimentalMaterial3Api::class)

package com.gametuner.launcher

import android.Manifest
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

data class GameApp(
    val pkg: String,
    val label: String,
    val icon: ImageBitmap,
    val isGame: Boolean,
)

data class SysStatus(
    val mode: ShellRunner.Mode = ShellRunner.Mode.NONE,
    val shizukuRunning: Boolean = false,
    val info: DisplayInfo? = null,
    /** Refresh rate yang sedang dikunci (Hz); 0 = otomatis. */
    val pinnedHz: Int = 0,
)

class MainActivity : ComponentActivity() {

    private lateinit var store: GameStore

    private var apps by mutableStateOf<List<GameApp>>(emptyList())
    private var status by mutableStateOf(SysStatus())
    private var overlayGranted by mutableStateOf(false)
    private var scaleDensity by mutableStateOf(true)
    private var boosting by mutableStateOf(false)
    private var autoReset by mutableStateOf(true)
    private val scales = mutableStateMapOf<String, Int>()
    private val fpsByGame = mutableStateMapOf<String, Int>()

    private val supportedRates by lazy { DisplayController.supportedRates(this) }

    private val binderListener = Shizuku.OnBinderReceivedListener { refreshStatus() }
    private val deadListener = Shizuku.OnBinderDeadListener { refreshStatus() }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refreshStatus() }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        store = GameStore(this)
        scaleDensity = store.scaleDensity
        autoReset = store.autoReset

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        loadApps()
        setContent { GameTunerTheme { Screen() } }
    }

    override fun onResume() {
        super.onResume()
        overlayGranted = Settings.canDrawOverlays(this)
        // overlay bisa mengubah profil saat game jalan
        scales.clear()
        fpsByGame.clear()
        refreshStatus()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- data

    private fun loadApps() {
        lifecycleScope.launch { apps = withContext(Dispatchers.IO) { queryApps() } }
    }

    @Suppress("DEPRECATION")
    private fun queryApps(): List<GameApp> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .mapNotNull { ri ->
                val ai = ri.activityInfo.applicationInfo
                if (ai.packageName == packageName) return@mapNotNull null
                val isGame = ai.category == ApplicationInfo.CATEGORY_GAME ||
                    (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                GameApp(
                    pkg = ai.packageName,
                    label = ri.loadLabel(pm).toString(),
                    icon = ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap(),
                    isGame = isGame,
                )
            }
            .distinctBy { it.pkg }
            .sortedWith(compareByDescending<GameApp> { it.isGame }.thenBy { it.label.lowercase() })
    }

    private fun refreshStatus(forceRoot: Boolean = false) {
        lifecycleScope.launch {
            val s = withContext(Dispatchers.IO) {
                val mode = ShellRunner.detect(forceRoot)
                val hasAccess = mode != ShellRunner.Mode.NONE
                SysStatus(
                    mode = mode,
                    shizukuRunning = ShellRunner.shizukuRunning(),
                    info = if (hasAccess) DisplayController.read() else null,
                    pinnedHz = if (hasAccess) DisplayController.readRefreshRate() else 0,
                )
            }
            status = s
        }
    }

    // ------------------------------------------------------------- actions

    private fun launchGame(app: GameApp, percent: Int, fps: Int) {
        val launchIntent = packageManager.getLaunchIntentForPackage(app.pkg)
        if (launchIntent == null) {
            toast("Tidak bisa membuka ${app.label}")
            return
        }
        store.setScale(app.pkg, percent)
        store.setFps(app.pkg, fps)
        store.currentGame = app.pkg
        scales[app.pkg] = percent
        fpsByGame[app.pkg] = fps

        lifecycleScope.launch {
            // Pengaturan diterapkan SEBELUM game dibuka, karena game membaca resolusi saat start.
            val res = withContext(Dispatchers.IO) {
                DisplayController.applyProfile(percent, fps, store.scaleDensity, store)
            }
            if (!res.ok && (percent < 100 || fps > 0)) {
                toast("Sebagian pengaturan gagal: ${res.err.ifBlank { res.out }}")
            }

            if (Settings.canDrawOverlays(this@MainActivity)) {
                ContextCompat.startForegroundService(
                    this@MainActivity,
                    Intent(this@MainActivity, OverlayService::class.java)
                )
            } else {
                toast("Izin pop-up overlay belum aktif, bubble tidak akan muncul.")
            }

            startActivity(launchIntent)
            refreshStatus()
        }
    }

    private fun resetDisplay() {
        lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) { DisplayController.resetAll(store) }
            if (!res.ok) toast("Gagal reset: ${res.err.ifBlank { res.out }}")
            refreshStatus()
        }
    }

    private fun boost() {
        boosting = true
        lifecycleScope.launch {
            val out = withContext(Dispatchers.IO) { Boost.run(this@MainActivity) }
            boosting = false
            toast(Boost.message(out))
        }
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private fun describeDisplay(i: DisplayInfo, hz: Int): String {
        val size = if (i.isOverridden) {
            "${i.physW}×${i.physH} → ${i.curW}×${i.curH} (${i.currentPercent}%)"
        } else {
            "${i.physW}×${i.physH} (asli)"
        }
        return if (hz > 0) "$size · $hz Hz" else size
    }

    // ------------------------------------------------------------------ UI

    @Composable
    private fun Screen() {
        var selected by remember { mutableStateOf<GameApp?>(null) }
        var showAll by remember { mutableStateOf(false) }

        val games = apps.filter { it.isGame }
        val shown = if (showAll || games.isEmpty()) apps else games

        Box(
            Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .systemBarsPadding()
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item {
                    Column(Modifier.padding(bottom = 6.dp)) {
                        Text("Game Tuner", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "Atur resolusi dan FPS game, kontrol langsung lewat bubble pop-up.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
                item { StatusCard() }
                item { StatsCard() }
                item {
                    Row(
                        Modifier.padding(horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            if (games.isEmpty()) "Semua aplikasi" else "Game",
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f),
                        )
                        if (games.isNotEmpty()) {
                            Text("Tampilkan semua", style = MaterialTheme.typography.labelMedium)
                            Spacer(Modifier.width(8.dp))
                            Switch(checked = showAll, onCheckedChange = { showAll = it })
                        }
                    }
                }
                items(shown, key = { it.pkg }) { app ->
                    GameRow(
                        app = app,
                        scale = scales[app.pkg] ?: store.getScale(app.pkg),
                        fps = fpsByGame[app.pkg] ?: store.getFps(app.pkg),
                    ) { selected = app }
                }
            }
        }

        selected?.let { app ->
            ScaleDialog(
                app = app,
                initialScale = scales[app.pkg] ?: store.getScale(app.pkg),
                initialFps = fpsByGame[app.pkg] ?: store.getFps(app.pkg),
                info = status.info,
                rates = supportedRates,
                onDismiss = { selected = null },
                onLaunch = { percent, fps ->
                    selected = null
                    launchGame(app, percent, fps)
                },
            )
        }
    }

    @Composable
    private fun StatusCard() {
        val st = status
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                when {
                    st.mode == ShellRunner.Mode.SHIZUKU ->
                        StatusRow("Akses sistem", "Shizuku aktif", true, null)
                    st.mode == ShellRunner.Mode.ROOT ->
                        StatusRow("Akses sistem", "Root aktif", true, null)
                    st.shizukuRunning ->
                        StatusRow("Akses sistem", "Shizuku jalan, belum diberi izin", false, "Izinkan") {
                            ShellRunner.requestShizuku()
                        }
                    else ->
                        StatusRow(
                            "Akses sistem",
                            "Belum ada. Jalankan Shizuku (atau pakai root).",
                            false,
                            "Cek ulang",
                        ) { refreshStatus(forceRoot = true) }
                }

                StatusRow(
                    "Pop-up overlay",
                    if (overlayGranted) "Diizinkan" else "Belum diizinkan",
                    overlayGranted,
                    if (overlayGranted) null else "Izinkan",
                ) { openOverlaySettings() }

                val info = st.info
                StatusRow(
                    "Layar",
                    if (info != null) describeDisplay(info, st.pinnedHz) else "Butuh akses sistem",
                    info != null,
                    if (info?.isOverridden == true || st.pinnedHz > 0) "Reset" else null,
                ) { resetDisplay() }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Sesuaikan density", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Ukuran UI dan teks tetap normal saat resolusi turun",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = scaleDensity,
                        onCheckedChange = {
                            scaleDensity = it
                            store.scaleDensity = it
                        },
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "Reset otomatis saat game ditutup",
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Text(
                            "Layar dikembalikan ±12 detik setelah kamu keluar dari game",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = autoReset,
                        onCheckedChange = {
                            autoReset = it
                            store.autoReset = it
                        },
                    )
                }
            }
        }
    }

    /** Suhu, baterai, RAM bebas (diperbarui tiap 3 detik) dan tombol Boost. */
    @Composable
    private fun StatsCard() {
        var stats by remember { mutableStateOf(SystemStats.read(this@MainActivity)) }
        LaunchedEffect(Unit) {
            while (true) {
                stats = SystemStats.read(this@MainActivity)
                delay(3000)
            }
        }
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
        ) {
            Row(
                Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                StatItem("Suhu", "%.1f°C".format(stats.tempC), Modifier.weight(1f))
                StatItem(
                    "Baterai",
                    "${stats.batteryPct}%" + if (stats.charging) " ⚡" else "",
                    Modifier.weight(1f),
                )
                StatItem("RAM bebas", "%.1f GB".format(stats.ramFreeMb / 1024f), Modifier.weight(1f))
                Button(
                    onClick = { boost() },
                    enabled = !boosting && status.mode != ShellRunner.Mode.NONE,
                ) { Text(if (boosting) "…" else "Boost") }
            }
        }
    }

    @Composable
    private fun StatItem(label: String, value: String, modifier: Modifier) {
        Column(modifier) {
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(value, style = MaterialTheme.typography.titleSmall, maxLines = 1)
        }
    }

    @Composable
    private fun StatusRow(
        title: String,
        value: String,
        ok: Boolean,
        actionLabel: String?,
        onAction: () -> Unit = {},
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(if (ok) Color(0xFF5AD19A) else Color(0xFFFFB454))
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(value, style = MaterialTheme.typography.bodyMedium)
            }
            if (actionLabel != null) {
                TextButton(onClick = onAction) { Text(actionLabel) }
            }
        }
    }

    @Composable
    private fun GameRow(app: GameApp, scale: Int, fps: Int, onClick: () -> Unit) {
        val parts = buildList {
            if (scale < 100) add("Resolusi $scale%")
            if (fps > 0) add("$fps Hz")
        }
        Card(
            onClick = onClick,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
        ) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Image(
                    bitmap = app.icon,
                    contentDescription = null,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp)),
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        app.label,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = FontWeight.Medium,
                    )
                    Text(
                        if (parts.isEmpty()) "Pengaturan asli" else parts.joinToString(" · "),
                        style = MaterialTheme.typography.labelMedium,
                        color = if (parts.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant
                        else MaterialTheme.colorScheme.primary,
                    )
                }
            }
        }
    }

    @Composable
    private fun ScaleDialog(
        app: GameApp,
        initialScale: Int,
        initialFps: Int,
        info: DisplayInfo?,
        rates: List<Int>,
        onDismiss: () -> Unit,
        onLaunch: (Int, Int) -> Unit,
    ) {
        var scalePick by remember { mutableIntStateOf(initialScale) }
        var fpsPick by remember { mutableIntStateOf(if (initialFps in rates) initialFps else 0) }

        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(
                    Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Text(
                        "Resolusi render",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    DisplayController.PRESETS.chunked(3).forEach { rowItems ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            rowItems.forEach { p ->
                                FilterChip(
                                    selected = scalePick == p,
                                    onClick = { scalePick = p },
                                    label = { Text(if (p == 100) "Asli" else "$p%") },
                                )
                            }
                        }
                    }
                    val t = info?.let { DisplayController.target(it, scalePick, scaleDensity) }
                    Text(
                        if (t != null) "Hasil: ${t.w}×${t.h} @${t.dpi}dpi"
                        else "Pratinjau butuh akses sistem",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )

                    if (rates.size > 1) {
                        Text(
                            "Batas refresh rate (membatasi FPS)",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        (listOf(0) + rates).chunked(3).forEach { rowItems ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                rowItems.forEach { hz ->
                                    FilterChip(
                                        selected = fpsPick == hz,
                                        onClick = { fpsPick = hz },
                                        label = { Text(if (hz == 0) "Auto" else "$hz Hz") },
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { onLaunch(scalePick, fpsPick) }) { Text("Luncurkan") }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        )
    }
}
