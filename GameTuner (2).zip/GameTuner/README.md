# Game Tuner

Launcher game untuk Android: **downscale resolusi**, **batas FPS**, **boost RAM**, dan **monitor perangkat**, semuanya bisa diatur langsung dari bubble pop-up saat game berjalan.

## Fitur

**Launcher**
- Daftar game yang terpasang (otomatis dikenali; ada saklar "Tampilkan semua" untuk aplikasi lain)
- Profil per game: skala resolusi (Asli, 85%, 75%, 60%, 50%) dan batas refresh rate
- Tombol **Luncurkan**: pengaturan diterapkan dulu, baru game dibuka
- Kartu monitor: suhu baterai, level baterai, RAM bebas, plus tombol **Boost**

**Bubble pop-up (⚡)** di atas game. Ketuk untuk membuka panel, geser untuk memindahkan.
- Ganti skala resolusi kapan saja
- Ganti batas refresh rate (hanya pilihan yang didukung layar HP-mu)
- **Boost**: bersihkan RAM dari proses latar
- Suhu, baterai, dan RAM bebas, diperbarui tiap 3 detik selama panel terbuka
- **Reset** mengembalikan resolusi dan refresh rate; **Selesai** reset sekaligus menutup bubble
- Pilihan terakhir di bubble tersimpan sebagai profil game tersebut
- **Reset otomatis:** setelah kamu keluar dari game sekitar 12 detik, layar dikembalikan dan bubble ditutup (bisa dimatikan lewat saklar di kartu status)

## Cara kerja dan batasannya

Pengaturan sistem diubah lewat perintah shell (`wm size`, `wm density`, `settings put system ...`, `am kill-all`). Perintah ini hanya bisa dijalankan akses **shell** atau **root**, bukan aplikasi biasa. Jadi aplikasi ini memakai **Shizuku** (tanpa root, disarankan) atau **root**.

- **Resolusi:** `wm size` menurunkan resolusi **seluruh layar**, bukan hanya game. Tekan **Selesai** atau **Reset** setelah main.
- **Atur FPS:** yang dibatasi adalah **refresh rate layar** (misalnya 60 atau 90 Hz). Game yang mengikuti layar ikut terbatas. Game yang punya pilihan FPS sendiri di dalam game tetap perlu diatur di sana. Beberapa merek HP memakai pengaturan refresh rate sendiri, jadi di sebagian HP pengaturan ini mungkin tidak berpengaruh.
- **Refresh rate asli dipulihkan:** nilai pengaturan sebelum diubah disimpan, lalu dikembalikan persis saat Reset atau Selesai.
- **Boost:** menjalankan `am kill-all`, yang mematikan proses latar yang aman dimatikan. Android sering memulai ulang sebagian aplikasi itu, jadi efeknya bisa sementara dan kadang kecil. Aplikasi menampilkan selisih RAM bebas sesudahnya.
- **Reset otomatis:** aplikasi memeriksa aplikasi yang sedang di depan tiap 4 detik (lewat `dumpsys`). Kalau kamu keluar dari game lebih dari ±12 detik, layar dikembalikan dan bubble ditutup. Membuka Game Tuner sendiri tidak dihitung keluar dari game. Membuka aplikasi lain lebih dari 12 detik (misalnya login lewat browser) juga dianggap keluar. Kalau aplikasi tidak bisa memastikan mana yang di depan (format `dumpsys` berbeda antar HP), tidak ada yang direset otomatis, jadi tetap tekan **Selesai** untuk jaga-jaga. Pemeriksaan berkala ini memakai sedikit baterai; matikan lewat saklar di kartu status bila tidak perlu.
- Layar akan berkedip sebentar saat resolusi berubah. Ini normal.
- Sebagian game membaca resolusi hanya saat dibuka, jadi perubahan dari bubble mungkin baru terasa setelah game dibuka ulang.

## Cara mendapatkan APK

**Opsi A: GitHub Actions (tanpa Android Studio)**
1. Buat repo baru di GitHub, lalu unggah seluruh isi folder ini.
2. Buka tab **Actions**, pilih **Build APK**, klik **Run workflow**.
3. Setelah selesai, unduh artifact `GameTuner-debug-apk`, ekstrak, lalu pasang `app-debug.apk`.

**Opsi B: Android Studio**
1. File → Open → pilih folder ini.
2. Tunggu Gradle sync, lalu Build → Build APK(s).

## Cara pakai pertama kali

1. Pasang **Shizuku** dari Play Store / GitHub, lalu jalankan lewat *Wireless debugging* (ikuti petunjuk di aplikasi Shizuku). Perlu diulang setelah HP restart.
2. Buka Game Tuner. Di kartu status, tekan **Izinkan** pada "Akses sistem" dan setujui permintaan Shizuku.
3. Tekan **Izinkan** pada "Pop-up overlay" dan aktifkan izin tampil di atas aplikasi lain.
4. Pilih game, pilih skala resolusi dan batas refresh rate, tekan **Luncurkan**.

## Kalau layar tersangkut

Dari Game Tuner tekan **Reset**. Kalau aplikasi tidak bisa dibuka, jalankan dari PC lewat ADB:

```
adb shell wm size reset
adb shell wm density reset
adb shell settings delete system min_refresh_rate
adb shell settings delete system peak_refresh_rate
```

Dua perintah terakhir menghapus pengaturan refresh rate. Kalau sebelumnya kamu pernah mengatur refresh rate sendiri di Pengaturan HP, atur ulang di sana.

## Status

Proyek ini belum pernah dikompilasi atau diuji di perangkat. Kalau build pertama menampilkan error, kirim pesan errornya agar bisa diperbaiki.

## Ide berikutnya

- Batas FPS per game yang lebih akurat lewat Game Mode bawaan Android (Android 12 ke atas)
