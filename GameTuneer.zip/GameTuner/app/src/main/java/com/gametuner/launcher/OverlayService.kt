package com.gametuner.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.concurrent.Executors
import kotlin.math.abs

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** ScrollView yang tingginya dibatasi, supaya panel tidak lebih tinggi dari layar. */
private class MaxHeightScrollView(context: Context) : ScrollView(context) {
    var maxHeightPx: Int = 100_000
        set(value) {
            field = value
            requestLayout()
        }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val capped = View.MeasureSpec.makeMeasureSpec(maxHeightPx, View.MeasureSpec.AT_MOST)
        super.onMeasure(widthMeasureSpec, capped)
    }
}

/** Saklar berbentuk pil, digambar dengan View biasa supaya tampilannya sama di semua HP. */
private class PillSwitch(context: Context, scale: Float = 1f) : FrameLayout(context) {
    private val d = context.resources.displayMetrics.density * scale
    private val thumb = View(context)

    var checked: Boolean = false
        set(value) {
            field = value
            render()
        }

    init {
        addView(
            thumb,
            FrameLayout.LayoutParams((18 * d).toInt(), (18 * d).toInt(), Gravity.CENTER_VERTICAL)
        )
        render()
    }

    private fun render() {
        background = GradientDrawable().apply {
            cornerRadius = 12 * d
            setColor(if (checked) 0xFF6D3CF5.toInt() else 0xFF2A2540.toInt())
        }
        thumb.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (checked) Color.WHITE else 0xFFC9C3DD.toInt())
        }
        val lp = thumb.layoutParams as FrameLayout.LayoutParams
        lp.marginStart = ((if (checked) 21 else 3) * d).toInt()
        thumb.layoutParams = lp
    }
}

/** Kartu saklar di panel: [view] untuk ditambahkan ke layar, [sw] saklarnya, [sub] keterangan kecilnya. */
private class ToggleCard(val view: LinearLayout, val sw: PillSwitch, val sub: TextView)

/**
 * Cincin persen untuk beban GPU dan CPU (atau RAM): busur gradasi ungu dengan glow, angka besar di
 * tengah, nama di bawahnya. [percent] null berarti HP tidak menyediakan datanya, jadi yang tampil
 * adalah "—", bukan angka karangan. [scale] ikut skala panel.
 */
private class RingView(context: Context, scale: Float) : View(context) {
    private val d = context.resources.displayMetrics.density * scale
    private val box = RectF()
    private val stroke = 11 * d
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = stroke
        color = 0xFF2A1F55.toInt()
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = stroke
        strokeCap = Paint.Cap.ROUND
    }
    private val inner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF0F0826.toInt()
    }
    private val numText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.LEFT
        textSize = 27 * d
        typeface = Typeface.DEFAULT_BOLD
    }
    private val pctText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFE9E3FF.toInt()
        textAlign = Paint.Align.LEFT
        textSize = 14 * d
        typeface = Typeface.DEFAULT_BOLD
    }
    private val captionText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFD8D0F5.toInt()
        textAlign = Paint.Align.CENTER
        textSize = 13 * d
        typeface = Typeface.DEFAULT_BOLD
    }
    private var gradient: Shader? = null

    init {
        // Glow (setShadowLayer) pada garis hanya tergambar di software layer; view-nya kecil jadi ringan.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    var label: String = ""
        set(value) {
            field = value
            invalidate()
        }

    var percent: Int? = null
        set(value) {
            field = value
            invalidate()
        }

    /** Batas persen mulai kuning dan mulai merah. RAM memakai batas lebih tinggi karena wajar terisi banyak. */
    var warnFrom: Int = 70
    var alertFrom: Int = 90

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        gradient = SweepGradient(
            cx, cy,
            intArrayOf(0xFF7C3AED.toInt(), 0xFFE879F9.toInt(), 0xFF7C3AED.toInt()),
            floatArrayOf(0f, 0.75f, 1f)
        ).also { g ->
            // Busur mulai dari arah jam 7:30 (135 derajat), jadi gradasinya ikut diputar.
            g.setLocalMatrix(Matrix().apply { postRotate(135f, cx, cy) })
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val pad = stroke / 2f + 5 * d
        box.set(pad, pad, width - pad, height - pad)
        val cx = width / 2f
        val cy = height / 2f

        canvas.drawCircle(cx, cy, box.width() / 2f - stroke / 2f - 2 * d, inner)
        canvas.drawArc(box, 135f, 270f, false, track)

        val p = percent
        if (p != null && p > 0) {
            val glow: Int
            when {
                p >= alertFrom -> {
                    arc.shader = null
                    arc.color = 0xFFFF6B5A.toInt()
                    glow = 0xFFFF6B5A.toInt()
                }
                p >= warnFrom -> {
                    arc.shader = null
                    arc.color = 0xFFFFA94D.toInt()
                    glow = 0xFFFFA94D.toInt()
                }
                else -> {
                    arc.shader = gradient
                    glow = 0xFF8B5CF6.toInt()
                }
            }
            arc.setShadowLayer(7 * d, 0f, 0f, glow)
            canvas.drawArc(box, 135f, 270f * p / 100f, false, arc)
        }

        val num = if (p != null) "$p" else "—"
        val numW = numText.measureText(num)
        val pctW = if (p != null) pctText.measureText("%") else 0f
        val startX = cx - (numW + pctW) / 2f
        val base = cy - (numText.ascent() + numText.descent()) / 2f - 8 * d
        canvas.drawText(num, startX, base, numText)
        if (p != null) canvas.drawText("%", startX + numW + d, base, pctText)

        val captionBase = cy - (captionText.ascent() + captionText.descent()) / 2f + 19 * d
        canvas.drawText(label, cx, captionBase, captionText)
    }
}

/**
 * Bubble melayang di atas game. Ketuk untuk membuka panel Nexus: cincin GPU/CPU, FPS, suhu, baterai,
 * skala resolusi, batas FPS, Mode Main, Mode Fokus, Hemat Baterai, Peringatan Panas, Crosshair, Macro, dan Boost.
 * Dibuat dengan View biasa (bukan Compose) supaya tidak butuh lifecycle owner di Service.
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_RESET = "com.gametuner.launcher.RESET"
        const val ACTION_FINISH = "com.gametuner.launcher.FINISH"
        const val ACTION_MACRO = "com.gametuner.launcher.MACRO"
        const val ACTION_CROSSHAIR = "com.gametuner.launcher.CROSSHAIR"
        const val ACTION_HUD = "com.gametuner.launcher.HUD"
        const val ACTION_OPEN = "com.gametuner.launcher.OPEN"
        private const val CHANNEL_ID = "overlay"
        private const val NOTIF_ID = 1
        private const val COLUMNS = 4

        // Pemantau game: cek tiap POLL_MS; reset bila game ditinggalkan terus-menerus selama GRACE_MS.
        private const val POLL_MS = 4000L
        private const val GRACE_MS = 12_000L
        private const val ARM_TIMEOUT_MS = 60_000L

        // Suhu, Auto FPS, dan Boost otomatis dicek tiap HEAT_POLL_MS.
        private const val HEAT_POLL_MS = 10_000L
        private const val DEFAULT_HOT_C = 44
        private const val AUTO_BOOST_COOLDOWN_MS = 90_000L
        private const val STATS_MS = 3000L

        private val COLOR_PANEL = 0xF20D0722.toInt()
        private val COLOR_PANEL_TOP = 0xF21A1040.toInt()
        private val COLOR_FRAME = 0xFF8B5CF6.toInt()
        private val COLOR_BORDER = 0xFF3A1FA0.toInt()
        private val COLOR_DIVIDER = 0xFF241848.toInt()
        private val COLOR_CHIP = 0xFF2B2452.toInt()
        private val COLOR_CHIP_ACTIVE = 0xFF2A1A66.toInt()
        private val COLOR_TILE = 0xFF150F2C.toInt()
        private val COLOR_CARD_BORDER = 0xFF4A32B8.toInt()

        /** Pilihan batas suhu (°C) untuk Peringatan Panas. */
        private val HEAT_CHOICES = listOf(40, 42, 44, 46)
        private val COLOR_ACCENT = 0xFFA78BFA.toInt()
        private val COLOR_MUTED = 0xFFA79FC4.toInt()
        private val COLOR_GREEN = 0xFF34D399.toInt()
        private val COLOR_AMBER = 0xFFFFA94D.toInt()
        private val COLOR_ALERT = 0xFFFF6B5A.toInt()
        private val COLOR_PILL_BG = 0xFF0F3D2C.toInt()
        private val COLOR_PILL_EDGE = 0xCCB66DFF.toInt()
    }

    private lateinit var wm: WindowManager
    private lateinit var store: GameStore
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var bubbleView: ImageView? = null

    // Geser dari tepi layar: jendela tipis di pinggir yang membuka panel saat digeser ke dalam.
    private var edgeView: FrameLayout? = null
    private var edgePill: View? = null
    private var alertOn = false
    private var panel: LinearLayout? = null
    private var scroll: MaxHeightScrollView? = null
    private var pillView: TextView? = null
    private var resStatus: TextView? = null
    private var fpsValue: TextView? = null
    private var tempValue: TextView? = null
    private var battValue: TextView? = null
    private var extraView: TextView? = null
    private var autoFpsSwitch: PillSwitch? = null
    private var mainSwitch: PillSwitch? = null
    private var focusSwitch: PillSwitch? = null
    private var saverSwitch: PillSwitch? = null
    private var saverSub: TextView? = null
    private var macroSwitch: PillSwitch? = null
    private var crossSwitch: PillSwitch? = null
    private var hudSwitch: PillSwitch? = null
    private var macro: MacroController? = null
    private var crosshair: CrosshairController? = null
    private var hud: HudController? = null
    private var ringGpu: RingView? = null
    private var ringCpu: RingView? = null
    private val scaleChips = mutableMapOf<Int, TextView>()
    private val fpsChips = mutableMapOf<Int, TextView>()
    private val heatChips = mutableMapOf<Int, TextView>()

    // Pop-up lebar (desain dua panel)
    private var spaceRoot: FrameLayout? = null
    private var pickerLayer: FrameLayout? = null
    private var rowRes: ArtRow? = null
    private var rowFps: ArtRow? = null
    private var orbCpu: ArtGauge? = null
    private var orbRight: ArtGauge? = null
    private var meterCpu: ArtMeter? = null
    private var meterRight: ArtMeter? = null
    private var hexMacro: ArtHit? = null
    private var hexCross: ArtHit? = null
    private var hexHud: ArtHit? = null
    private var tileMain: ArtTile? = null
    private var tileSaver: ArtTile? = null
    private var tileAuto: ArtTile? = null
    private var selHeat: ArtSelector? = null
    private var selFocus: ArtSelector? = null

    private var heatWarned = false
    private var measuringFps = false
    private var measuringLoad = false
    private var uiScale = 1f          // skala ukuran panel (dp dan teks), diatur di buildPanel
    private var spaceMode = false     // true = pop-up lebar dua panel (landscape); false = kartu bertumpuk
    private var spaceUnit = 1f        // piksel per 1 dp pada tata letak pop-up lebar
    private var shownScale: Int? = null   // skala resolusi yang sedang aktif (untuk menandai pilihan)
    private var shownFps = 0
    private var saverOn = false
    private var bubbleX = 0           // posisi bubble sebelum panel dibuka
    private var bubbleY = 0
    private var gpuMissing = false  // HP tidak membuka data GPU: cincinnya dipakai untuk RAM

    // Auto FPS: true bila KITA yang menurunkan FPS karena panas, jadi KITA yang menaikkannya lagi.
    private var autoFpsThrottled = false
    private var autoFpsBusy = false
    private var autoFpsPrev = 0
    private var lastAutoBoost = 0L

    // Pemantau game di depan: layar dikembalikan otomatis setelah game ditinggalkan.
    @Volatile private var alive = true
    private var finishing = false
    private var armed = false      // true setelah game pernah terlihat di depan
    private var awaySince = 0L     // 0 = game sedang di depan / belum dianggap ditinggalkan
    private var startedAt = 0L

    private val heatTick = object : Runnable {
        override fun run() {
            if (finishing) return
            checkHeatAndAuto()
            main.postDelayed(this, HEAT_POLL_MS)
        }
    }

    private val watchTick = object : Runnable {
        override fun run() {
            if (finishing) return
            val game = store.currentGame
            // Selama Macro tampil, pemantau game dijeda: Macro bisa dipakai di aplikasi apa pun.
            if (!store.autoReset || game == null || macro?.shown == true) {
                main.postDelayed(this, POLL_MS)
                return
            }
            io.execute {
                val fg = ForegroundWatcher.foregroundPackage()
                main.post {
                    if (alive && !finishing) {
                        onForeground(fg, game)
                        if (!finishing) main.postDelayed(this, POLL_MS)
                    }
                }
            }
        }
    }

    /** Memperbarui statistik tiap 3 detik selama panel terbuka. */
    private val statsTick = object : Runnable {
        override fun run() {
            if (finishing || panel?.visibility != View.VISIBLE) return
            updateStatsViews()
            measureFps()
            measureLoads()
            main.postDelayed(this, STATS_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        store = GameStore(this)

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Bubble Nexus Game Boost", NotificationManager.IMPORTANCE_LOW)
        )
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin pop-up overlay belum aktif", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        macro = MacroController(this, wm, store, main) {
            macroSwitch?.checked = false
            hexMacro?.active = false
        }
        crosshair = CrosshairController(this, wm, store, main) {
            crossSwitch?.checked = false
            hexCross?.active = false
        }
        hud = HudController(this, wm, store, main) {
            hudSwitch?.checked = false
            hexHud?.active = false
        }
        buildOverlay()
        refreshStatus()
        startWatching()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_RESET -> resetAll()
            ACTION_FINISH -> finishAndReset()
            ACTION_OPEN -> if (panel?.visibility != View.VISIBLE) togglePanel()
            ACTION_MACRO -> {
                macro?.setShown(true)
                macroSwitch?.checked = macro?.shown == true
                hexMacro?.active = macro?.shown == true
            }
            ACTION_CROSSHAIR -> {
                crosshair?.let { it.setShown(!it.shown) }
                crossSwitch?.checked = crosshair?.shown == true
                hexCross?.active = crosshair?.shown == true
            }
            ACTION_HUD -> {
                hud?.setShown(true)
                hudSwitch?.checked = hud?.shown == true
                hexHud?.active = hud?.shown == true
            }
            // dimulai lagi dari launcher (mungkin untuk game lain): mulai pantauan dari awal
            else -> {
                applyOpenMode()
                resetWatchState()
                // Crosshair otomatis ikut tampil saat game dibuka (bila dinyalakan di Pengaturan).
                if (store.crossAuto && crosshair?.shown != true) {
                    crosshair?.setShown(true)
                    crossSwitch?.checked = crosshair?.shown == true
                    hexCross?.active = crosshair?.shown == true
                }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        alive = false
        macro?.destroy()
        macro = null
        crosshair?.destroy()
        crosshair = null
        hud?.destroy()
        hud = null
        main.removeCallbacksAndMessages(null)
        hideEdgeHandle()
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        io.shutdown()
        super.onDestroy()
    }

    // ------------------------------------------------------------ actions

    private fun applyScale(percent: Int) {
        resStatus?.text = "Mengatur…"
        io.execute {
            val game = store.currentGame
            val perGame = GameDownscale.enabled(store)
            val res = if (perGame) {
                if (game == null) {
                    CmdResult(false, "", "Belum ada game yang diluncurkan dari Nexus.")
                } else {
                    GameDownscale.apply(game, percent, store)
                }
            } else {
                val info = DisplayController.read()
                if (info == null) {
                    CmdResult(false, "", "Tidak ada akses sistem (Shizuku/root).")
                } else {
                    DisplayController.setScale(percent, store.scaleDensity, info, store)
                }
            }
            if (res.ok) {
                game?.let { store.setScale(it, percent) }
                if (perGame) toastFromBackground("Berlaku setelah game dibuka ulang")
            } else {
                toastFromBackground("Gagal: ${res.err.ifBlank { res.out }}")
            }
            refreshStatus()
        }
    }

    private fun applyFps(hz: Int) {
        io.execute {
            val game = store.currentGame
            // Game Mode untuk game ini bila diizinkan dan nilainya dikenal; kalau tidak, kunci refresh rate.
            val gm: CmdResult? =
                if (game != null && GameDownscale.fpsEnabled(store) && (hz == 0 || GameDownscale.fpsSupported(hz))) {
                    if (hz == 0 && GameDownscale.activeFps(game, store) == 0) {
                        CmdResult(true, "", "")
                    } else {
                        GameDownscale.applyFps(game, hz, store)
                    }
                } else {
                    null
                }
            val useLock = gm == null || !gm.ok
            val res = if (useLock && hz > 0) {
                DisplayController.setRefreshRate(hz, store)
            } else {
                DisplayController.resetRefreshRate(store)
            }
            if (res.ok) {
                game?.let { store.setFps(it, hz) }
                // Pengguna memilih sendiri; Auto FPS tidak boleh menimpanya lagi.
                main.post { autoFpsThrottled = false }
                if (hz > 0 && gm != null && !gm.ok) {
                    toastFromBackground("Game Mode menolak batas FPS, dipakai kunci refresh rate layar")
                } else if (hz > 0 && gm != null) {
                    toastFromBackground("Batas FPS game diatur. Buka ulang game bila belum terasa.")
                }
            } else {
                toastFromBackground("Gagal: ${res.err.ifBlank { res.out }}")
            }
            refreshStatus()
        }
    }

    private fun boost() {
        toastFromBackground("Boost berjalan…")
        io.execute {
            val out = Boost.run(this)
            main.post {
                Toast.makeText(this, Boost.message(out), Toast.LENGTH_LONG).show()
                updateStatsViews()
            }
        }
    }

    private fun resetAll() {
        autoFpsThrottled = false
        io.execute {
            DisplayController.resetAll(store)
            refreshStatus()
        }
    }

    private fun finishAndReset() {
        finishing = true
        autoFpsThrottled = false
        io.execute {
            DisplayController.resetAll(store)
            PlayMode.restore(store)
            main.post { stopSelf() }
        }
    }

    private fun startWatching() {
        resetWatchState()
        main.postDelayed(watchTick, POLL_MS)
        main.postDelayed(heatTick, HEAT_POLL_MS)
    }

    // --------------------------------------------- panas, Auto FPS, Boost

    private fun checkHeatAndAuto() {
        val temp = SystemStats.read(this).tempC
        checkHeat(temp)
        checkAutoFps(temp)
        checkAutoBoost()
    }

    /** Bandingkan suhu baterai dengan batas pengguna; ubah bubble dan beri pesan bila terlalu panas. */
    private fun checkHeat(temp: Float) {
        val limit = store.heatWarnC
        if (limit <= 0) {
            if (heatWarned) {
                heatWarned = false
                setAlert(false)
            }
            return
        }
        if (!heatWarned && temp >= limit) {
            heatWarned = true
            setAlert(true)
            Toast.makeText(
                this,
                String.format(java.util.Locale.US, "⚠ HP panas (%.1f°C). Turunkan resolusi/FPS atau istirahat sebentar.", temp),
                Toast.LENGTH_LONG
            ).show()
        } else if (heatWarned && temp < limit - 2) {
            heatWarned = false
            setAlert(false)
        }
    }

    /** Auto FPS: turun ke 60 Hz saat panas, kembali ke pilihan sebelumnya setelah suhu turun 3°C. */
    private fun checkAutoFps(temp: Float) {
        if (!store.autoFps || autoFpsBusy) return
        val limit = if (store.heatWarnC > 0) store.heatWarnC else DEFAULT_HOT_C

        if (!autoFpsThrottled && temp >= limit) {
            val rates = DisplayController.supportedRates(this)
            val target = rates.lastOrNull { it <= 60 } ?: rates.firstOrNull() ?: return
            autoFpsBusy = true
            io.execute {
                val current = DisplayController.readRefreshRate()
                if (current in 1..target) {
                    main.post { autoFpsBusy = false }
                    return@execute
                }
                val r = DisplayController.setRefreshRate(target, store)
                main.post {
                    autoFpsBusy = false
                    if (r.ok) {
                        autoFpsThrottled = true
                        autoFpsPrev = current
                        Toast.makeText(
                            this,
                            "Auto FPS: turun ke $target Hz karena HP panas",
                            Toast.LENGTH_LONG
                        ).show()
                        refreshStatus()
                    }
                }
            }
        } else if (autoFpsThrottled && temp < limit - 3) {
            restoreAutoFps()
        }
    }

    private fun restoreAutoFps() {
        if (!autoFpsThrottled || autoFpsBusy) return
        autoFpsBusy = true
        val prev = autoFpsPrev
        io.execute {
            val r = if (prev > 0) {
                DisplayController.setRefreshRate(prev, store)
            } else {
                DisplayController.resetRefreshRate(store)
            }
            main.post {
                autoFpsBusy = false
                if (r.ok) {
                    autoFpsThrottled = false
                    Toast.makeText(this, "Auto FPS: FPS dikembalikan", Toast.LENGTH_SHORT).show()
                    refreshStatus()
                }
            }
        }
    }

    /** Boost otomatis bila RAM bebas menipis; jeda 90 detik antar-boost supaya tidak berulang terus. */
    private fun checkAutoBoost() {
        if (!store.autoBoost) return
        val now = SystemClock.elapsedRealtime()
        if (lastAutoBoost != 0L && now - lastAutoBoost < AUTO_BOOST_COOLDOWN_MS) return
        val s = SystemStats.read(this)
        val low = s.ramFreeMb < maxOf(s.ramTotalMb * 12 / 100, 700L)
        if (!low) return
        lastAutoBoost = now
        io.execute {
            val out = Boost.run(this)
            main.post {
                Toast.makeText(this, "Boost otomatis. " + Boost.message(out), Toast.LENGTH_SHORT).show()
                updateStatsViews()
            }
        }
    }

    private fun setAlert(alert: Boolean) {
        alertOn = alert
        bubbleView?.foreground = ring(alert)
        (edgePill?.background as? GradientDrawable)?.setColor(if (alert) COLOR_ALERT else COLOR_PILL_EDGE)
        pillView?.apply {
            text = if (alert) "● PANAS" else "● ACTIVE"
            setTextColor(if (alert) COLOR_ALERT else COLOR_GREEN)
        }
    }

    // ----------------------------------------------------- pemantau game

    private fun resetWatchState() {
        armed = false
        awaySince = 0L
        startedAt = SystemClock.elapsedRealtime()
    }

    /**
     * Dipanggil di main thread dengan paket yang sedang di depan ([fg], null = tidak diketahui).
     * Fail-safe: layar hanya dikembalikan bila SECARA PASTI terlihat aplikasi lain di depan
     * terus-menerus selama [GRACE_MS]. Bila tidak yakin (null), tidak ada yang dilakukan.
     */
    private fun onForeground(fg: String?, game: String) {
        if (finishing || fg == null) return
        val now = SystemClock.elapsedRealtime()
        when {
            fg == game -> {
                armed = true
                awaySince = 0L
            }
            // Nexus sendiri di depan: pengguna mungkin sedang mengubah profil, jangan reset.
            fg == packageName -> awaySince = 0L
            // Aplikasi lain di depan. Baru dihitung setelah game pernah terlihat, atau setelah
            // ARM_TIMEOUT_MS bila game ternyata tidak pernah terbuka.
            armed || now - startedAt > ARM_TIMEOUT_MS -> {
                if (awaySince == 0L) {
                    awaySince = now
                } else if (now - awaySince >= GRACE_MS) {
                    toastFromBackground("Game ditutup, layar dikembalikan")
                    finishAndReset()
                }
            }
        }
    }

    private fun toastFromBackground(msg: String) {
        main.post { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
    }

    // ----------------------------------------------------------- statistik

    private fun clock(): String {
        val secs = (SystemClock.elapsedRealtime() - startedAt) / 1000
        return if (secs >= 3600) {
            String.format(java.util.Locale.US, "%d:%02d:%02d", secs / 3600, secs % 3600 / 60, secs % 60)
        } else {
            String.format(java.util.Locale.US, "%d:%02d", secs / 60, secs % 60)
        }
    }

    private fun heatColor(c: Float): Int = when {
        c >= 44f -> COLOR_ALERT
        c >= 38f -> COLOR_AMBER
        else -> COLOR_GREEN
    }

    private fun updateStatsViews() {
        val s = SystemStats.read(this)
        tempValue?.apply {
            text = String.format(java.util.Locale.US, "%.0f°C", s.tempC)
            setTextColor(heatColor(s.tempC))
        }
        battValue?.apply {
            text = "${s.batteryPct}%"
            setTextColor(if (s.batteryPct <= 15) COLOR_ALERT else COLOR_GREEN)
        }
        extraView?.text = String.format(java.util.Locale.US, "RAM %.1f GB bebas  ·  Main %s", s.ramFreeMb / 1024f, clock())
    }

    /** Perkiraan FPS game dari SurfaceFlinger; "—" bila HP tidak menyediakan datanya. */
    private fun measureFps() {
        val game = store.currentGame
        if (game == null) {
            fpsValue?.text = "—"
            return
        }
        if (measuringFps) return
        measuringFps = true
        io.execute {
            val fps = FpsMeter.measure(game)
            main.post {
                measuringFps = false
                fpsValue?.text = fps?.toString() ?: "—"
            }
        }
    }

    /**
     * Beban CPU dan GPU untuk cincin; null (tampil "—") bila HP tidak menyediakan datanya.
     * Bila HP sama sekali tidak membuka data GPU, cincin GPU berganti menjadi cincin RAM.
     */
    private fun measureLoads() {
        if (measuringLoad) return
        measuringLoad = true
        io.execute {
            val cpu = LoadMeter.cpuPercent()
            val gpu = LoadMeter.gpuPercent()
            val noGpu = LoadMeter.gpuUnavailable
            // GPU tidak terbaca di HP ini: cincinnya menampilkan RAM terpakai (data asli, selalu tersedia).
            var ram: Int? = null
            var ramGb: Float? = null
            if (noGpu) {
                val st = SystemStats.read(this)
                if (st.ramTotalMb > 0) {
                    ram = ((st.ramTotalMb - st.ramFreeMb) * 100 / st.ramTotalMb).toInt().coerceIn(0, 100)
                    ramGb = (st.ramTotalMb - st.ramFreeMb) / 1024f
                }
            }
            val ramPct = ram
            val usedGb = ramGb
            main.post {
                measuringLoad = false
                gpuMissing = noGpu
                val rightPct = if (noGpu) ramPct else gpu

                // Panel sempit: cincin.
                ringCpu?.percent = cpu
                ringGpu?.let {
                    it.label = if (noGpu) "RAM" else "GPU"
                    it.warnFrom = if (noGpu) 85 else 70
                    it.alertFrom = if (noGpu) 93 else 90
                    it.percent = rightPct
                }

                // Pop-up lebar: pengukur hologram dan garis-garis beban.
                orbCpu?.setPercent(cpu)
                orbRight?.let {
                    it.label = if (noGpu) "RAM" else "GPU"
                    it.warnFrom = if (noGpu) 85 else 70
                    it.alertFrom = if (noGpu) 93 else 90
                    if (noGpu) {
                        it.progress = ramPct
                        it.value = usedGb?.let { g -> String.format(java.util.Locale.US, "%.1f", g) } ?: "—"
                        it.unitText = if (usedGb != null) "GB" else ""
                    } else {
                        it.setPercent(gpu)
                    }
                }
                meterCpu?.percent = cpu
                meterRight?.percent = rightPct
            }
        }
    }

    /** Skala game yang benar-benar aktif: 100 (asli) bila downscale-nya sudah dibersihkan oleh Reset. */
    private fun effectiveGameScale(game: String): Int = GameDownscale.activeScale(game, store)

    /** Baca resolusi dan refresh rate saat ini di background, lalu perbarui teks dan chip di main thread. */
    private fun refreshStatus() {
        io.execute {
            val info = DisplayController.read()
            val hz = if (info != null) DisplayController.readRefreshRate() else 0
            main.post {
                val perGame = GameDownscale.enabled(store)
                val game = store.currentGame
                val label = when {
                    perGame && game == null -> "Resolusi per game (belum ada game)"
                    perGame -> "Game ${DisplayController.scaleLabel(effectiveGameScale(game!!))} · layar tetap asli"
                    info == null -> "Akses sistem tidak tersedia"
                    info.isOverridden -> "${info.curW}×${info.curH} (${info.currentPercent}%)"
                    else -> "${info.physW}×${info.physH} (asli)"
                }
                val gameFps = game?.let { GameDownscale.activeFps(it, store) } ?: 0
                resStatus?.text = when {
                    gameFps > 0 -> "$label · maks $gameFps FPS"
                    hz > 0 -> "$label · $hz Hz"
                    else -> label
                }

                val activeScale = when {
                    perGame -> game?.let { g ->
                        DisplayController.PRESETS.minByOrNull { abs(it - effectiveGameScale(g)) }
                    }
                    info == null -> null
                    !info.isOverridden -> 100
                    else -> DisplayController.PRESETS.minByOrNull { abs(it - info.currentPercent) }
                }
                scaleChips.forEach { (p, v) -> styleChip(v, p == activeScale) }
                val activeFps = if (gameFps > 0) gameFps else hz
                fpsChips.forEach { (h, v) -> styleChip(v, h == activeFps) }

                // Pop-up lebar: nilai di daftar kiri dan penanda pilihan saat kotak pilihan dibuka.
                shownScale = activeScale
                shownFps = activeFps
                rowRes?.setValue(activeScale?.let { DisplayController.scaleLabel(it) } ?: "—")
                rowFps?.setValue(
                    when {
                        gameFps > 0 -> "$gameFps FPS"
                        hz > 0 -> "$hz Hz"
                        else -> "Auto"
                    }
                )

                main.postDelayed({ clamp() }, 600) // layar berubah ukuran, jaga bubble tetap terlihat
            }
        }
    }

    /** Sinkronkan saklar panel dengan pengaturan tersimpan dan status Penghemat Baterai saat ini. */
    private fun loadToggles() {
        autoFpsSwitch?.checked = store.autoFps
        mainSwitch?.checked = store.playOptimize
        focusSwitch?.checked = store.focusMode
        macroSwitch?.checked = macro?.shown == true
        crossSwitch?.checked = crosshair?.shown == true
        hudSwitch?.checked = hud?.shown == true
        tileMain?.active = store.playOptimize
        tileAuto?.active = store.autoFps
        hexMacro?.active = macro?.shown == true
        hexCross?.active = crosshair?.shown == true
        hexHud?.active = hud?.shown == true
        selFocus?.setLabel(focusLabel(store.focusMode))
        updateHeatChips()
        io.execute {
            val on = PlayMode.batterySaverOn() ?: false
            main.post {
                saverOn = on
                saverSwitch?.checked = on
                saverSub?.text = if (on) "(Aktif)" else "(Nonaktif)"
                tileSaver?.active = on
            }
        }
    }

    // ------------------------------------------------------------ overlay

    private fun buildOverlay() {
        val bubble = ImageView(this).apply {
            setImageResource(R.drawable.logo_nx)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF0B0618.toInt())
            }
            foreground = ring(false)
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52))
        }
        bubbleView = bubble

        // Isi panel dibangun saat panel dibuka (buildPanel), supaya susunannya mengikuti orientasi layar.
        val panelView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(COLOR_PANEL)
                setStroke(dp(1), COLOR_BORDER)
            }
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP)
        }
        panel = panelView

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bubble)
            addView(panelView)
        }
        root = container

        val lp = WindowManager.LayoutParams(
            WRAP,
            WRAP,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(120)
        }
        params = lp

        installDrag(bubble) { togglePanel() }
        wm.addView(container, lp)
        applyOpenMode()
    }

    // ------------------------------------------------- buka pop-up dari tepi layar

    /**
     * Terapkan cara membuka pop-up: bubble melayang, atau jendela tipis di tepi layar yang dibuka
     * dengan menggesernya ke dalam. Saat panel terbuka, keduanya disembunyikan.
     */
    private fun applyOpenMode() {
        val open = panel?.visibility == View.VISIBLE
        val edge = store.openMode == GameStore.OPEN_EDGE
        bubbleView?.visibility = if (edge || open) View.GONE else View.VISIBLE
        if (edge && !open) {
            // Sisi atau ukuran layar mungkin berubah: pasang ulang dari awal.
            hideEdgeHandle()
            showEdgeHandle()
        } else {
            hideEdgeHandle()
        }
    }

    private fun rawDp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun showEdgeHandle() {
        if (edgeView != null) return
        val right = store.edgeRight
        val handleW = rawDp(22)
        val handleH = rawDp(160)
        val pillW = rawDp(4)
        val pillH = rawDp(56)
        val side = if (right) Gravity.END else Gravity.START

        val pill = View(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = rawDp(2).toFloat()
                setColor(if (alertOn) COLOR_ALERT else COLOR_PILL_EDGE)
            }
        }
        val view = FrameLayout(this).apply {
            addView(pill, FrameLayout.LayoutParams(pillW, pillH, Gravity.CENTER_VERTICAL or side))
        }
        installEdgeTouch(view, right, handleH, pillH)

        val lp = WindowManager.LayoutParams(
            handleW,
            handleH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or side
            x = 0
            y = ((realMetrics().heightPixels - handleH) * 0.4f).toInt().coerceAtLeast(0)
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        // Minta Android tidak memakai gestur Kembali di area ini (Android 10 ke atas, maksimal 200 dp
        // per sisi). Tidak semua HP menghormatinya; kalau gestur Kembali tetap menang, pakai mode bubble.
        if (Build.VERSION.SDK_INT >= 29) {
            runCatching { view.systemGestureExclusionRects = listOf(Rect(0, 0, handleW, handleH)) }
        }

        try {
            wm.addView(view, lp)
        } catch (e: Throwable) {
            Toast.makeText(
                this,
                "Gagal memasang gagang tepi layar: ${e.message ?: e.javaClass.simpleName}",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        edgeView = view
        edgePill = pill
    }

    private fun hideEdgeHandle() {
        edgeView?.let { v -> runCatching { wm.removeView(v) } }
        edgeView = null
        edgePill = null
    }

    /** Geser ke dalam dari tepi membuka panel. Ketukan pada garis penanda juga membuka (cadangan). */
    private fun installEdgeTouch(view: View, right: Boolean, handleH: Int, pillH: Int) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val need = rawDp(24)
        var downX = 0f
        var downY = 0f
        var fired = false

        view.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    fired = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!fired) {
                        val inward = if (right) downX - e.rawX else e.rawX - downX
                        if (inward > need && inward > abs(e.rawY - downY)) {
                            fired = true
                            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                            openFromEdge()
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val still = abs(e.rawX - downX) < slop && abs(e.rawY - downY) < slop
                    val onPill = e.y >= (handleH - pillH) / 2f && e.y <= (handleH + pillH) / 2f
                    if (!fired && still && onPill) {
                        v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        openFromEdge()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun openFromEdge() {
        if (panel?.visibility != View.VISIBLE) togglePanel()
    }

    /**
     * Susun isi panel. Layar lebar (landscape): dua kolom seperti desain, kartu di bawahnya sejajar.
     * Layar sempit (portrait): satu kolom, kartu bertumpuk.
     */
    /** Panel sempit (portrait): kartu bertumpuk selebar layar. Layar landscape memakai [buildSpacePanel]. */
    private fun buildPanel() {
        val p = panel ?: return
        val dm = realMetrics()
        val wDp = dm.widthPixels / dm.density

        // Rancangan dasar 360 dp lebar; semua ukuran (dp, teks, cincin) dikalikan skala ini.
        uiScale = ((wDp - 16f) / 360f).coerceIn(0.9f, 1.3f)
        val edge = (8 * dm.density).toInt()
        val panelW = dm.widthPixels - 2 * edge

        p.removeAllViews()
        scaleChips.clear()
        fpsChips.clear()
        heatChips.clear()
        p.background = panelBackground()
        p.layoutParams = LinearLayout.LayoutParams(panelW, WRAP)

        p.addView(buildHeader())

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(2), dp(12), dp(10))
        }
        val sv = MaxHeightScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        scroll = sv
        p.addView(sv, LinearLayout.LayoutParams(MATCH, WRAP))

        content.addView(buildStatsBlock(), LinearLayout.LayoutParams(MATCH, WRAP))
        content.addView(buildControlsBlock(), LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) })

        // Dua kartu per baris supaya panel tidak terlalu panjang.
        listOf(
            buildMainCard(), buildFocusCard(), buildSaverCard(), buildHeatCard(),
            buildCrosshairCard(), buildMacroCard(), buildHudCard(), buildBoostCard(), buildAboutCard(),
        ).chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, c -> row.addView(c, cardParams(first = i == 0)) }
            content.addView(row, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        }

        extraView = label("…", 10f, COLOR_MUTED).also {
            it.gravity = Gravity.CENTER
            it.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(8) }
            content.addView(it)
        }
        setAlert(heatWarned)
    }

    /** Bingkai ungu menyala (glow) dengan latar gradasi gelap, seperti desain. */
    private fun panelBackground(): Drawable {
        val glow = GradientDrawable().apply {
            cornerRadius = dp(20).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(5), 0x408B5CF6)
        }
        val frame = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(COLOR_PANEL_TOP, COLOR_PANEL)
        ).apply {
            cornerRadius = dp(17).toFloat()
            setStroke(dp(2), COLOR_FRAME)
        }
        return LayerDrawable(arrayOf(glow, frame)).apply {
            setLayerInset(1, dp(2), dp(2), dp(2), dp(2))
        }
    }

    /** Latar kotak besar (blok cincin dan blok resolusi/FPS). */
    private fun framePanel(v: LinearLayout): LinearLayout = v.apply {
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0xFF1B1242.toInt(), 0xFF130C30.toInt())
        ).apply {
            cornerRadius = dp(14).toFloat()
            setStroke(dp(1), COLOR_CARD_BORDER)
        }
    }

    /** Latar kartu kecil (Mode Main, Macro, dan seterusnya). */
    private fun cardBackground(): Drawable = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT,
        intArrayOf(0xFF22184F.toInt(), 0xFF171036.toInt())
    ).apply {
        cornerRadius = dp(12).toFloat()
        setStroke(dp(1), COLOR_CARD_BORDER)
    }

    private fun buildHeader(): LinearLayout {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(12), dp(8))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo_nx)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF0B0618.toInt())
            }
            foreground = ring(false)
            clipToOutline = true
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)))

        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label("NEXUS GAME BOOST", 17f, Color.WHITE, bold = true))
        titles.addView(label("Max Performance, No Lag", 12f, COLOR_MUTED))
        header.addView(titles, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(12) })

        val pill = label("● ACTIVE", 12f, COLOR_GREEN, bold = true).apply {
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(COLOR_PILL_BG)
            }
        }
        pillView = pill
        header.addView(pill, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(10) })

        // Kecilkan ke bubble; tutup = Selesai (kembalikan semuanya lalu tutup bubble).
        header.addView(
            headerButton(R.drawable.ic_minimize) { togglePanel() },
            LinearLayout.LayoutParams(dp(34), dp(34)).apply { marginEnd = dp(8) }
        )
        header.addView(headerButton(R.drawable.ic_close) { finishAndReset() }, LinearLayout.LayoutParams(dp(34), dp(34)))

        // Header dipakai untuk menggeser panel.
        installDrag(header, null)
        return header
    }

    private fun headerButton(iconRes: Int, onClick: () -> Unit): ImageView = ImageView(this).apply {
        setImageResource(iconRes)
        imageTintList = ColorStateList.valueOf(COLOR_ACCENT)
        setPadding(dp(7), dp(7), dp(7), dp(7))
        background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(COLOR_CHIP)
            setStroke(dp(1), COLOR_FRAME)
        }
        setOnClickListener { onClick() }
    }

    /** Cincin GPU dan CPU di kiri, garis pemisah, lalu FPS, suhu, dan baterai. */
    private fun buildStatsBlock(): LinearLayout {
        val ringDp = 84
        val gpu = RingView(this, uiScale).apply { label = if (gpuMissing) "RAM" else "GPU" }
        val cpu = RingView(this, uiScale).apply { label = "CPU" }
        ringGpu = gpu
        ringCpu = cpu

        val rings = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        rings.addView(gpu, LinearLayout.LayoutParams(dp(ringDp), dp(ringDp)))
        rings.addView(cpu, LinearLayout.LayoutParams(dp(ringDp), dp(ringDp)).apply { marginStart = dp(6) })

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val (fpsRow, fpsV) = statRow(R.drawable.ic_chart, COLOR_ACCENT, "FPS")
        val (tempRow, tempV) = statRow(R.drawable.ic_thermo, COLOR_ALERT, "Suhu HP")
        val (battRow, battV) = statRow(R.drawable.ic_battery, COLOR_GREEN, "Baterai")
        fpsValue = fpsV
        tempValue = tempV
        battValue = battV
        col.addView(fpsRow)
        col.addView(tempRow, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
        col.addView(battRow, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })

        val sep = View(this).apply { setBackgroundColor(COLOR_CARD_BORDER) }

        val block = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        block.addView(rings)
        block.addView(sep, LinearLayout.LayoutParams(dp(1), dp(ringDp * 3 / 4)).apply {
            marginStart = dp(8)
            marginEnd = dp(8)
        })
        block.addView(col, LinearLayout.LayoutParams(WRAP, WRAP))
        return framePanel(block)
    }

    private fun statRow(iconRes: Int, tint: Int, caption: String): Pair<LinearLayout, TextView> {
        val value = label("—", 20f, Color.WHITE, bold = true)
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(value)
        texts.addView(label(caption, 11f, COLOR_MUTED))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        row.addView(icon(iconRes, tint, 28))
        row.addView(texts, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
        return row to value
    }

    /** Render Resolution dan FPS Limit. */
    private fun buildControlsBlock(): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val cols = COLUMNS

        // Status resolusi di sisi kanan judul, supaya tidak memakan satu baris sendiri.
        val status = label("…", 10f, COLOR_MUTED).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        resStatus = status
        box.addView(
            sectionHeader(
                R.drawable.ic_monitor, "Render Resolution",
                info = "Skala resolusi game (hanya game ini, layar tetap asli). Makin kecil makin ringan, " +
                    "tapi gambar makin kabur. Berlaku setelah game dibuka ulang.",
                topDp = 0,
                trailing = status,
            )
        )
        chipGrid(DisplayController.PRESETS, scaleChips, cols, { DisplayController.scaleLabel(it) }) {
            applyScale(it)
        }.forEach { box.addView(it) }

        // Auto FPS di sisi kanan judul FPS Limit.
        val autoSw = PillSwitch(this, uiScale)
        autoFpsSwitch = autoSw
        val auto = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setOnClickListener {
                autoSw.checked = !autoSw.checked
                store.autoFps = autoSw.checked
                if (!autoSw.checked) restoreAutoFps()
            }
        }
        auto.addView(label("Auto FPS", 10f, COLOR_MUTED))
        auto.addView(autoSw, LinearLayout.LayoutParams(dp(42), dp(24)).apply { marginStart = dp(6) })

        val rates = listOf(0) + GameDownscale.fpsOptions(DisplayController.supportedRates(this), store.perGameFps)
        if (rates.size > 1) {
            box.addView(
                sectionHeader(
                    R.drawable.ic_bolt, "FPS Limit",
                    info = if (GameDownscale.fpsEnabled(store)) {
                        "Batas FPS khusus game ini (Game Mode). Nilai lain mengunci refresh rate layar. " +
                            "Auto = tanpa batas. Auto FPS menurunkan FPS otomatis saat HP panas."
                    } else {
                        "Membatasi refresh rate layar. Auto = diatur otomatis oleh sistem. " +
                            "Auto FPS menurunkan FPS otomatis saat HP panas."
                    },
                    topDp = 10,
                    trailing = auto,
                )
            )
            chipGrid(rates, fpsChips, cols, { if (it == 0) "Auto" else "$it FPS" }) {
                applyFps(it)
            }.forEach { box.addView(it) }
        }
        return framePanel(box)
    }

    // ------------------------------------------------------------- kartu

    private fun cardParams(first: Boolean = false) =
        LinearLayout.LayoutParams(0, MATCH, 1f).apply { if (!first) marginStart = dp(6) }

    /** Kartu bergaya desain: ikon, judul, keterangan kecil, dan [trailing] di kanan (boleh kosong). */
    private fun card(
        iconRes: Int,
        tint: Int,
        title: String,
        subtitle: String,
        trailing: View?,
        onClick: (() -> Unit)?,
    ): Pair<LinearLayout, TextView> {
        val sub = label(subtitle, 11f, COLOR_MUTED).apply { maxLines = 2 }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = cardBackground()
            if (onClick != null) setOnClickListener { onClick() }
        }
        row.addView(icon(iconRes, tint, 28))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label(title, 13f, Color.WHITE, bold = true))
        col.addView(sub)
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
            marginStart = dp(6)
            marginEnd = dp(4)
        })
        if (trailing != null) row.addView(trailing)
        return row to sub
    }

    private fun toggleCard(
        iconRes: Int,
        tint: Int,
        title: String,
        subtitle: String,
        onChange: (PillSwitch, Boolean) -> Unit,
    ): ToggleCard {
        val sw = PillSwitch(this, uiScale)
        val (view, sub) = card(iconRes, tint, title, subtitle, null, null)
        view.addView(sw, LinearLayout.LayoutParams(dp(42), dp(24)))
        view.setOnClickListener {
            sw.checked = !sw.checked
            onChange(sw, sw.checked)
        }
        return ToggleCard(view, sw, sub)
    }

    private fun buildMainCard(): LinearLayout {
        val c = toggleCard(R.drawable.ic_crown, COLOR_ACCENT, "Mode Main", "(Optimasi Game)") { _, on ->
            store.playOptimize = on
        }
        mainSwitch = c.sw
        return c.view
    }

    private fun buildFocusCard(): LinearLayout {
        val c = toggleCard(R.drawable.ic_focus, COLOR_ACCENT, "Mode Fokus", "(Jangan Ganggu)") { sw, on ->
            io.execute {
                val r = PlayMode.setFocus(on, store)
                if (!r.ok) {
                    main.post {
                        sw.checked = !on
                        store.focusMode = !on
                        Toast.makeText(this, "Gagal: ${r.err.ifBlank { r.out }}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        focusSwitch = c.sw
        return c.view
    }

    private fun buildSaverCard(): LinearLayout {
        lateinit var holder: ToggleCard
        holder = toggleCard(R.drawable.ic_leaf, COLOR_GREEN, "Hemat Baterai", "(Nonaktif)") { sw, on ->
            holder.sub.text = if (on) "(Aktif)" else "(Nonaktif)"
            io.execute {
                val r = PlayMode.setBatterySaver(on, store)
                if (!r.ok) {
                    main.post {
                        sw.checked = !on
                        holder.sub.text = if (!on) "(Aktif)" else "(Nonaktif)"
                        Toast.makeText(this, "Gagal: ${r.err.ifBlank { r.out }}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        saverSwitch = holder.sw
        saverSub = holder.sub
        return holder.view
    }

    /** Peringatan Panas: pilih batas suhu; ketuk batas yang sedang aktif untuk mematikannya. */
    private fun buildHeatCard(): LinearLayout {
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        HEAT_CHOICES.forEach { c ->
            val chip = label("$c", 11f, Color.WHITE).apply {
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(4), dp(3), dp(4))
                setOnClickListener { selectHeat(c) }
            }
            heatChips[c] = chip
            chips.addView(chip, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(3) })
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = cardBackground()
        }
        row.addView(icon(R.drawable.ic_warning, COLOR_ALERT, 28))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(label("Peringatan Panas", 13f, Color.WHITE, bold = true))
        col.addView(label("Batas suhu (°C)", 11f, COLOR_MUTED))
        col.addView(chips, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(4) })
        row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(6) })
        updateHeatChips()
        return row
    }

    private fun selectHeat(c: Int) {
        if (store.heatWarnC == c) {
            store.lastHeatWarnC = c
            store.heatWarnC = 0
        } else {
            store.heatWarnC = c
            store.lastHeatWarnC = c
        }
        updateHeatChips()
    }

    private fun updateHeatChips() {
        heatChips.forEach { (c, v) -> styleChip(v, c == store.heatWarnC) }
        selHeat?.setLabel(heatLabel())
    }

    /** Crosshair: titik bidik di tengah layar; warna dan ukurannya diatur di Pengaturan. */
    private fun buildCrosshairCard(): LinearLayout {
        val c = toggleCard(R.drawable.ic_crosshair, COLOR_ALERT, "Crosshair", "Titik bidik di layar") { _, on ->
            crosshair?.setShown(on)
        }
        crossSwitch = c.sw
        return c.view
    }

    /** Macro: kapsul rekam/putar ketukan dan geseran. */
    private fun buildMacroCard(): LinearLayout {
        val c = toggleCard(R.drawable.ic_touch, COLOR_ACCENT, "Macro", "Rekam dan putar ketukan") { _, on ->
            macro?.setShown(on)
        }
        macroSwitch = c.sw
        return c.view
    }

    /** HUD Mini: kotak FPS (dan angka pilihan lain) melayang; angkanya dipilih di Pengaturan. */
    private fun buildHudCard(): LinearLayout {
        val c = toggleCard(R.drawable.ic_chart, COLOR_GREEN, "HUD Mini", "FPS melayang") { _, on ->
            hud?.setShown(on)
        }
        hudSwitch = c.sw
        return c.view
    }

    private fun buildBoostCard(): LinearLayout =
        card(
            R.drawable.ic_rocket, COLOR_ACCENT, "Boost", "Suhu | Baterai | RAM",
            icon(R.drawable.ic_chevron_right, COLOR_ACCENT, 20)
        ) { boost() }.first

    private fun buildAboutCard(): LinearLayout =
        card(R.drawable.ic_info, COLOR_ACCENT, "About", versionLabel(), null) { openApp() }.first

    @Suppress("DEPRECATION")
    private fun versionLabel(): String =
        runCatching { "v" + (packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0") }
            .getOrDefault("v1.0")

    private fun openApp() {
        runCatching {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /**
     * Geser overlay dengan jari. [handle] adalah bagian yang disentuh; posisi yang diubah selalu
     * posisi overlay utama ([params] dan [root]), dibaca saat disentuh sehingga boleh dipasang
     * sebelum overlay selesai dibuat. Ketukan singkat memanggil [onTap].
     */
    private fun installDrag(handle: View, onTap: (() -> Unit)?) {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        handle.setOnTouchListener { _, e ->
            val lp = params
            val target = root
            if (lp == null || target == null) return@setOnTouchListener false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - touchX
                    val dy = e.rawY - touchY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        wm.updateViewLayout(target, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke() else clamp()
                    true
                }
                else -> false
            }
        }
    }

    private fun togglePanel() {
        val p = panel ?: return
        val b = bubbleView ?: return
        val opening = p.visibility != View.VISIBLE
        if (opening) {
            params?.let {
                bubbleX = it.x
                bubbleY = it.y
            }
            // Susunan mengikuti layar: landscape = dua panel miring, portrait = kartu bertumpuk.
            layoutPanelForScreen()
            b.visibility = View.GONE
            hideEdgeHandle()
            p.visibility = View.VISIBLE
            refreshStatus()
            loadToggles()
            updateStatsViews()
            main.removeCallbacks(statsTick)
            main.post(statsTick)
            if (!spaceMode) clampAfterLayout()
        } else {
            hidePicker()
            p.visibility = View.GONE
            applyOpenMode()
            main.removeCallbacks(statsTick)
            // Bubble kembali ke tempat semula.
            params?.let {
                it.x = bubbleX
                it.y = bubbleY
            }
            setFullScreen(false)
            clampAfterLayout()
        }
    }

    @Suppress("DEPRECATION")
    private fun realMetrics(): DisplayMetrics = DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }

    /** Batasi tinggi isi panel agar seluruh panel (header + isi) tetap muat di layar. */
    private fun updateScrollMax() {
        scroll?.maxHeightPx = (realMetrics().heightPixels - dp(64)).coerceAtLeast(dp(140))
    }

    /** Layar diputar saat panel terbuka: susun ulang panel supaya cocok dengan layar yang baru. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Layar diputar: letakkan ulang gagang tepi layar di sisi yang benar.
        if (edgeView != null) {
            hideEdgeHandle()
            showEdgeHandle()
        }
        if (finishing || panel?.visibility != View.VISIBLE) return
        layoutPanelForScreen()
        loadToggles()
        refreshStatus()
        updateStatsViews()
        if (!spaceMode) clampAfterLayout()
    }

    /** Pastikan seluruh overlay (termasuk panel) berada di dalam layar. */
    @Suppress("DEPRECATION")
    private fun clamp() {
        val r = root ?: return
        val lp = params ?: return
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        val maxX = (dm.widthPixels - r.width).coerceAtLeast(0)
        val maxY = (dm.heightPixels - r.height).coerceAtLeast(0)
        lp.x = lp.x.coerceIn(0, maxX)
        lp.y = lp.y.coerceIn(0, maxY)
        runCatching { wm.updateViewLayout(r, lp) }
    }

    // ============================================================ pop-up layar lebar
    // Desain: dua panel miring di kiri dan kanan, bagian tengah transparan (game tetap terlihat).

    /** Kosongkan semua rujukan ke view panel lama sebelum panel disusun ulang. */
    private fun clearViewRefs() {
        scroll = null
        resStatus = null
        fpsValue = null
        tempValue = null
        battValue = null
        extraView = null
        autoFpsSwitch = null
        mainSwitch = null
        focusSwitch = null
        saverSwitch = null
        saverSub = null
        macroSwitch = null
        crossSwitch = null
        hudSwitch = null
        ringGpu = null
        ringCpu = null
        scaleChips.clear()
        fpsChips.clear()
        heatChips.clear()
        rowRes = null
        rowFps = null
        orbCpu = null
        orbRight = null
        meterCpu = null
        meterRight = null
        hexMacro = null
        hexCross = null
        hexHud = null
        tileMain = null
        tileSaver = null
        tileAuto = null
        selHeat = null
        selFocus = null
        pickerLayer = null
        spaceRoot = null
    }

    /** Pilih susunan panel sesuai layar: landscape lebar = dua panel miring; selain itu = kartu bertumpuk. */
    private fun layoutPanelForScreen() {
        val dm = realMetrics()
        spaceMode = dm.widthPixels > dm.heightPixels && dm.widthPixels / dm.density >= 560f
        clearViewRefs()
        if (spaceMode) {
            buildSpacePanel()
        } else {
            params?.x = (8 * dm.density).toInt()
            buildPanel()
        }
        setFullScreen(spaceMode)
        updateScrollMax()
    }

    /** Panel lebar menutupi seluruh layar (tengahnya transparan); panel sempit dan bubble hanya sebesar isinya. */
    private fun setFullScreen(on: Boolean) {
        val lp = params ?: return
        val r = root ?: return
        if (on) {
            lp.width = WindowManager.LayoutParams.MATCH_PARENT
            lp.height = WindowManager.LayoutParams.MATCH_PARENT
            lp.x = 0
            lp.y = 0
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        } else {
            lp.width = WindowManager.LayoutParams.WRAP_CONTENT
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN.inv()
        }
        runCatching { wm.updateViewLayout(r, lp) }
    }

    /** Jalankan [clamp] setelah tata letak selesai (ukuran root baru diketahui setelah layout). */
    private fun clampAfterLayout() {
        val r = root ?: return
        val vto = r.viewTreeObserver
        if (!vto.isAlive) return
        vto.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                val o = r.viewTreeObserver
                if (o.isAlive) o.removeOnGlobalLayoutListener(this)
                clamp()
            }
        })
    }

    /**
     * Pop-up lebar: dua papan artwork (kiri dan kanan) dengan bagian tengah transparan, dan tombol,
     * angka, serta teks hidup yang diletakkan di atas slot pada gambar (lihat ArtPanel.kt).
     */
    private fun buildSpacePanel() {
        val p = panel ?: return
        val dm = realMetrics()
        val h = dm.heightPixels
        val w = dm.widthPixels
        // Rancangan dasar 800 x 360 dp; dipakai untuk kapsul status dan pemilih (di luar gambar).
        uiScale = minOf(w / dm.density / 800f, h / dm.density / 360f).coerceIn(0.7f, 1.6f)
        val u = dm.density * uiScale
        spaceUnit = u
        val s = Art.scaleFor(w, h)

        p.removeAllViews()
        p.background = null
        p.layoutParams = LinearLayout.LayoutParams(MATCH, MATCH)

        val frame = FrameLayout(this).apply {
            setBackgroundColor(0x55000000)
            // Ketuk bagian tengah yang transparan = kecilkan panel.
            setOnClickListener { togglePanel() }
        }
        spaceRoot = frame
        p.addView(frame, LinearLayout.LayoutParams(MATCH, MATCH))

        val left = buildArtLeft(s)
        val right = buildArtRight(s)
        frame.addView(
            left,
            FrameLayout.LayoutParams(left.boardWidth(), left.boardHeight(), Gravity.START or Gravity.CENTER_VERTICAL)
        )
        frame.addView(
            right,
            FrameLayout.LayoutParams(right.boardWidth(), right.boardHeight(), Gravity.END or Gravity.CENTER_VERTICAL)
        )
        frame.addView(
            buildStatusPill(u),
            FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
                .apply { bottomMargin = (10 * u).toInt() }
        )
        setAlert(heatWarned)
    }

    /** Papan kiri: tombol ikon, daftar status, pengukur CPU, pilihan peringatan panas, garis beban, dan kipas (Boost). */
    private fun buildArtLeft(s: Float): ArtBoard {
        val b = ArtBoard(this, R.drawable.popup_left, s, originX = 0)

        // Empat tombol segi enam: Beranda, Crosshair (pena), Macro (stik), HUD Mini (kubus).
        fun hex(cx: Int, onClick: () -> Unit): ArtHit {
            val v = ArtHit(this, s, hex = true)
            v.setOnClickListener { onClick() }
            b.place(v, cx - 48, 14, cx + 48, 110)
            return v
        }
        hex(92) { openApp() }
        hexCross = hex(215) { toggleCross() }
        hexMacro = hex(340) { toggleMacro() }
        hexHud = hex(462) { toggleHud() }

        // Daftar status di atas kelima kartu kosong pada gambar.
        val rRes = ArtRow(this, s, "Render Resolution", withMore = true)
            .apply { setOnClickListener { pickResolution() } }
        val rFps = ArtRow(this, s, "FPS Limit", withMore = true)
            .apply { setOnClickListener { pickFps() } }
        val rLive = ArtRow(this, s, "FPS Sekarang", withMore = false)
        val rTemp = ArtRow(this, s, "Suhu HP", withMore = false)
        val rBatt = ArtRow(this, s, "Baterai", withMore = false)
        rowRes = rRes
        rowFps = rFps
        fpsValue = rLive.valueView
        tempValue = rTemp.valueView
        battValue = rBatt.valueView
        val ys = listOf(145 to 228, 270 to 353, 395 to 478, 516 to 598, 637 to 712)
        listOf(rRes, rFps, rLive, rTemp, rBatt).forEachIndexed { i, r ->
            b.place(r, 30, ys[i].first, 272, ys[i].second)
        }

        // Pengukur CPU, pilihan batas panas, garis beban.
        val orb = ArtGauge(this, s).apply { label = "CPU" }
        b.place(orb, 340, 150, 580, 375)
        orbCpu = orb

        val sel = ArtSelector(this, s, heatLabel(), padL = 30, padT = 8, padR = 30, padB = 22)
            .apply { setOnClickListener { cycleHeat() } }
        b.place(sel, 348, 386, 565, 456)
        selHeat = sel

        val meter = ArtMeter(this, s, left = true)
        b.place(meter, 350, 495, 525, 718)
        meterCpu = meter

        // Kipas di dasar garis beban = Boost.
        val fan = ArtHit(this, s).apply { setOnClickListener { boost() } }
        b.place(fan, 336, 698, 408, 764)
        return b
    }

    /** Papan kanan: logo (kecilkan), pengukur GPU/RAM, pilihan mode fokus, garis beban, tujuh tombol, dan Buka Nexus. */
    private fun buildArtRight(s: Float): ArtBoard {
        val b = ArtBoard(this, R.drawable.popup_right, s, originX = Art.RIGHT_ORIGIN)

        // Logo NX = kecilkan panel.
        val logo = ArtHit(this, s).apply { setOnClickListener { togglePanel() } }
        b.place(logo, 1410, 18, 1566, 110)

        val orb = ArtGauge(this, s).apply { label = if (gpuMissing) "RAM" else "GPU" }
        b.place(orb, 1293, 150, 1533, 375)
        orbRight = orb

        val sel = ArtSelector(this, s, focusLabel(store.focusMode), padL = 22, padT = 8, padR = 40, padB = 8)
            .apply { setOnClickListener { toggleFocus() } }
        b.place(sel, 1313, 390, 1523, 468)
        selFocus = sel

        val meter = ArtMeter(this, s, left = false)
        b.place(meter, 1345, 495, 1520, 718)
        meterRight = meter

        // Kipas di dasar garis beban = kecilkan panel.
        val fan = ArtHit(this, s).apply { setOnClickListener { togglePanel() } }
        b.place(fan, 1462, 698, 1534, 766)

        // Tujuh tombol di atas kotak kosong pada gambar: dua kolom tiga baris, ditambah satu di bawah.
        val tMain = ArtTile(this, s, R.drawable.ic_crown, "Mode Main").apply { setOnClickListener { toggleMain() } }
        val tSaver = ArtTile(this, s, R.drawable.ic_leaf, "Hemat Daya").apply { setOnClickListener { toggleSaver() } }
        val tAuto = ArtTile(this, s, R.drawable.ic_speed, "Auto FPS").apply { setOnClickListener { toggleAutoFps() } }
        tileMain = tMain
        tileSaver = tSaver
        tileAuto = tAuto
        val tiles = listOf<View>(
            tMain,
            tSaver,
            tAuto,
            ArtTile(this, s, R.drawable.ic_monitor, "Res. Asli").apply { setOnClickListener { applyScale(100) } },
            ArtTile(this, s, R.drawable.ic_bolt, "FPS Auto").apply { setOnClickListener { applyFps(0) } },
            ArtTile(this, s, R.drawable.ic_refresh, "Reset").apply { setOnClickListener { resetAll() } },
        )
        val cols = listOf(1597 to 1698, 1735 to 1837)
        val rows = listOf(143 to 226, 268 to 351, 393 to 478)
        tiles.forEachIndexed { i, t ->
            val c = cols[i % 2]
            val r = rows[i / 2]
            b.place(t, c.first, r.first, c.second, r.second)
        }
        val done = ArtTile(this, s, R.drawable.ic_close, "Selesai").apply { setOnClickListener { finishAndReset() } }
        b.place(done, 1597, 522, 1698, 608)

        // Kotak besar bertanda + : buka aplikasi Nexus.
        val open = ArtHit(this, s, caption = "Buka Nexus").apply { setOnClickListener { openApp() } }
        b.place(open, 1607, 653, 1800, 782)
        return b
    }

    /** Kapsul kecil di tengah bawah: status resolusi/FPS dan RAM, supaya tidak perlu membuka panel lain. */
    private fun buildStatusPill(u: Float): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding((16 * u).toInt(), (5 * u).toInt(), (16 * u).toInt(), (5 * u).toInt())
            background = NeonDrawable(
                NeonDrawable.Shape.CHAMFER, u, cutDp = 8f,
                fillTop = 0xE6120A30.toInt(), fillBottom = 0xE6120A30.toInt()
            )
            isClickable = true
        }
        val line1 = TextView(this).apply {
            text = "…"
            with(Neon) { sizePx(10f, u) }
            setTextColor(Neon.TEXT)
            maxLines = 1
        }
        val line2 = TextView(this).apply {
            text = "…"
            with(Neon) { sizePx(9f, u) }
            setTextColor(Neon.MUTED)
            maxLines = 1
        }
        resStatus = line1
        extraView = line2
        box.addView(line1)
        box.addView(line2)
        return box
    }

    // ------------------------------------------------------------ pilihan di tengah layar

    private fun pickResolution() {
        showPicker("Render Resolution", DisplayController.PRESETS, shownScale, { DisplayController.scaleLabel(it) }) {
            applyScale(it)
        }
    }

    private fun pickFps() {
        val rates = listOf(0) + GameDownscale.fpsOptions(DisplayController.supportedRates(this), store.perGameFps)
        showPicker("FPS Limit", rates, shownFps, { if (it == 0) "Auto" else "$it" }) { applyFps(it) }
    }

    /** Kotak pilihan kecil di tengah layar yang transparan; ketuk di luar kotak untuk menutupnya. */
    private fun showPicker(
        title: String,
        values: List<Int>,
        selected: Int?,
        labelOf: (Int) -> String,
        onPick: (Int) -> Unit,
    ) {
        val frame = spaceRoot ?: return
        hidePicker()
        val u = spaceUnit
        val layer = FrameLayout(this).apply {
            setBackgroundColor(0x99000000.toInt())
            setOnClickListener { hidePicker() }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((14 * u).toInt(), (12 * u).toInt(), (14 * u).toInt(), (14 * u).toInt())
            background = NeonDrawable(NeonDrawable.Shape.CHAMFER, u, cutDp = 14f)
            isClickable = true
        }
        box.addView(TextView(this).apply {
            text = title
            with(Neon) { sizePx(14f, u) }
            typeface = Neon.SPORT
            setTextColor(Neon.TEXT)
        })
        val chips = mutableMapOf<Int, TextView>()
        chipGrid(values, chips, minOf(values.size, 7), labelOf) { v ->
            hidePicker()
            onPick(v)
        }.forEach { box.addView(it) }
        selected?.let { s -> chips[s]?.let { styleChip(it, true) } }
        layer.addView(box, FrameLayout.LayoutParams((320 * u).toInt(), WRAP, Gravity.CENTER))
        frame.addView(layer, FrameLayout.LayoutParams(MATCH, MATCH))
        pickerLayer = layer
    }

    private fun hidePicker() {
        val layer = pickerLayer ?: return
        (layer.parent as? ViewGroup)?.removeView(layer)
        pickerLayer = null
    }

    // ------------------------------------------------------------ tombol di panel lebar

    private fun heatLabel(): String =
        if (store.heatWarnC > 0) "Panas ${store.heatWarnC}°C" else "Panas: Mati"

    private fun focusLabel(on: Boolean): String = if (on) "Fokus: Aktif" else "Fokus: Mati"

    /** Ganti batas Peringatan Panas: 40, 42, 44, 46, lalu mati, dan seterusnya. */
    private fun cycleHeat() {
        val order = listOf(0) + HEAT_CHOICES
        val at = order.indexOf(store.heatWarnC).coerceAtLeast(0)
        val next = order[(at + 1) % order.size]
        if (next > 0) store.lastHeatWarnC = next
        store.heatWarnC = next
        updateHeatChips()
    }

    private fun toggleMain() {
        val on = !store.playOptimize
        store.playOptimize = on
        tileMain?.active = on
    }

    private fun toggleAutoFps() {
        val on = !store.autoFps
        store.autoFps = on
        tileAuto?.active = on
        if (!on) restoreAutoFps()
    }

    private fun toggleSaver() {
        val on = !saverOn
        saverOn = on
        tileSaver?.active = on
        io.execute {
            val r = PlayMode.setBatterySaver(on, store)
            if (!r.ok) {
                main.post {
                    saverOn = !on
                    tileSaver?.active = !on
                    Toast.makeText(this, "Gagal: ${r.err.ifBlank { r.out }}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun toggleFocus() {
        val on = !store.focusMode
        selFocus?.setLabel(focusLabel(on))
        io.execute {
            val r = PlayMode.setFocus(on, store)
            if (!r.ok) {
                main.post {
                    store.focusMode = !on
                    selFocus?.setLabel(focusLabel(!on))
                    Toast.makeText(this, "Gagal: ${r.err.ifBlank { r.out }}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /** Macro, Crosshair, dan HUD tampil di atas panel; panel dikecilkan agar game dan lapisannya terlihat. */
    private fun toggleMacro() {
        val m = macro ?: return
        m.setShown(!m.shown)
        hexMacro?.active = m.shown
        macroSwitch?.checked = m.shown
        if (m.shown) togglePanel()
    }

    private fun toggleCross() {
        val c = crosshair ?: return
        c.setShown(!c.shown)
        hexCross?.active = c.shown
        crossSwitch?.checked = c.shown
        if (c.shown) togglePanel()
    }

    private fun toggleHud() {
        val hd = hud ?: return
        hd.setShown(!hd.shown)
        hexHud?.active = hd.shown
        if (hd.shown) togglePanel()
    }

    // ------------------------------------------------------------ helpers

    private fun ring(alert: Boolean) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.TRANSPARENT)
        setStroke(dp(2), if (alert) COLOR_ALERT else COLOR_ACCENT)
    }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = sp * uiScale
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun icon(res: Int, tint: Int, sizeDp: Int) = ImageView(this).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(tint)
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun divider(top: Int = 0, bottom: Int = 0) = View(this).apply {
        setBackgroundColor(COLOR_DIVIDER)
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(1)).apply {
            topMargin = top
            bottomMargin = bottom
        }
    }

    /**
     * Judul bagian. Bila [info] diisi, muncul ikon "i" yang menampilkan penjelasan singkat saat diketuk.
     * [trailing] (boleh kosong) ditaruh di ujung kanan baris.
     */
    private fun sectionHeader(
        iconRes: Int,
        title: String,
        info: String? = null,
        topDp: Int = 12,
        trailing: View? = null,
    ): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(topDp) }
        }
        row.addView(icon(iconRes, COLOR_ACCENT, 18))
        row.addView(
            label(title, 13f, Color.WHITE, bold = true),
            LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) }
        )
        if (info != null) {
            val infoIcon = icon(R.drawable.ic_info, COLOR_MUTED, 16)
            infoIcon.setOnClickListener {
                Toast.makeText(this, info, Toast.LENGTH_LONG).show()
            }
            row.addView(infoIcon, LinearLayout.LayoutParams(dp(16), dp(16)).apply { marginStart = dp(8) })
        }
        if (trailing != null) {
            row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            row.addView(trailing)
        }
        return row
    }

    /** Baris-baris chip ([cols] per baris), disimpan di [into] supaya bisa di-highlight. */
    private fun chipGrid(
        values: List<Int>,
        into: MutableMap<Int, TextView>,
        cols: Int,
        label: (Int) -> String,
        onClick: (Int) -> Unit,
    ): List<LinearLayout> = values.chunked(cols).map { group ->
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) }
            group.forEach { v ->
                val chip = makeButton(label(v)) { onClick(v) }
                into[v] = chip
                addView(chip, weightParams())
            }
            // isi slot kosong agar lebar chip di baris terakhir tetap sama
            repeat(cols - group.size) { addView(View(this@OverlayService), weightParams()) }
        }
    }

    private fun makeButton(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 13f * uiScale
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(10), dp(2), dp(10))
            maxLines = 1
            styleChip(this, false)
            setOnClickListener { onClick() }
        }

    private fun styleChip(v: TextView, active: Boolean) {
        v.setTextColor(Color.WHITE)
        v.setTypeface(null, if (active) Typeface.BOLD else Typeface.NORMAL)
        v.background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(if (active) COLOR_CHIP_ACTIVE else COLOR_CHIP)
            if (active) setStroke(dp(2), 0xFFB794FF.toInt())
        }
    }

    private fun weightParams() =
        LinearLayout.LayoutParams(0, WRAP, 1f).apply {
            marginStart = dp(2)
            marginEnd = dp(2)
        }

    /** Ukuran dalam dp, dikalikan skala panel ([uiScale]). */
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density * uiScale).toInt()

    private fun buildNotification(): Notification {
        fun pending(action: String, code: Int) = PendingIntent.getService(
            this, code,
            Intent(this, OverlayService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_bolt)
            .setContentTitle("Nexus Game Boost aktif")
            .setContentText(
                if (store.openMode == GameStore.OPEN_EDGE) "Geser dari tepi layar untuk buka pop-up"
                else "Ketuk bubble NX untuk atur resolusi dan FPS"
            )
            .setContentIntent(open)
            .addAction(0, "Buka pop-up", pending(ACTION_OPEN, 3))
            .addAction(0, "Reset layar", pending(ACTION_RESET, 1))
            .addAction(0, "Selesai", pending(ACTION_FINISH, 2))
            .setOngoing(true)
            .build()
    }
}
