# Nexus Game Boost

Launcher game untuk Android: **downscale resolusi**, **batas FPS**, **boost RAM**, **monitor perangkat**, dan **mode main**, semuanya bisa diatur langsung dari bubble pop-up saat game berjalan.

Tampilan aplikasi (menu dan panel pop-up) dan ikon NX mengikuti desain buatan pemilik aplikasi.

## Fitur

**Menu aplikasi** (bilah bawah: Beranda, Statistik, tombol roket, Pengaturan, Tentang)
- **Beranda:** kartu status (Hz layar, suhu, baterai) dan empat bagian pengaturan
  - *Akses & Izin:* akses Shizuku/root, izin overlay, layar, density, reset otomatis
  - *Mode Game:* **Mode Main** (terapkan resolusi/FPS saat game dibuka) dan **Mode Fokus** (Jangan Ganggu)
  - *Penghemat & Peringatan:* matikan Penghemat Baterai selama main, **Peringatan Panas** (Mati, 40, 42, 44, 46, 48 °C)
  - *Suhu & RAM:* **Boost Otomatis** dan tombol **Boost Sekarang**
- **Tombol roket (Game):** daftar game terpasang (ada saklar "Semua" untuk aplikasi lain). Ketuk game, pilih resolusi (Asli, 0.9x, 0.8x, 0.6x, 0.5x, 0.4x, 0.3x) dan batas FPS, lalu **Luncurkan**. Pengaturan diterapkan dulu, baru game dibuka.
- **Statistik:** suhu, baterai, refresh rate, resolusi, RAM, dan Boost RAM
- **Pengaturan:** status sambungan Shizuku langkah demi langkah, **Auto FPS**, density, izin overlay, **Resolusi per Game**, **DPI Normal**, reset layar
- **Tentang**

**Bubble pop-up (logo NX)** di atas game. Ketuk untuk membuka panel, geser (bubble atau judul panel) untuk memindahkan.
- **Render Resolution:** ganti skala resolusi kapan saja
- **FPS Limit:** Auto atau salah satu refresh rate yang didukung layar
- **Live Statistics:** FPS, suhu HP, baterai, ditambah RAM bebas dan lama main, diperbarui tiap 3 detik selama panel terbuka
- **Auto FPS:** turun ke 60 Hz saat HP panas, naik lagi setelah suhu turun 3 °C
- **Temperature Warning:** pesan saat suhu melewati batas; cincin bubble berubah merah
- **Battery Saver:** nyalakan atau matikan Penghemat Baterai langsung dari panel
- **Boost / Reset / Selesai:** Reset mengembalikan resolusi dan refresh rate; Selesai mengembalikan semuanya dan menutup bubble
- Pilihan terakhir di bubble tersimpan sebagai profil game tersebut
- **Reset otomatis:** setelah kamu keluar dari game sekitar 12 detik, semuanya dikembalikan dan bubble ditutup (bisa dimatikan di Beranda)

## Cara kerja dan batasannya

Pengaturan sistem diubah lewat perintah shell (`wm size`, `wm density`, `settings put ...`, `cmd notification`, `am kill-all`). Perintah ini hanya bisa dijalankan akses **shell** atau **root**, bukan aplikasi biasa. Jadi aplikasi ini memakai **Shizuku** (tanpa root, disarankan) atau **root**.

- **Resolusi (0.9x, 0.8x, dst):** angka ini adalah **resolusi render game**, bukan ukuran layar. Di **Android 14 ke atas** aplikasi memakai Game Mode bawaan Android (`cmd game set --downscale 0.8 <paket>`), jadi hanya game itu yang turun resolusinya. Layar, ikon, dan aplikasi lain tidak berubah. Batasannya:
  - Game **harus dibuka ulang** supaya berlaku. Karena itu aplikasi menerapkannya sebelum game dibuka, dan perubahan dari bubble baru terasa setelah game dibuka lagi.
  - Game boleh menolak lewat pengaturannya sendiri, dan pabrikan HP (termasuk HiOS) boleh membatasinya. Kalau HP menolak, aplikasi menampilkan pesan errornya.
  - Android menyarankan tidak di bawah 0.7x karena sebagian game jadi kabur atau error.
  - Mode game bawaan game itu bisa kembali ke "standar" setelah Reset, karena Android tidak memberi tahu mode sebelumnya.
- **Resolusi seluruh layar (cadangan):** di Android 13 ke bawah, atau kalau saklar **Resolusi per Game** dimatikan di Pengaturan, dipakai `wm size` yang menurunkan resolusi **seluruh layar**. Cara ini langsung terasa, tapi semua aplikasi ikut mengecil. Tekan **Selesai** atau **Reset** setelah main.
- **DPI Normal (default 490):** DPI yang dipakai sehari-hari. Setelah main, density dikembalikan ke angka ini (bukan ke bawaan pabrik), dan pada cara seluruh layar density dihitung dari angka ini. Bisa diubah atau diset Otomatis di Pengaturan, bagian Layar. Reset otomatis tidak menyentuh DPI kalau bukan aplikasi ini yang mengubah layar. Tombol **Reset Layar Sekarang** selalu mengembalikan ke DPI Normal.
- **Atur FPS:** yang dibatasi adalah **refresh rate layar** (misalnya 60 atau 90 Hz). Game yang mengikuti layar ikut terbatas. Game yang punya pilihan FPS sendiri di dalam game tetap perlu diatur di sana. Beberapa merek HP memakai pengaturan refresh rate sendiri, jadi di sebagian HP pengaturan ini mungkin tidak berpengaruh.
- **Angka FPS di panel:** diperkirakan dari data frame SurfaceFlinger (`dumpsys SurfaceFlinger --latency`). Tidak semua HP atau versi Android mengisi data itu. Kalau gagal, panel menampilkan "—", bukan angka karangan. Angka "Hz Layar" di Beranda adalah refresh rate panel, bukan FPS game.
- **Refresh rate asli dipulihkan:** nilai pengaturan sebelum diubah disimpan, lalu dikembalikan persis saat Reset atau Selesai.
- **Mode main hanya memulihkan yang dia ubah:** kalau Jangan Ganggu sudah menyala, atau Penghemat Baterai sudah mati sebelum main, keduanya tidak disentuh sama sekali. Mode Fokus memakai mode "prioritas", jadi telepon dari kontak prioritas dan alarm tetap bunyi sesuai pengaturan HP-mu. Saklar Battery Saver di panel adalah kendali manual: apa pun yang kamu pilih di sana tidak dibalik otomatis.
- **Boost:** menjalankan `am kill-all`, yang mematikan proses latar yang aman dimatikan. Android sering memulai ulang sebagian aplikasi itu, jadi efeknya bisa sementara dan kadang kecil. Aplikasi menampilkan selisih RAM bebas sesudahnya. **Boost Otomatis** hanya jalan saat RAM bebas di bawah sekitar 12% (atau 700 MB), dengan jeda minimal 90 detik.
- **Peringatan panas / Auto FPS:** memakai suhu baterai, bukan suhu chip. Angkanya hanya perkiraan kasar kondisi HP. Peringatan muncul sekali, lalu baru muncul lagi setelah suhu turun 2 °C. Auto FPS memakai batas suhu yang sama (44 °C bila peringatan dimatikan) dan baru bekerja setelah game dibuka dari aplikasi ini sehingga bubble aktif.
- **Reset otomatis:** aplikasi memeriksa aplikasi yang sedang di depan tiap 4 detik (lewat `dumpsys`). Kalau kamu keluar dari game lebih dari ±12 detik, semuanya dikembalikan dan bubble ditutup. Membuka Nexus Game Boost sendiri tidak dihitung keluar dari game. Membuka aplikasi lain lebih dari 12 detik (misalnya login lewat browser) juga dianggap keluar. Kalau aplikasi tidak bisa memastikan mana yang di depan (format `dumpsys` berbeda antar HP), tidak ada yang direset otomatis, jadi tetap tekan **Selesai** untuk jaga-jaga.
- Layar akan berkedip sebentar saat resolusi berubah. Ini normal.
- Sebagian game membaca resolusi hanya saat dibuka, jadi perubahan dari bubble mungkin baru terasa setelah game dibuka ulang.

## Cara mendapatkan APK

Build dilakukan di server GitHub (gratis), hasilnya APK yang muncul di bagian **Releases** repo kamu. Tinggal tap file `GameTuner-debug.apk` untuk mengunduh.

**Opsi A: dari PC atau laptop**
1. Ekstrak zip ini.
2. Buat repo baru di GitHub (pilih Private), lalu unggah **isi** folder `GameTuner` lewat link "uploading an existing file". Pastikan folder `.github` ikut.
3. Build jalan otomatis. Setelah hijau, buka **Releases** di halaman utama repo dan unduh APK-nya.

**Opsi B: dari HP saja**
Upload web di HP tidak bisa memilih folder, jadi zip diunggah apa adanya dan GitHub yang mengekstraknya.
1. Buat repo baru (Private), centang **Add a README file**.
2. **Add file → Upload files**, pilih zip ini, lalu **Commit changes**.
3. **Add file → Create new file**, ketik nama `.github/workflows/build.yml`, lalu tempel isi file `build-dari-zip.yml` (ada di dalam zip ini) dan **Commit changes**.
4. Tunggu sekitar 5–10 menit sampai build hijau, lalu unduh APK dari **Releases**.

## Memperbarui ke versi baru

1. Unggah zip yang baru ke repo yang sama (**Add file → Upload files**). Workflow otomatis memakai zip yang paling baru, jadi zip lama tidak perlu dihapus.
2. Tunggu build hijau, lalu unduh APK dari **Releases** (pilih build dengan nomor paling besar).
3. Pasang APK-nya. Aplikasi ini memakai kunci tanda tangan tetap (`app/debug.keystore`), jadi APK baru langsung menimpa versi lama. Tidak perlu menghapus aplikasi, dan profil game serta pengaturanmu tetap ada.

**Perhatian, sekali saja:** APK dari zip lama (sebelum ada `app/debug.keystore`) ditandatangani kunci acak yang berbeda di setiap build. Kalau di HP-mu sudah terpasang APK seperti itu, **uninstall dulu** Game Tuner yang lama sebelum memasang yang ini. Kalau tidak, Android menolak dengan pesan "App not installed". Setelah itu izin Shizuku dan pengaturan perlu diatur ulang. Untuk versi-versi berikutnya hal ini tidak perlu diulang.

`app/debug.keystore` adalah kunci debug yang tidak rahasia dan hanya cukup untuk memasang update di HP sendiri. Jangan dipakai untuk merilis ke Play Store.

## Cara pakai pertama kali

1. Pasang **Shizuku** dari Play Store atau shizuku.rikka.app, lalu jalankan lewat *Wireless debugging* (ikuti petunjuk di aplikasi Shizuku). Perlu diulang setelah HP restart.
2. Buka Nexus Game Boost. Di Beranda, bagian *Akses & Izin*, nyalakan saklar **Akses Sistem Root / Shizuku** dan setujui permintaan Shizuku.
3. Nyalakan saklar **Izin Pop Up Overlay** dan aktifkan izin tampil di atas aplikasi lain.
4. Ketuk tombol roket, pilih game, atur resolusi dan FPS, lalu **Luncurkan**.

## Kalau tidak bisa tersambung ke Shizuku

Buka tab **Pengaturan**. Bagian *Sambungan Shizuku* menampilkan tiga langkah dengan tanda centang, dan satu tombol untuk langkah berikutnya:

| Yang terlihat | Artinya | Yang dilakukan |
|---|---|---|
| "Aplikasi Shizuku terpasang" belum centang | Shizuku belum dipasang | Ketuk **Unduh Shizuku**, pasang, lalu **Cek Ulang** |
| "Layanan Shizuku berjalan" belum centang | Shizuku terpasang tapi belum dinyalakan (hilang tiap HP restart) | Ketuk **Buka Shizuku**, lalu **Mulai** |
| "Izin untuk Nexus Game Boost" belum centang | Layanan jalan, izin belum diberikan | Ketuk **Beri Izin**, pilih **Izinkan** |
| Izin pernah ditolak | Shizuku tidak menampilkan dialog lagi | Buka Shizuku, **Aplikasi terotorisasi**, aktifkan Nexus Game Boost |

Pesan error terakhir dari perintah shell ikut ditampilkan di bagian itu, supaya penyebabnya kelihatan kalau kirim tangkapan layar.

Penyebab teknis yang sudah diperbaiki di versi ini: aplikasi sekarang mendeklarasikan izin `moe.shizuku.manager.permission.API_V23` dan mengizinkan pengecekan paket Shizuku di Android 11 ke atas. Tanpa itu aplikasi tidak terdaftar di Shizuku dan tombol izin bisa tidak berbuat apa-apa.

## Kalau layar atau pengaturan tersangkut

Dari Nexus Game Boost buka **Pengaturan** lalu tekan **Reset Layar Sekarang**; ini mengembalikan layar dan Mode main. Kalau aplikasi tidak bisa dibuka, jalankan dari PC lewat ADB:

```
adb shell wm size reset
adb shell wm density 490
adb shell cmd game reset <nama.paket.game>
adb shell settings delete system min_refresh_rate
adb shell settings delete system peak_refresh_rate
adb shell cmd notification set_dnd off
adb shell settings put global low_power 1
```

`wm density 490` mengembalikan ke DPI-mu (ganti angkanya kalau DPI-mu lain; `wm density reset` kembali ke bawaan pabrik). Baris `cmd game reset` hanya perlu kalau tadi resolusi per game dipakai; ganti `<nama.paket.game>` dengan paket game-nya. Dua perintah terakhir hanya perlu kalau tadi Mode Fokus atau Penghemat Baterai ikut diubah. Perintah refresh rate menghapus pengaturan refresh rate; kalau sebelumnya kamu pernah mengaturnya sendiri di Pengaturan HP, atur ulang di sana. `low_power 1` menyalakan Penghemat Baterai, jadi lewati baris itu kalau sebelumnya memang tidak kamu pakai.

## Aset dan lisensi

- Logo NX, ikon aplikasi, dan desain tampilan: buatan pemilik aplikasi.
- Ikon antarmuka di `app/src/main/res/drawable/ic_*.xml`: digambar sendiri sebagai VectorDrawable (Apache-2.0).
- [Shizuku](https://github.com/RikkaApps/Shizuku-API) oleh RikkaApps (Apache-2.0).

## Status

Versi sebelumnya sudah berhasil dibuild di GitHub Actions. Versi ini (tampilan baru, ikon baru, perbaikan Shizuku, panel bubble baru, Auto FPS, Boost Otomatis, pengukur FPS, resolusi per game lewat Game Mode, DPI Normal) **belum dikompilasi** karena lingkungan penyusunnya tidak punya akses ke server Gradle/Maven, dan belum ada fitur yang diuji berjalan di HP. Kode sudah diperiksa manual (kurung, referensi resource, XML), tapi kesalahan kecil saat kompilasi masih mungkin. Kalau build menampilkan error, kirim pesan errornya agar bisa diperbaiki.

## Ide berikutnya

- Batas FPS per game lewat Game Mode bawaan Android (`cmd game set --fps`), seperti yang sudah dipakai untuk resolusi
- Kunci kecerahan dan rotasi layar selama main
