package com.gametuner.launcher

import kotlin.math.roundToInt

/**
 * Memperkirakan FPS aplikasi yang sedang tampil dari data frame SurfaceFlinger
 * (`dumpsys SurfaceFlinger --latency`). Cara ini dipakai banyak aplikasi pengukur FPS,
 * tapi tidak semua versi Android/HP mengisi datanya. Bila gagal hasilnya null dan UI
 * menampilkan "—", bukan angka karangan. Blocking: panggil dari thread background.
 */
object FpsMeter {

    fun measure(pkg: String): Int? {
        val layers = ShellRunner.exec("dumpsys SurfaceFlinger --list").out
            .lines()
            .map { it.trim() }
            .filter { it.contains(pkg) && !it.contains("Background", ignoreCase = true) }
        if (layers.isEmpty()) return null

        // Layer BLAST (Android 12+) dan SurfaceView adalah tempat game menggambar; coba yang paling mungkin dulu.
        val candidates = layers.sortedBy {
            when {
                it.contains("SurfaceView") && it.contains("BLAST") -> 0
                it.contains("BLAST") -> 1
                it.contains("SurfaceView") -> 2
                else -> 3
            }
        }.take(4)

        for (layer in candidates) {
            val fps = fpsOf(layer)
            if (fps != null) return fps
        }
        return null
    }

    private fun fpsOf(layer: String): Int? {
        val out = ShellRunner.exec("dumpsys SurfaceFlinger --latency \"$layer\"").out
        // Baris pertama = periode refresh. Sisanya: 3 timestamp (ns); kolom ke-2 = waktu frame tampil.
        val times = out.lines().drop(1).mapNotNull { line ->
            val p = line.trim().split(Regex("\\s+"))
            if (p.size < 3) null else p[1].toLongOrNull()
        }.filter { it > 0L && it != Long.MAX_VALUE }

        if (times.size < 10) return null
        val sorted = times.sorted()
        val span = sorted.last() - sorted.first()
        if (span <= 0L) return null
        val fps = (sorted.size - 1) * 1_000_000_000.0 / span
        return fps.roundToInt().takeIf { it in 1..240 }
    }
}
