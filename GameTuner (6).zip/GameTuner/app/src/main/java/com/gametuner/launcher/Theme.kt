package com.gametuner.launcher

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Palet Nexus Game Boost: hitam keunguan, aksen ungu neon, hijau untuk status baik. */
object Nx {
    val Bg = Color(0xFF07050F)
    val Card = Color(0xFF0E0A1E)
    val CardRaised = Color(0xFF150F2C)
    val Chip = Color(0xFF1A1430)
    val Border = Color(0xFF5B2FE0)
    val BorderSoft = Color(0xFF2C1B6B)
    val Divider = Color(0xFF241848)
    val Purple = Color(0xFF6D3CF5)
    val PurpleDeep = Color(0xFF3A1BA6)
    val PurpleLight = Color(0xFFA78BFA)
    val Text = Color(0xFFF4F0FF)
    val Muted = Color(0xFFA79FC4)
    val Green = Color(0xFF34D399)
    val Amber = Color(0xFFFFA94D)
    val Red = Color(0xFFFF6B5A)
}

private val Scheme = darkColorScheme(
    primary = Nx.Purple,
    onPrimary = Color.White,
    secondary = Nx.PurpleLight,
    background = Nx.Bg,
    onBackground = Nx.Text,
    surface = Nx.Card,
    onSurface = Nx.Text,
    surfaceVariant = Nx.CardRaised,
    onSurfaceVariant = Nx.Muted,
    secondaryContainer = Nx.PurpleDeep,
    onSecondaryContainer = Color.White,
    error = Nx.Red,
)

@Composable
fun GameTunerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
