package com.gametuner.launcher

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity(), AppActions {

    private lateinit var store: GameStore
    private lateinit var ui: UiState

    private val supportedRates by lazy { DisplayController.supportedRates(this) }

    private val binderListener = Shizuku.OnBinderReceivedListener { refreshStatus() }
    private val deadListener = Shizuku.OnBinderDeadListener { refreshStatus() }
    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ -> refreshStatus() }

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // UI selalu gelap, jadi ikon status bar dan navigasi dibuat terang.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        store = GameStore(this)
        ui = UiState(store)

        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        loadApps()
        setContent {
            GameTunerTheme {
                NexusApp(ui, this@MainActivity, supportedRates)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        ui.overlayGranted = Settings.canDrawOverlays(this)
        // Overlay bisa mengubah profil saat game jalan, jadi baca ulang.
        ui.reloadProfiles()
        refreshStatus()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- data

    private fun loadApps() {
        lifecycleScope.launch { ui.apps = withContext(Dispatchers.IO) { queryApps() } }
    }

    @Suppress("DEPRECATION")
    private fun queryApps(): List<GameApp> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .mapNotNull { ri ->
                val ai = ri.activityInfo.applicationInfo
                if (ai.packageName == packageName) return@mapNotNull null
                val isGame = ai.category == ApplicationInfo.CATEGORY_GAME ||
                    (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                GameApp(
                    pkg = ai.packageName,
                    label = ri.loadLabel(pm).toString(),
                    icon = ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap(),
                    isGame = isGame,
                )
            }
            .distinctBy { it.pkg }
            .sortedWith(compareByDescending<GameApp> { it.isGame }.thenBy { it.label.lowercase() })
    }

    private fun refreshStatus(forceRoot: Boolean = false) {
        lifecycleScope.launch {
            val s = withContext(Dispatchers.IO) {
                val mode = ShellRunner.detect(forceRoot)
                val hasAccess = mode != ShellRunner.Mode.NONE
                val running = ShellRunner.shizukuRunning()
                val granted = running && ShellRunner.shizukuGranted()
                val shizuku = when {
                    granted -> ShizukuState.READY
                    running ->
                        if (ShellRunner.shizukuDeniedPermanently()) ShizukuState.DENIED
                        else ShizukuState.NEED_PERMISSION
                    ShellRunner.shizukuInstalled(this@MainActivity) -> ShizukuState.NOT_RUNNING
                    else -> ShizukuState.NOT_INSTALLED
                }
                SysStatus(
                    mode = mode,
                    shizuku = shizuku,
                    info = if (hasAccess) DisplayController.read() else null,
                    pinnedHz = if (hasAccess) DisplayController.readRefreshRate() else 0,
                    modeActive = store.focusApplied || store.batterySaverApplied,
                    lastError = ShellRunner.lastError,
                )
            }
            ui.status = s
        }
    }

    // ------------------------------------------------------------- actions

    override fun fixAccess() {
        when (ui.status.shizuku) {
            ShizukuState.READY -> toast("Akses sistem sudah aktif.")
            ShizukuState.NOT_INSTALLED -> {
                toast("Shizuku belum dipasang. Pasang dulu, lalu jalankan.")
                openUrl("https://shizuku.rikka.app/download/")
            }
            ShizukuState.NOT_RUNNING -> {
                toast("Ketuk Mulai di Shizuku, lalu kembali ke sini.")
                openShizuku()
            }
            ShizukuState.NEED_PERMISSION -> {
                ShellRunner.requestShizuku()
                refreshStatus()
            }
            ShizukuState.DENIED -> {
                toast("Aktifkan Nexus Game Boost di Shizuku, Aplikasi terotorisasi.")
                openShizuku()
            }
        }
    }

    override fun openShizuku() {
        val intent = packageManager.getLaunchIntentForPackage(ShellRunner.SHIZUKU_PACKAGE)
        if (intent == null) {
            toast("Shizuku belum dipasang.")
            openUrl("https://shizuku.rikka.app/download/")
        } else {
            startActivity(intent)
        }
    }

    override fun recheck() {
        refreshStatus(forceRoot = true)
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: ActivityNotFoundException) {
            toast("Tidak ada aplikasi untuk membuka $url")
        }
    }

    override fun launchGame(app: GameApp, percent: Int, fps: Int) {
        val launchIntent = packageManager.getLaunchIntentForPackage(app.pkg)
        if (launchIntent == null) {
            toast("Tidak bisa membuka ${app.label}")
            return
        }
        store.setScale(app.pkg, percent)
        store.setFps(app.pkg, fps)
        store.currentGame = app.pkg
        ui.rememberProfile(app.pkg, percent, fps)

        lifecycleScope.launch {
            val optimize = store.playOptimize
            // Pengaturan diterapkan SEBELUM game dibuka, karena game membaca resolusi saat start.
            val res = withContext(Dispatchers.IO) {
                val a = if (optimize) {
                    Profile.apply(app.pkg, percent, fps, store)
                } else {
                    CmdResult(true, "", "")
                }
                val b = PlayMode.enter(store)
                CmdResult(
                    ok = a.ok && b.ok,
                    out = "",
                    err = listOf(a.err, a.out, b.err).filter { it.isNotBlank() }.joinToString("\n"),
                )
            }
            val wanted = (optimize && (percent < 100 || fps > 0)) ||
                store.focusMode || store.batterySaverOff
            if (!res.ok && wanted) {
                val hint = if (GameDownscale.enabled(store)) {
                    "\nKalau HP menolak Game Mode, matikan 'Resolusi per Game' di tab Pengaturan."
                } else {
                    ""
                }
                toast("Sebagian pengaturan gagal: ${res.err}$hint")
            }

            if (Settings.canDrawOverlays(this@MainActivity)) {
                ContextCompat.startForegroundService(
                    this@MainActivity,
                    Intent(this@MainActivity, OverlayService::class.java)
                )
            } else {
                toast("Izin pop-up overlay belum aktif, bubble tidak akan muncul.")
            }

            startActivity(launchIntent)
            refreshStatus()
        }
    }

    override fun resetDisplay() {
        lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) {
                // Tombol manual: paksa kembali ke DPI normal walau bukan kita yang mengubah layar.
                val a = DisplayController.resetAll(store, force = true)
                val b = PlayMode.restore(store)
                CmdResult(
                    ok = a.ok && b.ok,
                    out = "",
                    err = listOf(a.err, a.out, b.err).filter { it.isNotBlank() }.joinToString("\n"),
                )
            }
            if (res.ok) toast("Layar dikembalikan ke bawaan.")
            else toast("Gagal reset: ${res.err}")
            refreshStatus()
        }
    }

    override fun boost() {
        if (ui.boosting) return
        ui.boosting = true
        lifecycleScope.launch {
            val out = withContext(Dispatchers.IO) { Boost.run(this@MainActivity) }
            ui.boosting = false
            toast(Boost.message(out))
        }
    }

    override fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
