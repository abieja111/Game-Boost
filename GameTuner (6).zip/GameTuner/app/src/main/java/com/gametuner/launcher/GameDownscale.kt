package com.gametuner.launcher

import android.os.Build
import java.util.Locale

/**
 * Menurunkan resolusi render SATU game lewat Game Mode bawaan Android
 * (`cmd game set --downscale <0.3..0.9> <paket>`), tanpa mengubah ukuran layar atau aplikasi lain.
 *
 * Batasan (dari dokumentasi Android):
 * - Perintah mode kustom ada di Android 14 (API 34) ke atas.
 * - Game harus dibuka ulang supaya perubahan berlaku.
 * - Game boleh menolak downscale lewat manifest-nya, dan pabrikan HP boleh membatasinya.
 * Semua fungsi memanggil shell (blocking): panggil dari thread background.
 */
object GameDownscale {

    val available: Boolean
        get() = Build.VERSION.SDK_INT >= 34

    /** Metode per game dipakai bila HP mendukung dan pengguna tidak mematikannya. */
    fun enabled(store: GameStore): Boolean = available && store.perGameResolution

    private val PACKAGE_NAME = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")

    /** `cmd` kadang tetap berkode 0 saat menolak perintah, jadi teks keluarannya ikut diperiksa. */
    private fun failed(r: CmdResult): Boolean {
        if (!r.ok) return true
        val t = (r.out + " " + r.err).lowercase()
        return "exception" in t || "error" in t || "invalid" in t || "unknown" in t
    }

    fun apply(pkg: String, percent: Int, store: GameStore): CmdResult {
        if (!PACKAGE_NAME.matches(pkg)) return CmdResult(false, "", "Nama paket tidak valid.")
        // Sisa pengecilan seluruh layar (cara cadangan) dibuang dulu supaya resolusi tidak turun dua kali.
        // Tidak melakukan apa-apa bila bukan kita yang mengubah layar.
        DisplayController.reset(store, force = false)

        // Game lain yang tadi kita turunkan dibersihkan dulu, supaya tidak ada sisa pengaturan.
        val previous = store.downscalePkg
        val previousCleared = previous == null || previous == pkg || clear(previous, store).ok

        if (percent >= 100) {
            // Hanya bersihkan bila KITA yang menurunkan game ini; jangan sentuh Game Mode buatan pengguna.
            return if (store.downscalePkg == pkg) clear(pkg, store) else CmdResult(true, "", "")
        }

        // Dicatat sebelum perintah dijalankan, supaya hasil sebagian pun tetap bisa dibersihkan saat Reset.
        store.downscalePkg = pkg
        val factor = String.format(Locale.US, "%.1f", percent / 100f)
        val set = ShellRunner.exec("cmd game set --downscale $factor $pkg")
        if (failed(set)) {
            // Gagal: lepaskan catatan, kecuali ada game yang masih terpasang dan perlu dibersihkan nanti.
            store.downscalePkg = if (previous != null && (previous == pkg || !previousCleared)) previous else null
            return CmdResult(false, set.out, set.err.ifBlank { set.out })
        }
        // Pilih mode kustom supaya pengaturan tadi dipakai. Bila perintah ini ditolak, tidak fatal.
        ShellRunner.exec("cmd game mode custom $pkg")
        return CmdResult(true, set.out, set.err)
    }

    /** Hapus downscale game ini dan kembalikan mode game-nya ke standar. */
    fun clear(pkg: String, store: GameStore): CmdResult {
        if (!PACKAGE_NAME.matches(pkg)) return CmdResult(true, "", "")
        val a = ShellRunner.exec("cmd game set --downscale disable $pkg")
        val b = ShellRunner.exec("cmd game reset $pkg")
        ShellRunner.exec("cmd game mode standard $pkg")

        val ok = !failed(a) || !failed(b)
        if (ok && store.downscalePkg == pkg) store.downscalePkg = null
        return CmdResult(
            ok = ok,
            out = "",
            err = if (ok) "" else listOf(a.err, b.err, a.out).filter { it.isNotBlank() }.joinToString("\n"),
        )
    }

    /** Dipakai Reset, Selesai, dan reset otomatis. Tidak melakukan apa-apa bila tidak ada yang kita ubah. */
    fun clearApplied(store: GameStore): CmdResult {
        val pkg = store.downscalePkg ?: return CmdResult(true, "", "")
        return clear(pkg, store)
    }
}

object Profile {

    /** Terapkan profil sebuah game: resolusi (per game atau seluruh layar) + batas refresh rate. */
    fun apply(pkg: String, percent: Int, fps: Int, store: GameStore): CmdResult {
        if (!GameDownscale.enabled(store)) {
            return DisplayController.applyProfile(percent, fps, store.scaleDensity, store)
        }
        val res = GameDownscale.apply(pkg, percent, store)
        val hz = if (fps > 0) {
            DisplayController.setRefreshRate(fps, store)
        } else {
            DisplayController.resetRefreshRate(store)
        }
        return CmdResult(
            ok = res.ok && hz.ok,
            out = listOf(res.out, hz.out).filter { it.isNotBlank() }.joinToString("\n"),
            err = listOf(res.err, hz.err).filter { it.isNotBlank() }.joinToString("\n"),
        )
    }
}
