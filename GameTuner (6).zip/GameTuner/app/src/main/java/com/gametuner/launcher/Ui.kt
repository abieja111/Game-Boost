package com.gametuner.launcher

import android.content.Context
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

// ------------------------------------------------------------------ dasar

@Composable
fun NxIcon(
    @DrawableRes id: Int,
    modifier: Modifier = Modifier,
    tint: Color = Nx.PurpleLight,
    size: Dp = 24.dp,
) {
    Icon(
        painter = painterResource(id),
        contentDescription = null,
        tint = tint,
        modifier = modifier.size(size),
    )
}

/** Kartu gelap berbingkai ungu. */
fun Modifier.nxCard(radius: Dp = 18.dp, borderColor: Color = Nx.Border): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .clip(shape)
        .background(Nx.Card)
        .border(1.dp, borderColor, shape)
}

// Tab judul bagian: sisi kanan miring seperti pada desain.
private val TabShape = GenericShape { size, _ ->
    val slant = size.height * 0.7f
    moveTo(0f, 0f)
    lineTo(size.width - slant, 0f)
    lineTo(size.width, size.height)
    lineTo(0f, size.height)
    close()
}

@Composable
fun SectionCard(
    title: String,
    @DrawableRes icon: Int,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier
                .clip(TabShape)
                .background(Brush.horizontalGradient(listOf(Nx.PurpleDeep, Nx.Purple)))
                .padding(start = 14.dp, end = 36.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NxIcon(icon, tint = Color.White, size = 22.dp)
            Spacer(Modifier.width(10.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
        val shape = RoundedCornerShape(topStart = 0.dp, topEnd = 18.dp, bottomStart = 18.dp, bottomEnd = 18.dp)
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Nx.Card)
                .border(1.dp, Nx.Border, shape)
                .padding(vertical = 4.dp),
            content = content,
        )
    }
}

@Composable
fun SettingRow(
    @DrawableRes icon: Int,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    iconTint: Color = Nx.PurpleLight,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit = {},
) {
    val base = if (onClick != null) modifier.clickable(onClick = onClick) else modifier
    Row(
        base
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        NxIcon(icon, tint = iconTint, size = 30.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Nx.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = Nx.Muted, fontSize = 12.sp, lineHeight = 16.sp)
        }
        Spacer(Modifier.width(10.dp))
        trailing()
    }
}

@Composable
fun NxDivider() {
    Box(
        Modifier
            .padding(horizontal = 14.dp)
            .fillMaxWidth()
            .height(1.dp)
            .background(Nx.Divider)
    )
}

@Composable
fun NxSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked = checked,
        onCheckedChange = onChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = Nx.Purple,
            checkedBorderColor = Nx.Purple,
            uncheckedThumbColor = Nx.Muted,
            uncheckedTrackColor = Nx.Card,
            uncheckedBorderColor = Nx.BorderSoft,
        ),
    )
}

@Composable
fun RadioDot(checked: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(28.dp)
            .clip(CircleShape)
            .border(2.dp, if (checked) Nx.PurpleLight else Nx.Muted.copy(alpha = 0.6f), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (checked) {
            Box(
                Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(Nx.PurpleLight)
            )
        }
    }
}

/** Tombol pil berbingkai, mis. "Atur >". Ikon null = tanpa ikon. */
@Composable
fun PillButton(
    text: String,
    modifier: Modifier = Modifier,
    @DrawableRes icon: Int? = R.drawable.ic_chevron_right,
    @DrawableRes leading: Int? = null,
    accent: Color = Nx.Border,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .clip(shape)
            .background(Nx.CardRaised)
            .border(1.dp, accent, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (leading != null) {
            NxIcon(leading, tint = Nx.PurpleLight, size = 18.dp)
            Spacer(Modifier.width(8.dp))
        }
        Text(text, color = Nx.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        if (icon != null) {
            Spacer(Modifier.width(6.dp))
            NxIcon(icon, tint = Nx.Text, size = 16.dp)
        }
    }
}

@Composable
fun HeatDropdown(value: Int, options: List<Int>, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        PillButton(
            text = if (value == 0) "Mati" else "$value°C",
            icon = R.drawable.ic_expand_more,
            leading = R.drawable.ic_thermo,
            onClick = { open = true },
        )
        DropdownMenu(
            expanded = open,
            onDismissRequest = { open = false },
            modifier = Modifier.background(Nx.CardRaised),
        ) {
            options.forEach { c ->
                DropdownMenuItem(
                    text = { Text(if (c == 0) "Mati" else "$c°C") },
                    onClick = {
                        onPick(c)
                        open = false
                    },
                )
            }
        }
    }
}

@Composable
fun NxButton(
    text: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = Nx.Purple,
            contentColor = Color.White,
            disabledContainerColor = Nx.Chip,
            disabledContentColor = Nx.Muted,
        ),
    ) {
        Text(text, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun NxChip(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier
            .clip(shape)
            .background(if (selected) Color(0xFF2A1A66) else Nx.Chip)
            .then(if (selected) Modifier.border(2.dp, Nx.PurpleLight, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            color = if (selected) Color.White else Nx.Text,
            fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            maxLines = 1,
        )
    }
}

/** Kisi tombol pilihan; baris terakhir diisi ruang kosong supaya lebarnya sama. */
@Composable
fun <T> ChipGrid(
    items: List<T>,
    selected: T?,
    columns: Int,
    label: (T) -> String,
    onPick: (T) -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.chunked(columns).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowItems.forEach { item ->
                    NxChip(label(item), item == selected, Modifier.weight(1f)) { onPick(item) }
                }
                repeat(columns - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun NxDialog(
    title: String,
    onDismiss: () -> Unit,
    confirmText: String? = null,
    onConfirm: () -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Nx.Card,
        titleContentColor = Nx.Text,
        textContentColor = Nx.Muted,
        shape = RoundedCornerShape(22.dp),
        title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content,
            )
        },
        confirmButton = {
            if (confirmText != null) NxButton(confirmText, onClick = onConfirm)
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Tutup", color = Nx.PurpleLight) }
        },
    )
}

// ------------------------------------------------------- header & navigasi

@Composable
fun NxHeader(onSettings: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 12.dp, end = 16.dp, top = 8.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Image(
            painter = painterResource(R.drawable.header_brand),
            contentDescription = "Nexus Game Boost",
            modifier = Modifier
                .weight(1f)
                .height(66.dp),
            alignment = Alignment.CenterStart,
            contentScale = ContentScale.Fit,
        )
        Spacer(Modifier.width(8.dp))
        val shape = RoundedCornerShape(14.dp)
        Box(
            Modifier
                .size(46.dp)
                .clip(shape)
                .background(Nx.CardRaised)
                .border(1.dp, Nx.Border, shape)
                .clickable(onClick = onSettings),
            contentAlignment = Alignment.Center,
        ) {
            NxIcon(R.drawable.ic_settings, tint = Nx.PurpleLight, size = 24.dp)
        }
    }
}

@Composable
private fun RowScope.BarItem(
    label: String,
    @DrawableRes icon: Int,
    selected: Boolean,
    onClick: () -> Unit,
) {
    val shape = RoundedCornerShape(14.dp)
    Column(
        Modifier
            .weight(1f)
            .fillMaxHeight()
            .padding(horizontal = 4.dp, vertical = 6.dp)
            .clip(shape)
            .then(
                if (selected) Modifier.background(
                    Brush.verticalGradient(listOf(Nx.PurpleDeep, Color(0xFF1B0F4F)))
                ) else Modifier
            )
            .clickable(onClick = onClick),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        NxIcon(icon, tint = if (selected) Color.White else Nx.Muted, size = 26.dp)
        Spacer(Modifier.height(2.dp))
        Text(
            label,
            color = if (selected) Color.White else Nx.Muted,
            fontSize = 12.sp,
            maxLines = 1,
        )
    }
}

/** Bilah bawah: Beranda, Statistik, tombol roket di tengah (daftar game), Pengaturan, Tentang. */
@Composable
fun NxBottomBar(tab: Tab, onTab: (Tab) -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .height(92.dp)
    ) {
        val barShape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(66.dp)
                .clip(barShape)
                .background(Brush.verticalGradient(listOf(Color(0xFF160E36), Nx.Bg)))
                .border(1.dp, Nx.Border, barShape),
        ) {
            BarItem("Beranda", R.drawable.ic_home, tab == Tab.HOME) { onTab(Tab.HOME) }
            BarItem("Statistik", R.drawable.ic_chart, tab == Tab.STATS) { onTab(Tab.STATS) }
            Spacer(Modifier.weight(1.1f))
            BarItem("Pengaturan", R.drawable.ic_tune, tab == Tab.SETTINGS) { onTab(Tab.SETTINGS) }
            BarItem("Tentang", R.drawable.ic_info, tab == Tab.ABOUT) { onTab(Tab.ABOUT) }
        }
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .size(76.dp)
                .shadow(14.dp, CircleShape, ambientColor = Nx.Purple, spotColor = Nx.Purple)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFF5B2FE0), Color(0xFF1B0F4F))))
                .border(3.dp, if (tab == Tab.GAMES) Nx.PurpleLight else Nx.Purple, CircleShape)
                .clickable { onTab(Tab.GAMES) },
            contentAlignment = Alignment.Center,
        ) {
            NxIcon(R.drawable.ic_rocket, tint = Color.White, size = 36.dp)
        }
    }
}

// ------------------------------------------------------------- data live

data class Live(val stats: SystemStats, val hz: Int)

private fun readLive(context: Context) =
    Live(SystemStats.read(context), DisplayController.currentRefreshHz(context))

/** Suhu, baterai, RAM, dan refresh rate layar; diperbarui tiap 3 detik selama layar tampil. */
@Composable
fun rememberLive(): Live {
    val context = LocalContext.current
    var live by remember { mutableStateOf(readLive(context)) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            live = readLive(context)
        }
    }
    return live
}

fun tempColor(c: Float): Color = when {
    c >= 44f -> Nx.Red
    c >= 38f -> Nx.Amber
    else -> Nx.Green
}

fun batteryColor(pct: Int): Color = when {
    pct <= 15 -> Nx.Red
    pct <= 30 -> Nx.Amber
    else -> Nx.Green
}
