package com.gametuner.launcher

/**
 * Mengetahui aplikasi mana yang sedang di depan lewat `dumpsys` (butuh akses shell/root,
 * yang memang sudah dipakai aplikasi ini). Format keluaran `dumpsys` berbeda antar versi
 * Android dan merek HP, jadi hasilnya null bila tidak bisa dipastikan. Pemanggil harus
 * menganggap null sebagai "tidak tahu" dan tidak mengambil tindakan apa pun.
 */
object ForegroundWatcher {

    // Contoh baris: "topResumedActivity=ActivityRecord{a1b2 u0 com.contoh.game/.MainActivity t42}"
    private val PACKAGE = Regex("""\s([a-zA-Z][a-zA-Z0-9_]*(?:\.[a-zA-Z0-9_]+)+)/""")

    /** Blocking: panggil dari thread background. */
    fun foregroundPackage(): String? {
        val activities = ShellRunner.exec(
            "dumpsys activity activities | grep -E 'topResumedActivity|ResumedActivity'"
        )
        parse(activities.out)?.let { return it }

        val window = ShellRunner.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
        return parse(window.out)
    }

    private fun parse(text: String): String? {
        for (line in text.lines()) {
            PACKAGE.find(line)?.let { return it.groupValues[1] }
        }
        return null
    }
}
