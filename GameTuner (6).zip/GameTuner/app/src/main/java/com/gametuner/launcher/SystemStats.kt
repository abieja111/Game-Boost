package com.gametuner.launcher

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

/** Gambaran kondisi perangkat: suhu baterai, level baterai, dan RAM bebas. */
data class SystemStats(
    val tempC: Float,
    val batteryPct: Int,
    val charging: Boolean,
    val ramFreeMb: Long,
    val ramTotalMb: Long,
) {
    companion object {
        /** Tidak butuh izin khusus dan cukup ringan untuk dipanggil dari main thread. */
        fun read(context: Context): SystemStats {
            val battery = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val temp = (battery?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
            val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
            val status = battery?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

            val am = context.getSystemService(ActivityManager::class.java)
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)

            return SystemStats(
                tempC = temp,
                batteryPct = pct,
                charging = charging,
                ramFreeMb = mi.availMem / (1024 * 1024),
                ramTotalMb = mi.totalMem / (1024 * 1024),
            )
        }
    }
}

/** Boost: matikan proses latar yang aman dimatikan (`am kill-all`) untuk melegakan RAM. */
object Boost {

    data class Outcome(val ok: Boolean, val freedMb: Long, val error: String)

    /** Blocking (ada jeda singkat untuk mengukur RAM sesudahnya): panggil dari thread background. */
    fun run(context: Context): Outcome {
        val before = SystemStats.read(context).ramFreeMb
        val r = ShellRunner.exec("am kill-all")
        if (!r.ok) return Outcome(false, 0, r.err.ifBlank { r.out })
        Thread.sleep(800)
        val after = SystemStats.read(context).ramFreeMb
        return Outcome(true, after - before, "")
    }

    fun message(o: Outcome): String = when {
        !o.ok -> "Boost gagal: ${o.error}"
        o.freedMb > 0 -> "Boost selesai: +${o.freedMb} MB RAM bebas"
        else -> "Boost selesai (RAM sudah lega)"
    }
}
